// 網頁版離線快取（擴充功能不使用這個檔案）
// VERSION 必須與 manifest.json 的 version 相同：改版時這個檔案內容改變，瀏覽器才會下載新版並清除舊快取。
const VERSION = 'wl-web-2.3.0';
// 預先快取：程式、頁面、樣式、離線詞典、PDF 核心；其他資源（PDF 字型對照表等）第一次用到時才快取
const PRECACHE = [
  "background/ai.js",
  "background/db.js",
  "background/errors.js",
  "background/main.js",
  "background/providers/ai-gemini.js",
  "background/providers/dict-offline.js",
  "background/providers/dict-online.js",
  "background/providers/index.js",
  "background/quota.js",
  "background/settings.js",
  "background/srs.js",
  "background/sw-v2.3.0.js",
  "background/words.js",
  "content.css",
  "content/cards.js",
  "content/core.js",
  "content/events.js",
  "content/highlight.js",
  "content/locate.js",
  "content/ui.js",
  "dict/a.json",
  "dict/b.json",
  "dict/c.json",
  "dict/d.json",
  "dict/e.json",
  "dict/f.json",
  "dict/g.json",
  "dict/h.json",
  "dict/i.json",
  "dict/j.json",
  "dict/k.json",
  "dict/l.json",
  "dict/m.json",
  "dict/n.json",
  "dict/o.json",
  "dict/p.json",
  "dict/q.json",
  "dict/r.json",
  "dict/s.json",
  "dict/t.json",
  "dict/u.json",
  "dict/v.json",
  "dict/w.json",
  "dict/x.json",
  "dict/y.json",
  "dict/z.json",
  "icons/icon180.png",
  "icons/icon192.png",
  "icons/icon48.png",
  "icons/icon512.png",
  "index.html",
  "manifest.json",
  "manifest.webmanifest",
  "pages/options.html",
  "pages/options.js",
  "pages/pages.css",
  "pages/popup.html",
  "pages/popup.js",
  "pages/review.html",
  "pages/review.js",
  "pages/wordbook.html",
  "pages/wordbook.js",
  "pdf/export.mjs",
  "pdf/lib/pdf-lib.min.js",
  "pdf/lib/pdf.min.mjs",
  "pdf/lib/pdf.worker.min.mjs",
  "pdf/lib/pdf_viewer.css",
  "pdf/lib/pdf_viewer.mjs",
  "pdf/marks-geometry.mjs",
  "pdf/viewer.css",
  "pdf/viewer.html",
  "pdf/viewer.mjs",
  "shared/util.js",
  "web/boot.mjs",
  "web/reader.mjs",
  "web/shim.js"
];

self.addEventListener('install', (e) => {
  e.waitUntil(caches.open(VERSION).then((c) => c.addAll(PRECACHE)).then(() => self.skipWaiting()));
});

self.addEventListener('activate', (e) => {
  e.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(keys.filter((k) => k !== VERSION).map((k) => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

// 同網站的檔案：先用快取（離線可用），沒有才下載並存入快取；外部網站（AI、英英字典）一律直接連線
self.addEventListener('fetch', (e) => {
  const url = new URL(e.request.url);
  if (e.request.method !== 'GET' || url.origin !== location.origin) return;
  const isPage = url.pathname.endsWith('.html') || url.pathname.endsWith('/');
  e.respondWith(
    caches.match(e.request, { ignoreSearch: isPage }).then((hit) => hit || fetch(e.request).then((res) => {
      if (res.ok) {
        const copy = res.clone();
        caches.open(VERSION).then((c) => c.put(e.request, copy));
      }
      return res;
    }))
  );
});
