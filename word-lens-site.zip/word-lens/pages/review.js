const $ = (id) => document.getElementById(id);
const { el, escapeRe, send, speak } = WLUtil;
const LEVEL_NAMES = ['新字', '認得', '學習中', '快熟了', '已掌握'];
const RATINGS = [
  { key: 'again', label: '忘記', tip: '稍後再練' },
  { key: 'hard', label: '模糊', tip: '熟悉度不變' },
  { key: 'good', label: '記得', tip: '熟悉度＋1' },
  { key: 'easy', label: '很簡單', tip: '熟悉度＋2' }
];
const KIND = { choice: '選擇題', recognize: '看英文想中文', spell: '看中文拼英文', listen: '聽發音', sense: '本句是哪個意思' };
const KEYS = {
  recognize: '空白鍵 看答案　1–4 評分',
  spell: 'Enter 送出　? 提示　Esc 不會',
  listen: 'R 再聽一次　1–4 選答案　空白鍵 不確定',
  sense: '1–4 選意思　空白鍵 不確定',
  choice: '1–4 選答案　空白鍵 不確定'
};

let queue = [];
let current = null;
let revealed = false;
let suggested = null;
let fixedMode = 'auto';
let practice = null;      // 自由練習中：{ scope, n }；null 表示今日複習
let practiceScope = 'all';
let session = null;       // 這一輪的進度與結果：{ total, done, results: [{ word, rating }] }

const display = (w) => w.lemma || w.key;
const answers = (w) => new Set([w.key, w.lemma, ...(w.forms || [])].filter(Boolean).map((s) => s.toLowerCase()));
const formRe = (w) => {
  const forms = [...answers(w)].sort((a, b) => b.length - a.length).map(escapeRe);
  return forms.length ? new RegExp('\\b(?:' + forms.join('|') + ')\\w*', 'i') : null;
};

// 「本句是哪個意思」要用存了本句意思的那個例句
const senseContext = (w) => (w.contexts || []).find((c) => c && c.sense_zh && c.sentence) || null;

const { clipSentence } = WLUtil;

function sentenceNode(w, hide, c = (w.contexts || [])[0]) {
  if (!c || !c.sentence) return null;
  const re = formRe(w);
  const { text, clipped } = clipSentence(c.sentence, re);
  const m = re && re.exec(text);
  if (!m && clipped) return null;   // 很長又找不到這個字（舊資料只存了段落開頭）：不顯示
  const box = el('div', 'sent');
  if (!m) box.textContent = text;
  else box.append(text.slice(0, m.index), hide ? el('span', 'gap', ' ') : el('mark', null, m[0]), text.slice(m.index + m[0].length));
  return box;
}

// 這個字在例句裡的意思：AI 選出的詞典義，或舊資料「在這句話裡是「X」的意思」裡的 X
function ctxMeaning(c) {
  if (!c) return '';
  if (c.sense_zh) return c.sense_zh;
  const m = /^在這句話裡是「(.+)」的意思。?$/.exec(String(c.context_zh || '').trim());
  return m ? m[1] : '';
}

// 中文翻譯只在例句是完整一句時才顯示（整段翻譯對單字沒有幫助）
function sentenceZh(w, c) {
  if (!c || !c.sentence_zh) return '';
  const { clipped } = clipSentence(c.sentence, formRe(w));
  return clipped || c.sentence_zh.length > 160 ? '' : c.sentence_zh;
}

// 舊資料的「在這句話裡是「X」的意思。」和本句意思重複時不再顯示
function contextNote(c, shown) {
  if (!c || !c.context_zh) return '';
  const m = /^在這句話裡是「(.+)」的意思。?$/.exec(c.context_zh.trim());
  if (m && shown.some((s) => s && s.includes(m[1]))) return '';
  return c.context_zh;
}

async function refreshStats() {
  const r = await send({ type: 'review-stats' });
  if (!r.ok) return;
  $('sDue').textContent = r.data.due;
  $('sToday').textContent = r.data.today;
  $('sStreak').textContent = r.data.streak;
  $('tabDue').textContent = r.data.due;
}

async function loadQueue() {
  const r = practice
    ? await send({ type: 'practice-pool', scope: practice.scope, n: practice.n, mode: fixedMode })
    : await send({ type: 'review-queue', limit: 30, mode: fixedMode });
  queue = r.ok ? r.data : [];
  session = { total: queue.length, done: 0, results: [] };
  next();
}

function setTab(isPractice) {
  $('tabReview').setAttribute('aria-pressed', String(!isPractice));
  $('tabPractice').setAttribute('aria-pressed', String(isPractice));
  $('practiceOpts').hidden = !isPractice;
  $('tabNote').textContent = isPractice ? '練習結果不影響熟悉度與排程，想練幾次都可以' : '依記憶曲線排程，結果會更新熟悉度';
}

function startPractice() {
  practice = { scope: practiceScope, n: +$('practiceN').value };
  loadQueue();
}

function backToReview() {
  practice = null;
  setTab(false);
  loadQueue();
}

function next() {
  refreshStats();
  current = queue.shift() || null;
  revealed = false;
  suggested = null;
  render();
}

function progress(card) {
  const total = Math.max(session.total, session.done + queue.length + 1);
  const bar = el('div', 'bar');
  const fill = el('i');
  fill.style.width = (100 * session.done / total) + '%';
  bar.appendChild(fill);
  card.appendChild(bar);
  const w = current.word;
  const lv = Math.min(5, Math.max(1, w.level || 1));
  const meta = el('div', 'meta');
  meta.appendChild(el('span', null, (practice ? '練習 ' : '複習 ') + (session.done + 1) + ' / ' + total + '　·　' + KIND[current.mode]));
  const dots = el('span', 'dots');
  dots.title = '熟悉度：' + LEVEL_NAMES[lv - 1];
  dots.append(LEVEL_NAMES[lv - 1] + ' ', '●'.repeat(lv), el('span', 'off', '●'.repeat(5 - lv)));
  if (w.cefr !== undefined) {
    const c = el('span', 'cefr', w.cefr || '表外');
    c.title = WLUtil.cefrNote(w.cefr);
    if (w.cefr) c.textContent = w.cefr + '・' + WLUtil.CEFR_TW[w.cefr].tw.replace('全民英檢', '英檢');
    dots.prepend(c);
  }
  meta.appendChild(dots);
  card.appendChild(meta);
}

function headword(w) {
  const h = el('div');
  h.appendChild(el('span', 'word', display(w)));
  if (w.phonetic) h.appendChild(el('span', 'ph', w.phonetic));
  h.appendChild(speakBtn(w));
  return h;
}

function render() {
  const card = $('card');
  card.textContent = '';
  $('keys').textContent = current ? KEYS[current.mode] : '';
  if (!current) return renderDone(card);
  const w = current.word;
  progress(card);

  if (current.mode === 'recognize') {
    card.appendChild(headword(w));
    const s = sentenceNode(w, false);
    if (s) card.appendChild(s);
    card.appendChild(el('p', 'prompt', s ? '想想它在這句話裡是什麼意思，再看答案。' : '想想它的中文意思，再看答案。'));
    card.appendChild(revealButtons('看答案'));
  } else if (current.mode === 'sense') {
    renderSense(card, w);
  } else if (current.mode === 'choice') {
    renderChoice(card, w);
  } else if (current.mode === 'listen') {
    renderListen(card, w);
  } else {
    renderSpell(card, w);
  }
}

function revealButtons(label) {
  const box = el('div', 'btns');
  const b = el('button', 'btn', label);
  b.id = 'revealBtn';
  b.addEventListener('click', () => reveal());
  box.appendChild(b);
  return box;
}

// 看中文拼英文：中文意思＋挖空的原句；可要提示（首字母與字數），用了提示答對只建議「模糊」
function renderSpell(card, w) {
  const c = (w.contexts || [])[0];
  const mean = ctxMeaning(c);
  card.appendChild(el('div', 'zhbig', mean || w.zh || '（沒有中文意思）'));
  if (mean && w.zh && w.zh !== mean) card.appendChild(el('div', 'muted', '詞典：' + w.zh));
  const s = sentenceNode(w, true);
  if (s) card.appendChild(s);
  const box = el('div', 'spell');
  const input = el('input');
  input.id = 'spellInput';
  input.placeholder = '輸入英文單字';
  input.autocomplete = 'off';
  input.autocapitalize = 'off';
  input.spellcheck = false;
  box.appendChild(input);
  card.appendChild(box);
  const hintLine = el('div', 'hintline');
  hintLine.id = 'hintLine';
  card.appendChild(hintLine);
  const btns = el('div', 'btns');
  const ok = el('button', 'btn', '送出');
  ok.id = 'revealBtn';
  ok.addEventListener('click', () => reveal());
  const hint = el('button', 'btn ghost', '提示');
  hint.id = 'hintBtn';
  hint.addEventListener('click', showHint);
  const give = el('button', 'btn ghost', '不會，看答案');
  give.addEventListener('click', () => reveal(true));
  btns.append(ok, hint, give);
  card.appendChild(btns);
  setTimeout(() => input.focus(), 50);
}

function showHint() {
  if (!current || revealed || current.mode !== 'spell') return;
  const t = display(current.word);
  current.hints = (current.hints || 0) + 1;
  const shown = Math.min(t.length - 1, current.hints);
  $('hintLine').textContent = [...t].map((ch, i) => (i < shown || ch === ' ' || ch === '-' ? ch : '_')).join(' ');
  if (shown >= t.length - 1) $('hintBtn').disabled = true;
  $('spellInput').focus();
}

// 四個選項的按鈕（本句意思、選擇題、聽音選字共用）；選了就對答案
function optionButtons(card, opts) {
  const box = el('div', 'opts');
  opts.options.forEach((label, i) => {
    const b = el('button', 'opt');
    b.append(el('span', 'k', String(i + 1)), document.createTextNode(label));
    b.addEventListener('click', () => chooseOption(i));
    box.appendChild(b);
  });
  card.appendChild(box);
}

const choiceDir = (w) => {
  const lv = w.level || 1;
  return lv <= 1 ? 'en2zh' : lv === 2 ? (Math.random() < 0.5 ? 'en2zh' : 'zh2en') : 'zh2en';
};

// 選擇題：新字看英文選中文；熟一點的字看中文（＋挖空原句）選英文
async function renderChoice(card, w) {
  const item = current;
  const c = (w.contexts || [])[0];
  const dir = item.dir || (item.dir = choiceDir(w));
  const r = await send({ type: 'choice-options', key: item.key, dir, answer: dir === 'en2zh' ? ctxMeaning(c) : '' });
  if (current !== item) return;
  if (!r || !r.ok || !r.data) {   // 生詞本太少、詞典也補不到選項：改用一般卡片
    item.mode = 'recognize';
    return render();
  }
  item.options = r.data;
  if (dir === 'en2zh') {
    card.appendChild(headword(w));
    const s = sentenceNode(w, false);
    if (s) card.appendChild(s);
    card.appendChild(el('p', 'ask', s ? '它在這句話裡是什麼意思？' : '它是什麼意思？'));
  } else {
    card.appendChild(el('div', 'zhbig', ctxMeaning(c) || w.zh || ''));
    const s = sentenceNode(w, true);
    if (s) card.appendChild(s);
    card.appendChild(el('p', 'ask', s ? '哪個字可以填進空格？' : '哪個英文字是這個意思？'));
  }
  optionButtons(card, r.data);
  card.appendChild(revealButtons('不確定，看答案'));
}

// 聽發音：聽完從四個英文字選一個（字首、長度相近的字優先當干擾）
async function renderListen(card, w) {
  const item = current;
  const box = el('div', 'listen');
  const big = el('button', 'big', '🔊');
  big.title = '再聽一次（R）';
  big.setAttribute('aria-label', '再聽一次');
  big.addEventListener('click', () => speak(display(w), w.audio));
  const prompt = el('p', 'prompt', '聽到的是哪個字？');
  box.append(big, prompt);
  card.appendChild(box);
  setTimeout(() => speak(display(w), w.audio), 250);
  const r = await send({ type: 'choice-options', key: item.key, dir: 'listen' });
  if (current !== item) return;
  if (r && r.ok && r.data) {
    item.options = r.data;
    optionButtons(card, r.data);
    card.appendChild(revealButtons('不確定，看答案'));
  } else {
    prompt.textContent = '聽到的是哪個字？什麼意思？';
    card.appendChild(revealButtons('看答案'));
  }
}

// 本句是哪個意思：從詞典意思中選一個；選完就對答案（自己判斷，不是只看答案）
async function renderSense(card, w) {
  const item = current;
  const ctx = senseContext(w);
  const r = ctx ? await send({ type: 'sense-options', word: w.lemma || w.key, answer: ctx.sense_zh }) : null;
  if (current !== item) return;   // 等待期間已換到下一張
  if (!r || !r.ok || !r.data) {   // 詞典裡找不到當時的意思：改出選擇題
    item.mode = 'choice';
    return render();
  }
  item.ctx = ctx;
  item.options = r.data;
  card.appendChild(headword(w));
  card.appendChild(sentenceNode(w, false, ctx));
  card.appendChild(el('p', 'ask', '這句話裡是哪個意思？'));
  optionButtons(card, r.data);
  card.appendChild(revealButtons('不確定，看答案'));
}

function chooseOption(i) {
  if (!current || revealed || !current.options) return;
  const ans = current.options.answer;
  document.querySelectorAll('.opt').forEach((b, j) => {
    b.disabled = true;
    if (j === ans) b.classList.add('ok');
    else if (j === i) b.classList.add('bad');
  });
  suggested = i === ans ? 'good' : 'again';
  reveal();
}

function speakBtn(w) {
  const b = el('button', 'icon', '🔊');
  b.title = '播放發音';
  b.setAttribute('aria-label', '播放發音');
  b.addEventListener('click', () => speak(display(w), w.audio));
  return b;
}

function markDiff(typed, target) {
  const d = el('div', 'diff');
  for (let i = 0; i < Math.max(typed.length, target.length); i++) {
    const ch = target[i] || '';
    const wrong = (typed[i] || '').toLowerCase() !== ch.toLowerCase();
    d.appendChild(wrong ? el('span', 'x', ch || '·') : document.createTextNode(ch));
  }
  return d;
}

function reveal(gaveUp = false) {
  if (!current || revealed) return;
  const w = current.word;
  const card = $('card');
  const btns = card.querySelector('.btns');
  if (current.mode === 'spell') {
    const input = $('spellInput');
    const typed = input.value.trim();
    if (!typed && !gaveUp) return input.focus();
    const ok = !!typed && answers(w).has(typed.toLowerCase());
    input.classList.add(ok ? 'ok' : 'bad');
    input.disabled = true;
    suggested = ok ? (current.hints ? 'hard' : 'good') : 'again';
    const v = el('p', 'verdict ' + (ok ? 'ok' : 'bad'), ok ? (current.hints ? '答對了（用了提示）' : '答對了！') : typed ? '拼錯了，紅色是不對的位置：' : '正確拼法：');
    card.insertBefore(v, btns);
    if (!ok) card.insertBefore(typed ? markDiff(typed, display(w)) : el('div', 'diff', display(w)), btns);
  } else if (current.options && suggested) {
    const ok = suggested === 'good';
    card.insertBefore(el('p', 'verdict ' + (ok ? 'ok' : 'bad'), ok ? '答對了！' : '不是這個，綠色才是正確答案。'), btns);
  } else if (current.options) {   // 不確定直接看答案：標出正確選項，建議「忘記」
    document.querySelectorAll('.opt').forEach((b, j) => { b.disabled = true; if (j === current.options.answer) b.classList.add('ok'); });
    suggested = 'again';
  }
  if (btns) btns.remove();
  revealed = true;

  const back = el('div', 'back');
  const c = current.ctx || (w.contexts || [])[0];
  const head = el('p', 'head');
  head.appendChild(el('b', null, display(w)));
  if (w.phonetic) head.appendChild(el('span', 'ph', w.phonetic));
  if (w.pos) head.appendChild(el('span', 'tag', w.pos));
  back.appendChild(head);
  const sense = ctxMeaning(c);
  if (sense) {
    back.appendChild(el('div', 'zhbig', '本句：' + sense));
    if (w.zh) back.appendChild(el('p', 'dict', '詞典：' + w.zh));
  } else {
    back.appendChild(el('div', 'zhbig', w.zh || '（沒有中文意思）'));
  }
  const note = contextNote(c, [sense, w.zh]);
  if (note) back.appendChild(el('p', null, note));
  if (current.mode === 'spell' || current.mode === 'listen' || (current.mode === 'choice' && current.dir === 'zh2en')) {
    const s = sentenceNode(w, false, c);
    if (s) back.appendChild(s);
  }
  const zh = sentenceZh(w, c);
  if (zh) back.appendChild(el('p', 'muted', zh));
  if (w.en_def) back.appendChild(el('p', 'muted', w.en_def));
  card.appendChild(back);
  if (current.mode !== 'listen') speak(display(w), w.audio);

  const acts = el('div', 'actions');
  RATINGS.forEach((r, i) => {
    const b = el('button', 'rate ' + r.key + (suggested === r.key ? ' suggest' : ''));
    b.append((i + 1) + ' ' + r.label, el('small', null, practice ? (r.key === 'again' ? '這輪再練' : '') : r.tip));
    b.addEventListener('click', () => rate(r.key));
    acts.appendChild(b);
  });
  card.appendChild(acts);
  $('keys').textContent = (suggested ? 'Enter 用建議的評分　' : '') + '1 忘記、2 模糊、3 記得、4 很簡單';
}

async function rate(rating) {
  if (!current || !revealed) return;
  const item = current;
  current = null;
  session.done++;
  session.results.push({ word: item.word, rating });
  if (practice) {
    // 自由練習：不送出結果；忘記的字排到這一輪最後再練
    if (rating === 'again') queue.push({ ...item, hints: 0, options: null, dir: null });
    return next();
  }
  const r = await send({ type: 'review-answer', key: item.key, rating });
  if (rating === 'again') {
    queue.push({ ...item, hints: 0, options: null, dir: null, word: { ...item.word, level: r.ok ? r.data.level : item.word.level } });
  }
  next();
}

// 一輪結束：統計＋要多注意的字
function renderDone(card) {
  const d = el('div', 'done');
  const res = session ? session.results : [];
  if (!res.length) {
    d.appendChild(el('h2', null, practice ? '沒有符合的字' : '今天沒有要複習的字'));
    d.appendChild(el('p', 'muted', practice ? '換個範圍試試看。' : '想多練可以切到「自由練習」，不會影響排程。查到的新字加入生詞本後，會自動排進複習。'));
  } else {
    d.appendChild(el('h2', null, practice ? '這一輪練習完成了！' : '今天的複習完成了！'));
    // 同一個字可能練了好幾次：以最後一次為準，另外記下曾經忘記
    const last = new Map();
    const forgot = new Set();
    for (const r of res) {
      last.set(r.word.key, r);
      if (r.rating === 'again' || r.rating === 'hard') forgot.add(r.word.key);
    }
    const n = (k) => res.filter((r) => r.rating === k).length;
    const tally = el('div', 'tally');
    [['字數', last.size], ['記得', n('good') + n('easy')], ['模糊', n('hard')], ['忘記', n('again')]].forEach(([label, v]) => {
      const t = el('div');
      t.append(el('b', null, String(v)), el('span', null, label));
      tally.appendChild(t);
    });
    d.appendChild(tally);
    if (forgot.size) {
      d.appendChild(el('p', 'muted', '這幾個字要多注意：'));
      const ul = el('ul', 'weak');
      for (const k of forgot) {
        const w = last.get(k).word;
        const li = el('li');
        li.append(el('b', null, display(w)), '　' + (ctxMeaning((w.contexts || [])[0]) || w.zh || ''));
        ul.appendChild(li);
      }
      d.appendChild(ul);
    }
  }
  const row = el('div', 'btns');
  row.style.justifyContent = 'center';
  if (practice) {
    const again = el('button', 'btn', '再練一輪');
    again.addEventListener('click', loadQueue);
    const back = el('button', 'btn ghost', '回到今日複習');
    back.addEventListener('click', backToReview);
    row.append(again, back);
  } else {
    const p = el('button', 'btn', '自由練習');
    p.addEventListener('click', () => { setTab(true); startPractice(); });
    const again = el('button', 'btn ghost', '再檢查一次待複習');
    again.addEventListener('click', loadQueue);
    row.append(p, again);
  }
  [...row.children].forEach((b) => { b.style.flex = '0 1 auto'; });
  d.appendChild(row);
  card.appendChild(d);
}

document.addEventListener('keydown', (e) => {
  if (!current || e.metaKey || e.ctrlKey || e.altKey) return;
  const typing = document.activeElement && document.activeElement.id === 'spellInput' && !document.activeElement.disabled;
  if (!revealed) {
    if (current.options && /^[1-9]$/.test(e.key) && +e.key <= current.options.options.length) {
      chooseOption(+e.key - 1);
    } else if (current.mode === 'spell' && e.key === 'Escape') {
      reveal(true);
    } else if (current.mode === 'spell' && (e.key === '?' || e.key === '/')) {
      e.preventDefault();
      showHint();
    } else if (current.mode === 'listen' && (e.key === 'r' || e.key === 'R')) {
      speak(display(current.word), current.word.audio);
    } else if (e.key === 'Enter' || (e.key === ' ' && !typing)) {
      e.preventDefault();
      reveal();
    }
    return;
  }
  if (e.key === 'Enter' && suggested) {
    e.preventDefault();
    rate(suggested);
  } else if (['1', '2', '3', '4'].includes(e.key)) {
    rate(RATINGS[+e.key - 1].key);
  }
});

$('tabReview').addEventListener('click', backToReview);
$('tabPractice').addEventListener('click', () => { setTab(true); startPractice(); });
document.querySelectorAll('#scopes button').forEach((b) =>
  b.addEventListener('click', () => {
    practiceScope = b.dataset.scope;
    document.querySelectorAll('#scopes button').forEach((x) => x.setAttribute('aria-pressed', String(x === b)));
    if (practice) startPractice();
  })
);
$('practiceN').addEventListener('change', () => { if (practice) startPractice(); });
$('practiceStart').addEventListener('click', startPractice);

document.querySelectorAll('#modes button').forEach((b) =>
  b.addEventListener('click', async () => {
    fixedMode = b.dataset.mode;
    document.querySelectorAll('#modes button').forEach((x) => x.setAttribute('aria-pressed', String(x === b)));
    const { settings = {} } = await chrome.storage.local.get('settings');
    await chrome.storage.local.set({ settings: { ...settings, reviewMode: fixedMode } });
    loadQueue();
  })
);

chrome.storage.local.get('settings').then(({ settings = {} }) => {
  fixedMode = settings.reviewMode || 'auto';
  document.querySelectorAll('#modes button').forEach((x) => x.setAttribute('aria-pressed', String(x.dataset.mode === fixedMode)));
  loadQueue();
});

WLUtil.checkBuild();
WLUtil.loadContent(); // 在這一頁也能雙擊（iPad：點一下）單字查詢
