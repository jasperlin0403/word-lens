const $ = (id) => document.getElementById(id);
const { el, escapeRe, send, speak } = WLUtil;
const LEVEL_NAMES = ['新字', '認得', '學習中', '快熟了', '已掌握'];
const RATINGS = [
  { key: 'again', label: '忘記', tip: '約 10 分鐘後再練' },
  { key: 'hard', label: '模糊', tip: '熟悉度不變' },
  { key: 'good', label: '記得', tip: '熟悉度＋1' },
  { key: 'easy', label: '很簡單', tip: '熟悉度＋2' }
];
const KIND = { recognize: '看英文想中文', spell: '看中文拼英文', listen: '聽發音想字義' };

let queue = [];
let current = null;
let revealed = false;
let suggested = null;
let fixedMode = 'auto';
let practice = null; // 自由練習中：{ scope, n }；null 表示一般複習
let practiceScope = 'all';

const display = (w) => w.lemma || w.key;
const answers = (w) => new Set([w.key, w.lemma, ...(w.forms || [])].filter(Boolean).map((s) => s.toLowerCase()));

function sentenceNode(w, hide) {
  const c = (w.contexts || [])[0];
  if (!c || !c.sentence) return null;
  const box = el('div', 'sent');
  const forms = [...answers(w)].sort((a, b) => b.length - a.length).map(escapeRe);
  const m = forms.length ? new RegExp('\\b(?:' + forms.join('|') + ')\\w*', 'i').exec(c.sentence) : null;
  if (!m) box.textContent = c.sentence;
  else box.append(c.sentence.slice(0, m.index), hide ? el('b', null, '＿＿＿') : el('mark', null, m[0]), c.sentence.slice(m.index + m[0].length));
  return box;
}

async function refreshStats() {
  const r = await send({ type: 'review-stats' });
  if (!r.ok) return;
  $('sDue').textContent = r.data.due;
  $('sToday').textContent = r.data.today;
  $('sStreak').textContent = r.data.streak;
}

async function loadQueue() {
  const r = practice
    ? await send({ type: 'practice-pool', scope: practice.scope, n: practice.n, mode: fixedMode })
    : await send({ type: 'review-queue', limit: 30, mode: fixedMode });
  queue = r.ok ? r.data : [];
  next();
}

function startPractice() {
  practice = { scope: practiceScope, n: +$('practiceN').value };
  $('practiceBanner').hidden = false;
  loadQueue();
}

function stopPractice() {
  practice = null;
  $('practiceBanner').hidden = true;
  loadQueue();
}

function next() {
  if (!practice) refreshStats();
  current = queue.shift() || null;
  revealed = false;
  suggested = null;
  render();
}

function render() {
  const card = $('card');
  card.textContent = '';
  if (!current) {
    const d = el('div', 'done');
    if (practice) {
      d.appendChild(el('h2', null, '這一輪練習完成了！'));
      d.appendChild(el('p', 'muted', '練習結果不影響熟悉度與排程。'));
      const again = el('button', 'btn', '再練一輪');
      again.addEventListener('click', loadQueue);
      const back = el('button', 'btn ghost', '回到今日複習');
      back.style.marginLeft = '8px';
      back.addEventListener('click', stopPractice);
      d.append(again, back);
    } else {
      d.appendChild(el('h2', null, '今天的複習完成了！'));
      d.appendChild(el('p', 'muted', '想多練可以用上方的「自由練習」，不會影響排程。查到的新字加入生詞本後，也會自動排進複習。'));
      const again = el('button', 'btn ghost', '再檢查一次待複習');
      again.addEventListener('click', loadQueue);
      d.appendChild(again);
    }
    card.appendChild(d);
    return;
  }
  const w = current.word;
  const mode = current.mode;
  card.appendChild(el('div', 'kind', KIND[mode] + '　·　目前熟悉度：' + LEVEL_NAMES[(w.level || 1) - 1]));

  if (mode === 'recognize') {
    const h = el('div');
    h.appendChild(el('span', 'word', display(w)));
    if (w.phonetic) h.appendChild(el('span', 'ph', w.phonetic));
    h.appendChild(speakBtn(w));
    card.appendChild(h);
    const s = sentenceNode(w, false);
    if (s) card.appendChild(s);
  } else if (mode === 'listen') {
    const h = el('div');
    h.appendChild(el('span', 'muted', '仔細聽，想想是哪個字、什麼意思'));
    h.appendChild(speakBtn(w));
    card.appendChild(h);
    setTimeout(() => speak(display(w), w.audio), 250);
  } else {
    card.appendChild(el('div', 'zhbig', w.zh || '（沒有中文意思）'));
    if (w.pos) card.appendChild(el('div', 'muted', w.pos));
    const s = sentenceNode(w, true);
    if (s) card.appendChild(s);
    const box = el('div', 'spell');
    const input = el('input');
    input.id = 'spellInput';
    input.placeholder = '輸入英文單字後按 Enter';
    input.autocomplete = 'off';
    input.spellcheck = false;
    box.appendChild(input);
    card.appendChild(box);
    setTimeout(() => input.focus(), 50);
  }

  if (mode !== 'spell') {
    const b = el('button', 'btn reveal', '顯示答案（空白鍵）');
    b.id = 'revealBtn';
    b.addEventListener('click', reveal);
    card.appendChild(b);
  }
}

function speakBtn(w) {
  const b = el('button', 'icon', '🔊');
  b.title = '播放發音';
  b.setAttribute('aria-label', '播放發音');
  b.addEventListener('click', () => speak(display(w), w.audio));
  return b;
}

function markDiff(typed, target) {
  const d = el('div', 'diff');
  for (let i = 0; i < Math.max(typed.length, target.length); i++) {
    const ch = target[i] || '';
    const wrong = (typed[i] || '').toLowerCase() !== ch.toLowerCase();
    d.appendChild(wrong ? el('span', 'x', ch || '·') : document.createTextNode(ch));
  }
  return d;
}

function reveal() {
  if (!current || revealed) return;
  const w = current.word;
  const card = $('card');
  if (current.mode === 'spell') {
    const input = $('spellInput');
    const typed = input.value.trim();
    if (!typed) return;
    const ok = answers(w).has(typed.toLowerCase());
    input.classList.add(ok ? 'ok' : 'bad');
    input.disabled = true;
    suggested = ok ? 'good' : 'again';
    if (!ok) {
      card.appendChild(el('div', 'muted', '正確拼法（紅色底線是拼錯的位置）：'));
      card.appendChild(markDiff(typed, display(w)));
    }
  } else {
    const rb = $('revealBtn');
    if (rb) rb.remove();
  }
  revealed = true;

  const back = el('div', 'back');
  const top = el('p');
  top.appendChild(el('b', null, display(w)));
  if (w.phonetic) top.appendChild(el('span', 'ph', w.phonetic));
  if (w.pos) top.appendChild(el('span', 'lvl', w.pos));
  back.appendChild(top);
  back.appendChild(el('div', 'zhbig', w.zh || '（沒有中文意思）'));
  const c = (w.contexts || [])[0];
  if (c && c.context_zh) back.appendChild(el('p', null, '在原句中：' + c.context_zh));
  if (current.mode !== 'recognize') {
    const s = sentenceNode(w, false);
    if (s) back.appendChild(s);
  }
  if (c && c.sentence_zh) back.appendChild(el('p', 'muted', c.sentence_zh));
  if (w.en_def) back.appendChild(el('p', 'muted', w.en_def));
  card.appendChild(back);
  if (current.mode !== 'listen') speak(display(w), w.audio);

  const acts = el('div', 'actions');
  RATINGS.forEach((r, i) => {
    const b = el('button', 'rate ' + r.key + (suggested === r.key ? ' suggest' : ''));
    b.append((i + 1) + ' ' + r.label, el('small', null, r.tip));
    b.addEventListener('click', () => rate(r.key));
    acts.appendChild(b);
  });
  card.appendChild(acts);
}

async function rate(rating) {
  if (!current || !revealed) return;
  const item = current;
  current = null;
  if (practice) {
    // 自由練習：不送出結果；忘記的字排到這一輪最後再練
    if (rating === 'again') queue.push(item);
    return next();
  }
  const r = await send({ type: 'review-answer', key: item.key, rating });
  if (rating === 'again') {
    // 忘記的字排到這一輪最後再練一次
    queue.push({ ...item, word: { ...item.word, level: r.ok ? r.data.level : item.word.level } });
  }
  next();
}

document.addEventListener('keydown', (e) => {
  if (!current) return;
  const typing = document.activeElement && document.activeElement.id === 'spellInput' && !document.activeElement.disabled;
  if ((e.key === 'Enter' || (e.key === ' ' && !typing)) && !revealed) {
    e.preventDefault();
    reveal();
  } else if (revealed && e.key === 'Enter' && suggested) {
    e.preventDefault();
    rate(suggested);
  } else if (revealed && !typing && ['1', '2', '3', '4'].includes(e.key)) {
    rate(RATINGS[+e.key - 1].key);
  }
});

document.querySelectorAll('.scopes button').forEach((b) =>
  b.addEventListener('click', () => {
    practiceScope = b.dataset.scope;
    document.querySelectorAll('.scopes button').forEach((x) => x.setAttribute('aria-pressed', String(x === b)));
  })
);
$('practiceStart').addEventListener('click', startPractice);
$('practiceStop').addEventListener('click', stopPractice);

document.querySelectorAll('.modes button').forEach((b) =>
  b.addEventListener('click', async () => {
    fixedMode = b.dataset.mode;
    document.querySelectorAll('.modes button').forEach((x) => x.setAttribute('aria-pressed', String(x === b)));
    const { settings = {} } = await chrome.storage.local.get('settings');
    await chrome.storage.local.set({ settings: { ...settings, reviewMode: fixedMode } });
    loadQueue();
  })
);

chrome.storage.local.get('settings').then(({ settings = {} }) => {
  fixedMode = settings.reviewMode || 'auto';
  document.querySelectorAll('.modes button').forEach((x) => x.setAttribute('aria-pressed', String(x.dataset.mode === fixedMode)));
  loadQueue();
});

WLUtil.checkBuild();
WLUtil.loadContent(); // 在這一頁也能雙擊（iPad：點一下）單字查詢
