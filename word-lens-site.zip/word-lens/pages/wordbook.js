const $ = (id) => document.getElementById(id);
const { el, escapeRe, send } = WLUtil;
let words = {};
let stats = {};
const LEVEL_NAMES = ['新字', '認得', '學習中', '快熟了', '已掌握'];
const levelOf = (v) => v.level || 1;
const lookupsOf = (v) => Math.max((stats[v.key] && stats[v.key].lookups) || 0, v.lookups || 0, 1);

function setStatus(t, kind) {
  $('status').textContent = t;
  $('status').className = 'status' + (kind ? ' ' + kind : '');
}

function display(v) {
  return v.lemma || v.key;
}

function fmtDate(iso) {
  if (!iso) return '';
  const d = new Date(iso);
  if (isNaN(d)) return '';
  return d.getFullYear() + '/' + (d.getMonth() + 1) + '/' + d.getDate();
}

const speak = (v) => WLUtil.speak(display(v), v.audio);

function markSentence(sentence, forms) {
  const span = el('div', 'en');
  const list = (forms || []).filter(Boolean).sort((a, b) => b.length - a.length).map(escapeRe);
  const m = list.length ? new RegExp('\\b(?:' + list.join('|') + ')\\w*', 'i').exec(sentence) : null;
  if (!m) {
    span.textContent = sentence;
    return span;
  }
  span.append(sentence.slice(0, m.index), el('mark', null, m[0]), sentence.slice(m.index + m[0].length));
  return span;
}

function ctxBlock(c, v) {
  const box = el('div', 'ctx');
  box.appendChild(markSentence(c.sentence, [...(v.forms || []), v.key]));
  if (c.context_zh) box.appendChild(el('div', null, c.context_zh));
  if (c.sentence_zh) box.appendChild(el('div', 'muted', c.sentence_zh));
  if (c.url) {
    const src = el('div', 'src');
    const a = el('a', null, c.title || c.url);
    a.href = c.url;
    a.target = '_blank';
    a.rel = 'noopener';
    src.append('出處：', a, c.date ? '　' + fmtDate(c.date) : '');
    box.appendChild(src);
  }
  return box;
}

function sorted() {
  const q = $('q').value.trim().toLowerCase();
  let arr = Object.values(words);
  if (q) {
    arr = arr.filter((v) =>
      [v.key, v.lemma, v.zh, ...(v.forms || [])].filter(Boolean).some((s) => String(s).toLowerCase().includes(q))
    );
  }
  const lf = $('lvFilter').value;
  if (lf) arr = arr.filter((v) => String(levelOf(v)) === lf);
  const mode = $('sort').value;
  if (mode === 'alpha') arr.sort((a, b) => display(a).localeCompare(display(b)));
  else if (mode === 'lookups') arr.sort((a, b) => lookupsOf(b) - lookupsOf(a));
  else if (mode === 'level') arr.sort((a, b) => levelOf(a) - levelOf(b));
  else arr.sort((a, b) => String(b.addedAt || '').localeCompare(String(a.addedAt || '')));
  return arr;
}

function render() {
  $('total').textContent = Object.keys(words).length;
  const list = $('list');
  list.textContent = '';
  const arr = sorted();
  if (!arr.length) {
    list.appendChild(
      el('div', 'empty', Object.keys(words).length ? '找不到符合的字。' : '生詞本還是空的。到英文網頁雙擊一個單字，按「加入生詞本」開始收集吧。')
    );
    return;
  }
  for (const v of arr) {
    const item = el('div', 'item');

    const left = el('div');
    left.appendChild(el('div', 'w', display(v)));
    if (v.phonetic) left.appendChild(el('div', 'ph', v.phonetic));
    if (v.phrase) left.appendChild(el('div', 'ph', '片語：' + v.phrase));

    const mid = el('div');
    const line = el('div');
    if (v.pos) line.appendChild(el('span', 'pos', v.pos));
    line.appendChild(el('span', 'zh', v.zh || '（無中文意思）'));
    mid.appendChild(line);
    if (v.en_def) mid.appendChild(el('div', 'endef', v.en_def));
    const ctxs = v.contexts || [];
    if (ctxs[0]) mid.appendChild(ctxBlock(ctxs[0], v));
    if (ctxs.length > 1) {
      const d = el('details');
      d.appendChild(el('summary', null, '其他 ' + (ctxs.length - 1) + ' 個例句'));
      ctxs.slice(1).forEach((c) => d.appendChild(ctxBlock(c, v)));
      mid.appendChild(d);
    }

    const side = el('div', 'side');
    const sel = el('select', 'lvsel');
    sel.setAttribute('aria-label', '熟悉度');
    LEVEL_NAMES.forEach((n, i) => sel.appendChild(new Option(n, String(i + 1))));
    sel.value = String(levelOf(v));
    sel.addEventListener('change', () => send({ type: 'set-level', word: v.key, level: +sel.value }));
    side.appendChild(sel);
    const s = el('button', 'icon', '🔊');
    s.title = '發音';
    s.setAttribute('aria-label', '發音 ' + display(v));
    s.addEventListener('click', () => speak(v));
    side.appendChild(s);
    side.appendChild(el('div', 'n', '查過 ' + lookupsOf(v) + ' 次'));
    side.appendChild(el('div', 'n', fmtDate(v.addedAt) + ' 加入'));
    const del = el('button', 'del', '刪除');
    del.addEventListener('click', async () => {
      if (!confirm('確定要從生詞本刪除「' + display(v) + '」嗎？')) return;
      const { words: cur = {} } = await chrome.storage.local.get('words');
      delete cur[v.key];
      await chrome.storage.local.set({ words: cur });
    });
    side.appendChild(del);

    item.append(left, mid, side);
    list.appendChild(item);
  }
}

// ---------- 匯出 ----------
function download(name, content, type) {
  const blob = new Blob([content], { type });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = name;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 2000);
}

function today() {
  const d = new Date();
  return d.getFullYear() + String(d.getMonth() + 1).padStart(2, '0') + String(d.getDate()).padStart(2, '0');
}

function csvCell(v) {
  const s = String(v == null ? '' : v);
  return '"' + s.replace(/"/g, '""') + '"';
}

$('csv').addEventListener('click', () => {
  const arr = sorted();
  if (!arr.length) return setStatus('沒有可以匯出的字。', 'err');
  const head = ['單字', '音標', '詞性', '中文意思', '片語', '英英解釋', '字典例句', '本句意思', '原文例句', '例句翻譯', '出處網址', '加入日期', '查詢次數', '熟悉度'];
  const rows = [head.map(csvCell).join(',')];
  for (const v of arr) {
    const c = (v.contexts || [])[0] || {};
    rows.push(
      [display(v), v.phonetic, v.pos, v.zh, v.phrase, v.en_def, v.en_example, c.context_zh, c.sentence, c.sentence_zh, c.url, fmtDate(v.addedAt), lookupsOf(v), LEVEL_NAMES[levelOf(v) - 1]]
        .map(csvCell)
        .join(',')
    );
  }
  // 開頭加 BOM，Excel 開啟時中文才不會變亂碼
  download('生詞本_' + today() + '.csv', '\uFEFF' + rows.join('\r\n'), 'text/csv;charset=utf-8');
  setStatus('已匯出 ' + arr.length + ' 個字（CSV，可用 Excel 開啟）。', 'ok');
});

function h(s) {
  return String(s == null ? '' : s)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/[\t\r\n]+/g, ' ');
}

$('anki').addEventListener('click', () => {
  const arr = sorted();
  if (!arr.length) return setStatus('沒有可以匯出的字。', 'err');
  const lines = ['#separator:tab', '#html:true', '#columns:Front\tBack'];
  for (const v of arr) {
    const c = (v.contexts || [])[0] || {};
    let front = '<b style="font-size:1.4em">' + h(display(v)) + '</b>';
    if (c.sentence) {
      const forms = [...(v.forms || []), v.key].filter(Boolean).sort((a, b) => b.length - a.length).map(escapeRe);
      const re = new RegExp('\\b(?:' + forms.join('|') + ')\\w*', 'i');
      const esc = h(c.sentence);
      front += '<br><br><i>' + esc.replace(re, (m) => '<u>' + m + '</u>') + '</i>';
    }
    const back = [
      v.phonetic ? h(v.phonetic) : '',
      (v.pos ? '【' + h(v.pos) + '】' : '') + '<b>' + h(v.zh) + '</b>',
      v.phrase ? '片語：' + h(v.phrase) : '',
      c.context_zh ? '本句：' + h(c.context_zh) : '',
      c.sentence_zh ? h(c.sentence_zh) : '',
      v.en_def ? '<span style="color:#666">' + h(v.en_def) + '</span>' : ''
    ]
      .filter(Boolean)
      .join('<br>');
    lines.push(front + '\t' + back);
  }
  download('生詞本_Anki_' + today() + '.txt', lines.join('\n'), 'text/plain;charset=utf-8');
  setStatus('已匯出 ' + arr.length + ' 張 Anki 卡片。在 Anki 選「檔案 → 匯入」選擇此檔即可。', 'ok');
});

$('json').addEventListener('click', async () => {
  const n = Object.keys(words).length;
  if (!n) return setStatus('生詞本是空的。', 'err');
  const withStats = {};
  for (const [k, v] of Object.entries(words)) withStats[k] = { ...v, lookups: lookupsOf(v) };
  const srs = await send({ type: 'export-srs' });
  download('生詞本備份_' + today() + '.json', JSON.stringify({ app: 'word-lens', version: 3, words: withStats, srs: srs.ok ? srs.data : {} }, null, 2), 'application/json');
  await chrome.storage.local.set({ lastBackup: Date.now() });
  setStatus('已備份 ' + n + ' 個字。移除擴充功能前，請先備份！', 'ok');
});

$('importBtn').addEventListener('click', () => $('importFile').click());
$('importFile').addEventListener('change', async (e) => {
  const file = e.target.files[0];
  e.target.value = '';
  if (!file) return;
  try {
    const data = JSON.parse(await file.text());
    const incoming = data && data.words;
    if (!incoming || typeof incoming !== 'object') throw new Error('格式不符');
    const { words: cur = {} } = await chrome.storage.local.get('words');
    let added = 0;
    let merged = 0;
    for (const [k, v] of Object.entries(incoming)) {
      if (!v || typeof v !== 'object') continue;
      if (!cur[k]) {
        cur[k] = { ...v, key: k };
        added++;
      } else {
        const ctx = [...(cur[k].contexts || [])];
        for (const c of v.contexts || []) if (c && c.sentence && !ctx.some((x) => x.sentence === c.sentence)) ctx.push(c);
        cur[k].contexts = ctx.slice(0, 5);
        cur[k].forms = [...new Set([...(cur[k].forms || []), ...(v.forms || [])])];
        cur[k].lookups = Math.max(cur[k].lookups || 1, v.lookups || 1);
        if (v.level && data.srs && data.srs[k]) cur[k].level = v.level; // 有複習紀錄的備份：熟悉度以備份為準
        merged++;
      }
    }
    await chrome.storage.local.set({ words: cur });
    // 版本 3 以上的備份含複習排程：一併還原（以較新的紀錄為準）
    const n = data.srs ? await send({ type: 'import-srs', srs: data.srs }) : null;
    setStatus('還原完成：新增 ' + added + ' 個字，合併 ' + merged + ' 個已存在的字' + (n && n.ok ? '，更新 ' + n.data + ' 筆複習進度' : '') + '。', 'ok');
  } catch (err) {
    setStatus('無法讀取這個檔案，請選擇本工具匯出的 JSON 備份檔。', 'err');
  }
});

$('clear').addEventListener('click', async () => {
  const n = Object.keys(words).length;
  if (!n) return;
  if (!confirm('確定要清空全部 ' + n + ' 個字嗎？建議先按「備份（JSON）」。此動作無法復原。')) return;
  await chrome.storage.local.set({ words: {} });
  setStatus('生詞本已清空。', 'ok');
});

$('q').addEventListener('input', render);
$('lvFilter').addEventListener('change', render);
$('reviewBtn').addEventListener('click', () => send({ type: 'open-review' }));
$('sort').addEventListener('change', render);

chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local' && changes.words) {
    words = changes.words.newValue || {};
    render();
  }
});

Promise.all([chrome.storage.local.get('words'), send({ type: 'stats-all' })]).then(([{ words: w = {} }, st]) => {
  words = w;
  stats = st.ok ? st.data : {};
  render();
});

WLUtil.checkBuild();
WLUtil.loadContent(); // 在這一頁也能雙擊（iPad：點一下）單字查詢
