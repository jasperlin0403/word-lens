// 使用教學：5 步引導；查字、加入生詞本等小任務由 chrome.storage 的變化自動打勾
const $ = (id) => document.getElementById(id);
const { send } = WLUtil;
const WEB = !!globalThis.WL_WEB;
const STEPS = 5;
const SURVEY_END = Date.UTC(2026, 10, 30, 15, 59);
let step = 1;
let startWords = null; // 進到第 4 步時生詞本的字數，用來判斷有沒有新加入

// 擴充功能與網頁版的操作不同：雙擊／按住 Ctrl vs 點一下
document.querySelectorAll('.ext-only').forEach((e) => { e.hidden = WEB; });
document.querySelectorAll('.web-only').forEach((e) => { e.hidden = !WEB; });
$('survey').hidden = Date.now() > SURVEY_END;

const dots = $('dots');
for (let i = 1; i <= STEPS; i++) {
  const b = document.createElement('button');
  b.setAttribute('aria-label', '第 ' + i + ' 步');
  b.addEventListener('click', () => go(i));
  dots.appendChild(b);
}

function mark(id, ok) {
  $(id).classList.toggle('ok', !!ok);
}

function go(n) {
  step = Math.min(STEPS, Math.max(1, n));
  document.querySelectorAll('.step').forEach((s) => { s.hidden = +s.dataset.step !== step; });
  [...dots.children].forEach((b, i) => {
    b.classList.toggle('on', i + 1 === step);
    b.classList.toggle('done', i + 1 < step);
  });
  $('stepno').textContent = '第 ' + step + ' 步，共 ' + STEPS + ' 步';
  $('prev').hidden = step === 1;
  $('next').textContent = step === 1 ? '開始（約 2 分鐘）' : step === STEPS ? '完成，開始使用' : step === 3 && !$('tKey').classList.contains('ok') ? '先略過' : '下一步';
  if (step === 4 && startWords === null) chrome.storage.local.get('words').then(({ words = {} }) => { startWords = Object.keys(words).length; });
  chrome.storage.local.set({ onboarding: { step, t: Date.now() } });
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

async function finish() {
  await chrome.storage.local.set({ onboarding: { done: Date.now(), step: STEPS } });
  if (WEB) location.href = chrome.runtime.getURL('index.html');
  else chrome.tabs.getCurrent((t) => (t ? chrome.tabs.remove(t.id) : window.close()));
}

// ---------- 任務偵測 ----------
// 查字卡每查一次會更新 tips.last（content/cards.js），這裡依字和觸發方式打勾
chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== 'local') return;
  if (changes.tips && changes.tips.newValue) {
    const last = changes.tips.newValue.last || {};
    if (last.word === 'stick') mark('tDbl', true);
    if (last.word === 'address' && last.via === 'ctrl') mark('tCtrl', true);
  }
  if (changes.words && step === 4 && startWords !== null) {
    const words = changes.words.newValue || {};
    if (words.striking || Object.keys(words).length > startWords) mark('tSave', true);
  }
});

// ---------- 金鑰 ----------
async function keyState() {
  const r = await send({ type: 'key-status' });
  const set = r.ok && r.data.set;
  mark('tKey', set);
  if (set) $('keyStatus').textContent = '目前已設定金鑰（' + r.data.masked + '）。要更換可以再貼一次。';
  if (step === 3) go(3);
}

$('saveKey').addEventListener('click', async () => {
  const key = $('key').value.trim();
  if (!key) { $('key').focus(); return; }
  $('saveKey').disabled = true;
  $('keyStatus').className = 'status';
  $('keyStatus').textContent = '儲存中，正在測試連線…';
  await send({ type: 'set-key', key });
  $('key').value = '';
  const r = await send({ type: 'test' });
  $('saveKey').disabled = false;
  if (r.ok) {
    $('keyStatus').className = 'status ok';
    $('keyStatus').textContent = '連線成功！回到第 2 步再查一次 stick，就會看到「本句用的是…」。';
    mark('tKey', true);
    go(3);
  } else {
    $('keyStatus').className = 'status err';
    $('keyStatus').textContent = '測試失敗：' + r.error.message + '　請確認金鑰是否完整複製。';
  }
});

$('openBook').addEventListener('click', () => (WEB ? (location.href = chrome.runtime.getURL('pages/wordbook.html')) : send({ type: 'open-wordbook' })));
$('openReview').addEventListener('click', () => (WEB ? (location.href = chrome.runtime.getURL('pages/review.html')) : send({ type: 'open-review' })));
$('surveyBtn').addEventListener('click', async () => {
  const { tips = {} } = await chrome.storage.local.get('tips');
  chrome.storage.local.set({ tips: { ...tips, surveyDone: Date.now() } });
});

$('prev').addEventListener('click', () => go(step - 1));
$('next').addEventListener('click', () => (step === STEPS ? finish() : go(step + 1)));
$('skipAll').addEventListener('click', finish);

chrome.storage.local.get('onboarding').then(({ onboarding = {} }) => {
  go(!onboarding.done && onboarding.step ? onboarding.step : 1);
  keyState();
});

WLUtil.loadContent(); // 教學頁本身也能查字（第 2、4 步的任務）
