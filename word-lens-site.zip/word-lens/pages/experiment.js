// 研究模式：執行 M0／M1／M2／M2D 四種方法，記錄準確率與回應時間
// 每一題完成就自動存檔（chrome.storage.local），關掉頁面也不會遺失，可以接續上一輪
const $ = (id) => document.getElementById(id);
const { el, send } = WLUtil;

let DATA = null;       // 自建測試集
let WIC = null;        // WiC 資料（使用者選擇檔案後載入）
let rows = [];         // 目前這一輪的結果
let run = null;        // 目前這一輪（含設定、環境資訊、rows），存檔單位
let running = false;

const RUNS_KEY = 'researchRuns';
const RUNS_MAX = 40;   // 最多保留幾輪，超過時刪最舊的
const DEVICE_KEY = 'wl-research-device';

const median = (a) => { if (!a.length) return null; const s = [...a].sort((x, y) => x - y); const m = s.length >> 1; return s.length % 2 ? s[m] : (s[m - 1] + s[m]) / 2; };
const pct = (a, p) => { if (!a.length) return null; const s = [...a].sort((x, y) => x - y); return s[Math.min(s.length - 1, Math.floor(s.length * p))]; };
const fmtTime = (t) => new Date(t).toLocaleString('zh-TW', { hour12: false });

async function loadData() {
  const r = await fetch(chrome.runtime.getURL('research/efl_set.json'));
  DATA = await r.json();
  $('hint').textContent = '自建測試集：' + DATA.items.length + ' 題，' + Object.keys(DATA.senses).length + ' 個字';
}

async function loadWic() {
  if (!WIC) {
    const r = await fetch(chrome.runtime.getURL('research/wic_dev.json'));
    WIC = await r.json();
  }
  // 類別比例直接由資料算出，不寫死：若資料不是完整的 638 題，比例會跟著變，報告才不會寫錯
  const same = WIC.items.filter((x) => x.gold === 1).length;
  const diff = WIC.items.length - same;
  $('hint').textContent = 'WiC 驗證集：' + WIC.items.length + ' 題（相同意思 ' + same
    + ' 題、不同意思 ' + diff + ' 題；候選詞義取自 WordNet）';
  return WIC;
}

// ---------- 執行環境（寫進每一輪的存檔，報告的「執行環境」直接引用） ----------
async function collectEnv() {
  const env = {
    userAgent: navigator.userAgent,
    language: navigator.language,
    timeZone: Intl.DateTimeFormat().resolvedOptions().timeZone,
    cpuCores: navigator.hardwareConcurrency || null,
    memoryGB: navigator.deviceMemory || null,
    extensionVersion: chrome.runtime.getManifest().version,
    webVersion: !!globalThis.WL_WEB,
    device: $('device').value.trim()   // 電腦機型瀏覽器讀不到，由使用者填寫
  };
  const uad = navigator.userAgentData;
  if (uad && uad.getHighEntropyValues) {
    try {
      const h = await uad.getHighEntropyValues(['platform', 'platformVersion', 'architecture', 'fullVersionList']);
      env.os = h.platform + ' ' + h.platformVersion;
      env.arch = h.architecture;
      env.browser = (h.fullVersionList || []).filter((b) => !/not.?a.?brand/i.test(b.brand)).map((b) => b.brand + ' ' + b.version).join(', ');
    } catch (e) { /* 部分瀏覽器不提供，保留 userAgent 即可 */ }
  }
  const chain = await send({ type: 'model-chain' });
  if (chain.ok) env.modelChain = chain.data;
  return env;
}

function envText(env) {
  if (!env) return '';
  return [env.device || '（未填電腦機型）', env.os || '', env.arch || '', env.browser || env.userAgent,
    '擴充功能 v' + env.extensionVersion, env.modelChain ? '模型 ' + env.modelChain[0] : ''].filter(Boolean).join('｜');
}

// ---------- 自動存檔 ----------
async function loadRuns() {
  const o = await chrome.storage.local.get(RUNS_KEY);
  return o[RUNS_KEY] || {};
}

// 存檔排隊執行，避免兩次寫入互相覆蓋
let saveChain = Promise.resolve();
let saveTimer = null;
function saveSoon() {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(saveNow, 300);
}
function saveNow() {
  clearTimeout(saveTimer);
  if (!run) return saveChain;
  run.rows = rows;
  run.updated = Date.now();
  const snapshot = JSON.parse(JSON.stringify(run));
  saveChain = saveChain.then(async () => {
    const all = await loadRuns();
    all[snapshot.id] = snapshot;
    const ids = Object.keys(all).sort((a, b) => all[a].created - all[b].created);
    while (ids.length > RUNS_MAX) delete all[ids.shift()];
    await chrome.storage.local.set({ [RUNS_KEY]: all });
    $('saved').textContent = '已自動存檔（' + fmtTime(snapshot.updated) + '）';
  }).catch((e) => {
    $('saved').textContent = '⚠ 自動存檔失敗：' + (e && e.message ? e.message : e) + '，請先匯出 CSV／JSON';
  });
  return saveChain;
}

// ---------- 候選順序（測順序偏差用） ----------
// orig：資料檔順序；shuffle：依種子打亂（同一個種子、同一題永遠得到相同順序，可重現）；reverse：反轉
const ORDER_NAME = { orig: '原順序', shuffle: '打亂', reverse: '反轉' };
function mulberry32(a) {
  return () => {
    a = (a + 0x6D2B79F5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
// 回傳 perm：perm[顯示位置] = 原本的索引（都從 0 起算）
function orderFor(n, mode, seed, itemId) {
  const perm = [...Array(n).keys()];
  if (mode === 'reverse') return perm.reverse();
  if (mode !== 'shuffle') return perm;
  const rand = mulberry32(((seed | 0) * 100003 + itemId) >>> 0);
  for (let i = n - 1; i > 0; i--) {
    const j = Math.floor(rand() * (i + 1));
    [perm[i], perm[j]] = [perm[j], perm[i]];
  }
  return perm;
}
// 模型回答的「顯示位置」（1 起算）→ 原本的詞義編號（1 起算）；超出範圍回傳 null
const toOrig = (perm, shown) => (shown >= 1 && shown <= perm.length ? perm[shown - 1] + 1 : null);
const orderInfo = (perm, gold) => (run && run.order && run.order !== 'orig'
  ? { order: perm.map((i) => i + 1), goldPos: perm.indexOf(gold - 1) + 1 } : {});
const orderLabel = (r) => (r.order && r.order !== 'orig' ? ORDER_NAME[r.order] + (r.order === 'shuffle' ? '#' + r.seed : '') : '');

const STATUS = { running: '執行中', done: '完成', stopped: '已停止', interrupted: '中斷（可接續）', quota: '額度用完（可接續）' };
const METHOD_NAME = { M0: 'M0 詞典第一義', M1: 'M1 自由解釋', M2: 'M2 候選挑選', M2D: 'M2D 正式查字（選義＋解釋）' };

async function refreshRunList(selectId) {
  const all = await loadRuns();
  const list = Object.values(all).sort((a, b) => b.created - a.created);
  const sel = $('runs');
  sel.textContent = '';
  if (!list.length) sel.appendChild(new Option('（還沒有存檔）', ''));
  for (const r of list) {
    const label = fmtTime(r.created) + '　' + (r.dataset === 'wic' ? 'WiC' : '自建集') + '　'
      + (METHOD_NAME[r.method] || r.method) + (orderLabel(r) ? '（' + orderLabel(r) + '）' : '') + '　' + (r.rows || []).length + '/' + r.planned + ' 題　' + (STATUS[r.status] || r.status);
    sel.appendChild(new Option(label, r.id));
  }
  if (selectId) sel.value = selectId;
  return all;
}

function showRun(r) {
  run = r;
  rows = r.rows || [];
  $('dataset').value = r.dataset;
  $('method').value = r.method;
  $('limit').value = r.limit;
  $('order').value = r.order || 'orig';
  $('seed').value = r.seed || 1;
  $('tbl').querySelector('tbody').textContent = '';
  rows.forEach(addRow);
  refresh();
  $('envLine').textContent = envText(r.env);
  $('saved').textContent = '已載入存檔（' + fmtTime(r.updated || r.created) + '）';
  $('resume').disabled = running || !canResume(r);
}

const canResume = (r) => !!r && r.status !== 'done' && r.status !== 'running'
  && (r.rows.length < r.planned || r.rows.some((x) => x.failed));

// ---------- WiC：判斷同一個字在兩個句子中是否為相同意思 ----------
function promptWicM1(it) {
  return ['Decide whether the target word has the SAME meaning in the two sentences.',
    'Target word: ' + it.word, 'Sentence 1: ' + it.s1, 'Sentence 2: ' + it.s2,
    'Reply with JSON only: {"same": true or false}'].join('\n');
}

// M2 一次只看一個句子：模型看不到另一句，才是獨立的詞義判斷，而不是直接比較兩句
function promptWicM2One(it, sentence, senses) {
  const list = senses.map((d, i) => (i + 1) + '. ' + d).join('\n');
  return ['Choose the sense of the target word as it is used in the sentence.',
    'Target word: ' + it.word, 'Sentence: ' + sentence,
    'Senses:', list,
    'Reply with JSON only: {"choice": number}'].join('\n');
}

const sleep = (ms) => new Promise((res) => setTimeout(res, ms));

async function runWic(it, method, gap) {
  const base = { id: it.id, word: it.word, sentence: it.s1 + ' ｜ ' + it.s2, gold: it.gold,
    goldText: it.gold ? '相同意思' : '不同意思', options: [{ zh: '不同意思' }, { zh: '相同意思' }],
    correct: null, needReview: false, pred: null, predText: '', ms: 0, calls: 0, model: '', at: Date.now() };
  if (method === 'M0') {                       // 詞典第一義：兩句都取第一義 → 永遠回答「相同」
    return { ...base, pred: 2, predText: '相同意思（第一義必定相同）', correct: it.gold === 1 };
  }
  if (method === 'M1') {
    const r = await send({ type: 'research-call', prompt: promptWicM1(it) });
    if (!r.ok) throw new Error(r.error.message);
    const d = r.data.data || {};
    const meta = { ms: r.data.ms, calls: 1, model: r.data.model };
    if (d.same !== true && d.same !== false && d.same !== 'true' && d.same !== 'false') {
      return { ...base, ...meta, predText: '回答無法判讀：' + JSON.stringify(d).slice(0, 60), needReview: true };
    }
    const same = d.same === true || d.same === 'true';
    return { ...base, ...meta, pred: same ? 2 : 1, predText: same ? '相同意思' : '不同意思',
      correct: (same ? 1 : 0) === it.gold };
  }
  // M2：兩句各呼叫一次，再比對選到的詞義編號是否相同（完全程式判定，不需評審）
  // 兩句用同一個候選順序；比對的是換回原本編號後的詞義
  const perm = orderFor(it.senses.length, run.order, run.seed, it.id);
  const shown = perm.map((i) => it.senses[i]);
  const pick = async (sentence) => {
    const r = await send({ type: 'research-call', prompt: promptWicM2One(it, sentence, shown) });
    if (!r.ok) throw new Error(r.error.message);
    const n = toOrig(perm, parseInt((r.data.data || {}).choice, 10));
    return { n, ms: r.data.ms, model: r.data.model };
  };
  const a = await pick(it.s1);
  if (gap) await sleep(gap);
  const b = await pick(it.s2);
  const meta = { ms: a.ms + b.ms, calls: 2, model: a.model === b.model ? a.model : a.model + '/' + b.model,
    ...(run.order && run.order !== 'orig' ? { order: perm.map((i) => i + 1) } : {}) };
  if (a.n === null || b.n === null) {           // 任一句的選項超出範圍：標記待確認，不當成「不同意思」
    return { ...base, ...meta, predText: '選項無法判讀（' + a.n + ' vs ' + b.n + '）', needReview: true };
  }
  const same = a.n === b.n;
  return { ...base, ...meta, pred: same ? 2 : 1, predText: (same ? '相同意思' : '不同意思') + '（' + a.n + ' vs ' + b.n + '）',
    correct: (same ? 1 : 0) === it.gold };
}

// ---------- 自建測試集的方法 ----------
function promptM1(word, sentence) {
  return [
    '你是一位英文老師，學生的母語是繁體中文（台灣）。',
    '請判斷這個英文單字在下面這個句子中的意思，並用最簡短的繁體中文詞語表達（不要解釋、不要加句號）。',
    '單字：' + word,
    '句子：' + sentence,
    '只回傳 JSON：{"zh": "這個字在本句中的中文意思（最多 8 個字）"}'
  ].join('\n');
}

function promptM2(word, sentence, options) {
  const list = options.map((o, i) => (i + 1) + '. ' + o.zh + (o.en ? '（' + o.en + '）' : '')).join('\n');
  return [
    '你是一位英文老師。以下是某個英文單字的候選中文意思，請根據句子挑出最合適的一個。',
    '單字：' + word,
    '句子：' + sentence,
    '候選意思：',
    list,
    '只回傳 JSON：{"choice": 選項編號（數字）, "why": "簡短理由（繁體中文，20 字內）"}'
  ].join('\n');
}

// M1 的自由文字答案 → 對應到候選詞義（字元重疊度）；不明確時標記待確認
function matchSense(zh, senses) {
  const clean = (s) => String(s || '').replace(/[（(].*?[)）]/g, '');
  const target = new Set(clean(zh));
  let best = 0, bestScore = -1, second = -1;
  senses.forEach((s, i) => {
    const overlap = [...new Set(clean(s))].filter((c) => target.has(c)).length;
    const score = overlap / Math.max(1, new Set(clean(s)).size);
    if (score > bestScore) { second = bestScore; bestScore = score; best = i + 1; }
    else if (score > second) second = score;
  });
  const sure = bestScore >= 0.34 && bestScore - second >= 0.15;
  return { id: best, sure, score: +bestScore.toFixed(2) };
}

function addRow(r) {
  const tb = $('tbl').querySelector('tbody');
  const tr = el('tr');
  const cells = [r.id, r.word, r.sentence.length > 70 ? r.sentence.slice(0, 70) + '…' : r.sentence,
    r.goldText, r.predText || '—', r.correct === null ? '待確認' : (r.correct ? '✓' : '✗'),
    r.ms ? (r.ms / 1000).toFixed(1) : '—'];
  cells.forEach((v, i) => {
    const td = el('td', null, String(v));
    if (i === 5) td.className = r.correct === null ? '' : (r.correct ? 'ok' : 'bad');
    tr.appendChild(td);
  });
  const td = el('td');
  if (r.needReview) {
    const sel = el('select');
    sel.appendChild(new Option('（請選擇）', ''));
    r.options.forEach((o, i) => sel.appendChild(new Option((i + 1) + '. ' + o.zh, String(i + 1))));
    sel.addEventListener('change', () => {
      if (!sel.value) return;
      r.pred = +sel.value; r.correct = r.pred === r.gold; r.needReview = false; r.reviewed = true;
      tr.children[4].textContent = r.options[r.pred - 1].zh;
      tr.children[5].textContent = r.correct ? '✓' : '✗';
      tr.children[5].className = r.correct ? 'ok' : 'bad';
      refresh();
      saveSoon();                              // 人工修正也要存檔
    });
    td.appendChild(sel);
  }
  tr.appendChild(td);
  tb.appendChild(tr);
  tr.scrollIntoView({ block: 'nearest' });
}

function refresh() {
  const done = rows.length;
  const judged = rows.filter((r) => r.correct !== null);
  const times = rows.filter((r) => r.ms).map((r) => r.ms);
  $('sDone').textContent = done;
  $('sAcc').textContent = judged.length ? Math.round(judged.filter((r) => r.correct).length / judged.length * 100) + '%' : '—';
  $('sMed').textContent = times.length ? (median(times) / 1000).toFixed(2) + ' 秒' : '—';
  $('sP95').textContent = times.length ? (pct(times, 0.95) / 1000).toFixed(2) + ' 秒' : '—';
  // 舊存檔沒有 calls 欄位：有計時就算 1 次
  $('sCalls').textContent = rows.reduce((n, r) => n + (r.calls != null ? r.calls : (r.ms ? 1 : 0)), 0);
  $('sReview').textContent = rows.filter((r) => r.needReview).length;
  $('sFail').textContent = rows.filter((r) => r.failed).length;
}

async function runOne(item, method) {
  const senses = DATA.senses[item.word];
  const options = senses.map((zh, i) => ({ zh, en: (DATA.senses_en[item.word] || [])[i] }));
  const base = { id: item.id, word: item.word, sentence: item.sentence, gold: item.gold,
    goldText: senses[item.gold - 1], options, correct: null, needReview: false, pred: null, predText: '',
    ms: 0, calls: 0, model: '', at: Date.now() };

  if (method === 'M0') {
    const pred = DATA.m0[item.word];
    return { ...base, pred, predText: pred ? senses[pred - 1] : '（第一義不在候選清單中）', correct: pred === item.gold };
  }
  // M2D：正式查字用的 prompt（同一次呼叫先選義、再解釋），候選意思用測試集的詞義清單
  const perm = orderFor(senses.length, run.order, run.seed, item.id);
  const ord = orderInfo(perm, item.gold);
  if (method === 'M2D') {
    const r = await send({ type: 'research-word', word: item.word, sentence: item.sentence, senses: perm.map((i) => senses[i]) });
    if (!r.ok) throw new Error(r.error.message);
    const d = r.data.data || {};
    const pred = toOrig(perm, d.sense);       // 0（都不符合）或超出範圍 → null，算答錯
    return { ...base, ...ord, ms: r.data.ms, calls: 1, model: r.data.model, pred,
      predText: (pred ? senses[pred - 1] : '（沒有選出候選意思）') + (d.context_zh ? '｜' + d.context_zh : ''),
      explanation: d.context_zh || '', correct: pred === item.gold };
  }
  const prompt = method === 'M1' ? promptM1(item.word, item.sentence) : promptM2(item.word, item.sentence, perm.map((i) => options[i]));
  const r = await send({ type: 'research-call', prompt });
  if (!r.ok) throw new Error(r.error.message);
  const d = r.data.data || {};
  const meta = { ms: r.data.ms, calls: 1, model: r.data.model };
  if (method === 'M2') {
    // 超出範圍的編號標成待確認（以前會被當成第 1 個，打亂順序時會誤算成偏好第一個位置）
    const pred = toOrig(perm, parseInt(d.choice, 10));
    if (pred === null) {
      return { ...base, ...meta, ...ord, predText: '選項無法判讀：' + JSON.stringify(d.choice), needReview: true };
    }
    return { ...base, ...meta, ...ord, pred, predText: senses[pred - 1] + (d.why ? '（' + d.why + '）' : ''), correct: pred === item.gold };
  }
  const m = matchSense(d.zh, senses);
  return { ...base, ...meta, answer: d.zh || '', pred: m.sure ? m.id : null,
    predText: d.zh + '　→ ' + senses[m.id - 1] + '（自動對應 ' + m.score + '）',
    correct: m.sure ? m.id === item.gold : null, needReview: !m.sure };
}

// ---------- 執行（新的一輪，或接續存檔中未完成的一輪） ----------
async function execute(resume) {
  if (running) return;
  if (!DATA) await loadData();
  const wicMode = (resume ? run.dataset : $('dataset').value) === 'wic';
  const method = resume ? run.method : $('method').value;
  if (wicMode && method === 'M2D') {
    $('hint').textContent = 'M2D（正式查字流程）只適用自建測試集：WiC 沒有可給學習者看的中文解釋。';
    return;
  }
  const delay = Math.max(0, +$('delay').value || 0) * 1000;
  const src = wicMode ? (await loadWic()).items : DATA.items;

  if (resume) {
    rows = rows.filter((r) => !r.failed);      // 失敗的題目重新跑
  } else {
    const limit = Math.max(1, +$('limit').value || 20);
    rows = [];
    // M0／M1 不顯示候選，順序設定不適用
    const order = method === 'M0' || method === 'M1' ? 'orig' : $('order').value;
    run = { id: 'r' + Date.now(), created: Date.now(), dataset: wicMode ? 'wic' : 'efl', method, limit,
      order, seed: Math.max(1, +$('seed').value || 1),
      planned: Math.min(limit, src.length), status: 'running', env: await collectEnv(), rows };
    try { localStorage.setItem(DEVICE_KEY, run.env.device); } catch (e) { /* 只是方便下次預填 */ }
  }
  run.status = 'running';
  run.delaySec = delay / 1000;
  const doneIds = new Set(rows.map((r) => r.id));
  const items = src.slice(0, run.limit).filter((it) => !doneIds.has(it.id));

  $('tbl').querySelector('tbody').textContent = '';
  rows.forEach(addRow);
  refresh();
  $('envLine').textContent = envText(run.env);
  $('hint').textContent = '執行中：' + (METHOD_NAME[method] || method) + (orderLabel(run) ? '（' + orderLabel(run) + '）' : '');  // 清掉上一輪的「完成」
  running = true; $('run').disabled = true; $('resume').disabled = true; $('stop').disabled = false;
  $('bar').max = run.planned; $('bar').value = rows.length;
  await saveNow();
  await refreshRunList(run.id);

  let stoppedBy = null;
  for (const item of items) {
    if (!running) { stoppedBy = 'stopped'; break; }
    let r = null, lastErr = null;
    for (let attempt = 0; attempt < 3 && !r; attempt++) {
      try {
        r = wicMode ? await runWic(item, method, Math.round(delay / 2)) : await runOne(item, method);
      } catch (e) {
        lastErr = e;
        // 額度用完、沒有金鑰：停止整批；其他錯誤：稍候重試
        if (/額度|金鑰|PAUSED|NO_KEY/.test(e.message)) { r = null; break; }
        await sleep(1500 * (attempt + 1));
      }
    }
    if (!r) {
      if (lastErr && /額度|金鑰/.test(lastErr.message)) {
        $('hint').textContent = '已停止：' + lastErr.message + '（已存檔，額度恢復後按「接續上一輪」）';
        stoppedBy = 'quota';
        break;
      }
      const senses = wicMode ? ['不同意思', '相同意思'] : DATA.senses[item.word];
      r = { id: item.id, word: item.word, sentence: wicMode ? item.s1 + ' ｜ ' + item.s2 : item.sentence,
            gold: wicMode ? item.gold + 1 : item.gold, goldText: wicMode ? (item.gold ? '相同意思' : '不同意思') : senses[item.gold - 1],
            options: senses.map((zh) => ({ zh })), pred: null, predText: '⚠ 連續 3 次失敗：' + (lastErr ? lastErr.message : ''),
            correct: null, needReview: true, ms: 0, calls: 0, at: Date.now(), failed: true };
    }
    rows.push(r); addRow(r); refresh();
    saveSoon();
    $('bar').value = rows.length;
    if (method !== 'M0' && delay) await sleep(delay);
  }
  run.status = stoppedBy || 'done';
  if (run.status === 'done') run.finished = Date.now();
  running = false; $('run').disabled = false; $('stop').disabled = true;
  await saveNow();
  await refreshRunList(run.id);
  $('resume').disabled = !canResume(run);
  if (run.status === 'done') $('hint').textContent = '完成：' + rows.length + ' 題（' + method + '），已自動存檔';
}

$('run').addEventListener('click', () => execute(false));
$('resume').addEventListener('click', () => { if (run) execute(true); });
$('stop').addEventListener('click', () => { running = false; });

// ---------- 存檔管理 ----------
$('runs').addEventListener('change', async () => {
  if (running) return;
  const all = await loadRuns();
  if (all[$('runs').value]) showRun(all[$('runs').value]);
});

$('del').addEventListener('click', async () => {
  const id = $('runs').value;
  if (running || !id || !confirm('確定要刪除這一輪的存檔嗎？（建議先匯出）')) return;
  await saveChain;
  const all = await loadRuns();
  delete all[id];
  await chrome.storage.local.set({ [RUNS_KEY]: all });
  if (run && run.id === id) { run = null; rows = []; $('tbl').querySelector('tbody').textContent = ''; refresh(); $('envLine').textContent = ''; }
  await refreshRunList();
  $('saved').textContent = '已刪除';
});

const fileStamp = () => (run ? run.method + '_' + new Date(run.created).toISOString().slice(0, 10) : 'empty');
function download(name, blob) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = name;
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 4000);
}

$('csv').addEventListener('click', () => {
  if (!rows.length) return;
  const head = ['題號', '單字', '句子', '正解編號', '正解', '預測編號', '預測', '是否正確', '毫秒', '呼叫次數', '模型', '時間', '方法',
    '候選順序', '顯示順序（原編號）', '正解顯示位置'];
  const method = run ? run.method : $('method').value;
  const body = rows.map((r) => [r.id, r.word, r.sentence, r.gold, r.goldText, r.pred || '', r.predText,
    r.correct === null ? '待確認' : (r.correct ? '正確' : '錯誤'), r.ms || '', r.calls != null ? r.calls : '',
    r.model || '', r.at ? new Date(r.at).toISOString() : '', method,
    run ? (orderLabel(run) || '原順序') : '', r.order ? r.order.join(' ') : '', r.goldPos || '']);
  const csv = '﻿' + [head, ...body].map((line) => line.map((v) => '"' + String(v).replace(/"/g, '""') + '"').join(',')).join('\r\n');
  download('實驗結果_' + fileStamp() + '.csv', new Blob([csv], { type: 'text/csv;charset=utf-8' }));
});

// JSON 含執行環境與每題的完整欄位，寫報告用這個
$('json').addEventListener('click', () => {
  if (!run) return;
  run.rows = rows;
  download('實驗紀錄_' + fileStamp() + '.json', new Blob([JSON.stringify(run, null, 1)], { type: 'application/json' }));
});

$('dataset').addEventListener('change', async () => {
  if ($('dataset').value === 'wic') await loadWic();
  else $('hint').textContent = '自建測試集：' + DATA.items.length + ' 題，' + Object.keys(DATA.senses).length + ' 個字';
});

// ---------- 啟動：載入資料與最近一輪的存檔 ----------
(async () => {
  try { $('device').value = localStorage.getItem(DEVICE_KEY) || ''; } catch (e) { /* 忽略 */ }
  await loadData();
  const all = await loadRuns();
  // 上次關頁時還在跑的那一輪：標成「中斷」，可以接續
  let changed = false;
  for (const r of Object.values(all)) if (r.status === 'running') { r.status = 'interrupted'; changed = true; }
  if (changed) await chrome.storage.local.set({ [RUNS_KEY]: all });
  const latest = Object.values(all).sort((a, b) => b.created - a.created)[0];
  await refreshRunList(latest && latest.id);
  if (latest) showRun(latest);
})();
WLUtil.checkBuild();
