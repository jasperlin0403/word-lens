// 研究模式：執行 M0／M1／M2 三種方法，記錄準確率與回應時間
const $ = (id) => document.getElementById(id);
const { el, send } = WLUtil;

let DATA = null;       // 自建測試集
let WIC = null;        // WiC 資料（使用者選擇檔案後載入）
let rows = [];         // 本次執行結果
let running = false;

const median = (a) => { if (!a.length) return null; const s = [...a].sort((x, y) => x - y); const m = s.length >> 1; return s.length % 2 ? s[m] : (s[m - 1] + s[m]) / 2; };
const pct = (a, p) => { if (!a.length) return null; const s = [...a].sort((x, y) => x - y); return s[Math.min(s.length - 1, Math.floor(s.length * p))]; };

async function loadData() {
  const r = await fetch(chrome.runtime.getURL('research/efl_set.json'));
  DATA = await r.json();
  $('hint').textContent = '自建測試集：' + DATA.items.length + ' 題，' + Object.keys(DATA.senses).length + ' 個字';
}

async function loadWic() {
  if (!WIC) {
    const r = await fetch(chrome.runtime.getURL('research/wic_dev.json'));
    WIC = await r.json();
  }
  $('hint').textContent = 'WiC 驗證集：' + WIC.items.length + ' 題（正反各半；候選詞義取自 WordNet）';
  return WIC;
}

// WiC：判斷同一個字在兩個句子中是否為相同意思
function promptWicM1(it) {
  return ['Decide whether the target word has the SAME meaning in the two sentences.',
    'Target word: ' + it.word, 'Sentence 1: ' + it.s1, 'Sentence 2: ' + it.s2,
    'Reply with JSON only: {"same": true or false}'].join('\n');
}

function promptWicM2(it) {
  const list = it.senses.map((d, i) => (i + 1) + '. ' + d).join('\n');
  return ['For each sentence, choose the sense of the target word from the list.',
    'Target word: ' + it.word, 'Sentence 1: ' + it.s1, 'Sentence 2: ' + it.s2,
    'Senses:', list,
    'Reply with JSON only: {"sense1": number, "sense2": number}'].join('\n');
}

async function runWic(it, method) {
  const base = { id: it.id, word: it.word, sentence: it.s1 + ' ｜ ' + it.s2, gold: it.gold,
    goldText: it.gold ? '相同意思' : '不同意思', options: [{ zh: '不同意思' }, { zh: '相同意思' }],
    correct: null, needReview: false, pred: null, predText: '', ms: 0 };
  if (method === 'M0') {                       // 詞典第一義：兩句都取第一義 → 永遠回答「相同」
    return { ...base, pred: 2, predText: '相同意思（第一義必定相同）', correct: it.gold === 1 };
  }
  const r = await send({ type: 'research-call', prompt: method === 'M1' ? promptWicM1(it) : promptWicM2(it) });
  if (!r.ok) throw new Error(r.error.message);
  const d = r.data.data || {};
  let same;
  let detail = '';
  if (method === 'M1') same = d.same === true || d.same === 'true';
  else {
    const a = parseInt(d.sense1, 10), b = parseInt(d.sense2, 10);
    same = a === b; detail = '（' + a + ' vs ' + b + '）';
  }
  return { ...base, pred: same ? 2 : 1, predText: (same ? '相同意思' : '不同意思') + detail,
    correct: (same ? 1 : 0) === it.gold, ms: r.data.ms };
}

// ---------- 三種方法 ----------
function promptM1(word, sentence) {
  return [
    '你是一位英文老師，學生的母語是繁體中文（台灣）。',
    '請判斷這個英文單字在下面這個句子中的意思，並用最簡短的繁體中文詞語表達（不要解釋、不要加句號）。',
    '單字：' + word,
    '句子：' + sentence,
    '只回傳 JSON：{"zh": "這個字在本句中的中文意思（最多 8 個字）"}'
  ].join('\n');
}

function promptM2(word, sentence, options) {
  const list = options.map((o, i) => (i + 1) + '. ' + o.zh + (o.en ? '（' + o.en + '）' : '')).join('\n');
  return [
    '你是一位英文老師。以下是某個英文單字的候選中文意思，請根據句子挑出最合適的一個。',
    '單字：' + word,
    '句子：' + sentence,
    '候選意思：',
    list,
    '只回傳 JSON：{"choice": 選項編號（數字）, "why": "簡短理由（繁體中文，20 字內）"}'
  ].join('\n');
}

// M1 的自由文字答案 → 對應到候選詞義（字元重疊度）；不明確時標記待確認
function matchSense(zh, senses) {
  const clean = (s) => String(s || '').replace(/[（(].*?[)）]/g, '');
  const target = new Set(clean(zh));
  let best = 0, bestScore = -1, second = -1;
  senses.forEach((s, i) => {
    const overlap = [...new Set(clean(s))].filter((c) => target.has(c)).length;
    const score = overlap / Math.max(1, new Set(clean(s)).size);
    if (score > bestScore) { second = bestScore; bestScore = score; best = i + 1; }
    else if (score > second) second = score;
  });
  const sure = bestScore >= 0.34 && bestScore - second >= 0.15;
  return { id: best, sure, score: +bestScore.toFixed(2) };
}

function addRow(r) {
  const tb = $('tbl').querySelector('tbody');
  const tr = el('tr');
  const cells = [r.id, r.word, r.sentence.length > 70 ? r.sentence.slice(0, 70) + '…' : r.sentence,
    r.goldText, r.predText || '—', r.correct === null ? '待確認' : (r.correct ? '✓' : '✗'),
    r.ms ? (r.ms / 1000).toFixed(1) : '—'];
  cells.forEach((v, i) => {
    const td = el('td', null, String(v));
    if (i === 5) td.className = r.correct === null ? '' : (r.correct ? 'ok' : 'bad');
    tr.appendChild(td);
  });
  const td = el('td');
  if (r.needReview) {
    const sel = el('select');
    sel.appendChild(new Option('（請選擇）', ''));
    r.options.forEach((o, i) => sel.appendChild(new Option((i + 1) + '. ' + o.zh, String(i + 1))));
    sel.addEventListener('change', () => {
      if (!sel.value) return;
      r.pred = +sel.value; r.correct = r.pred === r.gold; r.needReview = false;
      tr.children[4].textContent = r.options[r.pred - 1].zh;
      tr.children[5].textContent = r.correct ? '✓' : '✗';
      tr.children[5].className = r.correct ? 'ok' : 'bad';
      refresh();
    });
    td.appendChild(sel);
  }
  tr.appendChild(td);
  tb.appendChild(tr);
  tr.scrollIntoView({ block: 'nearest' });
}

function refresh() {
  const done = rows.length;
  const judged = rows.filter((r) => r.correct !== null);
  const times = rows.filter((r) => r.ms).map((r) => r.ms);
  $('sDone').textContent = done;
  $('sAcc').textContent = judged.length ? Math.round(judged.filter((r) => r.correct).length / judged.length * 100) + '%' : '—';
  $('sMed').textContent = times.length ? (median(times) / 1000).toFixed(2) + ' 秒' : '—';
  $('sP95').textContent = times.length ? (pct(times, 0.95) / 1000).toFixed(2) + ' 秒' : '—';
  $('sCalls').textContent = rows.filter((r) => r.ms).length;
  $('sReview').textContent = rows.filter((r) => r.needReview).length;
  $('sFail').textContent = rows.filter((r) => r.failed).length;
}

async function runOne(item, method) {
  const senses = DATA.senses[item.word];
  const options = senses.map((zh, i) => ({ zh, en: (DATA.senses_en[item.word] || [])[i] }));
  const base = { id: item.id, word: item.word, sentence: item.sentence, gold: item.gold,
    goldText: senses[item.gold - 1], options, correct: null, needReview: false, pred: null, predText: '', ms: 0 };

  if (method === 'M0') {
    const pred = DATA.m0[item.word];
    return { ...base, pred, predText: pred ? senses[pred - 1] : '（第一義不在候選清單中）', correct: pred === item.gold };
  }
  const prompt = method === 'M1' ? promptM1(item.word, item.sentence) : promptM2(item.word, item.sentence, options);
  const r = await send({ type: 'research-call', prompt });
  if (!r.ok) throw new Error(r.error.message);
  const d = r.data.data || {};
  if (method === 'M2') {
    const pred = Math.min(senses.length, Math.max(1, parseInt(d.choice, 10) || 0));
    return { ...base, pred, predText: senses[pred - 1] + (d.why ? '（' + d.why + '）' : ''), correct: pred === item.gold, ms: r.data.ms };
  }
  const m = matchSense(d.zh, senses);
  return { ...base, pred: m.sure ? m.id : null, predText: d.zh + '　→ ' + senses[m.id - 1] + '（自動對應 ' + m.score + '）',
    correct: m.sure ? m.id === item.gold : null, needReview: !m.sure, ms: r.data.ms };
}

$('run').addEventListener('click', async () => {
  if (running) return;
  if (!DATA) await loadData();
  const method = $('method').value;
  const limit = Math.max(1, +$('limit').value || 20);
  const delay = Math.max(0, +$('delay').value || 0) * 1000;
  rows = []; $('tbl').querySelector('tbody').textContent = ''; refresh();
  running = true; $('run').disabled = true; $('stop').disabled = false;
  const wicMode = $('dataset').value === 'wic';
  const src = wicMode ? (await loadWic()).items : DATA.items;
  const items = src.slice(0, limit);
  $('bar').max = items.length; $('bar').value = 0;
  for (const item of items) {
    if (!running) break;
    let r = null, lastErr = null;
    for (let attempt = 0; attempt < 3 && !r; attempt++) {
      try {
        r = wicMode ? await runWic(item, method) : await runOne(item, method);
      } catch (e) {
        lastErr = e;
        // 額度用完、沒有金鑰：停止整批；其他錯誤：稍候重試
        if (/額度|金鑰|PAUSED|NO_KEY/.test(e.message)) { r = null; break; }
        await new Promise((res) => setTimeout(res, 1500 * (attempt + 1)));
      }
    }
    if (!r) {
      if (lastErr && /額度|金鑰/.test(lastErr.message)) {
        $('hint').textContent = '已停止：' + lastErr.message;
        break;
      }
      const senses = wicMode ? ['不同意思', '相同意思'] : DATA.senses[item.word];
      r = { id: item.id, word: item.word, sentence: wicMode ? item.s1 + ' ｜ ' + item.s2 : item.sentence,
            gold: wicMode ? item.gold + 1 : item.gold, goldText: wicMode ? (item.gold ? '相同意思' : '不同意思') : senses[item.gold - 1],
            options: senses.map((zh) => ({ zh })), pred: null, predText: '⚠ 連續 3 次失敗：' + (lastErr ? lastErr.message : ''),
            correct: null, needReview: true, ms: 0, failed: true };
    }
    rows.push(r); addRow(r); refresh();
    $('bar').value = rows.length;
    if (method !== 'M0' && delay) await new Promise((res) => setTimeout(res, delay));
  }
  running = false; $('run').disabled = false; $('stop').disabled = true;
  if (!$('hint').textContent.startsWith('已停止')) $('hint').textContent = '完成：' + rows.length + ' 題（' + method + '）';
});

$('stop').addEventListener('click', () => { running = false; });

$('csv').addEventListener('click', () => {
  if (!rows.length) return;
  const head = ['題號', '單字', '句子', '正解編號', '正解', '預測編號', '預測', '是否正確', '毫秒', '方法'];
  const method = $('method').value;
  const body = rows.map((r) => [r.id, r.word, r.sentence, r.gold, r.goldText, r.pred || '', r.predText,
    r.correct === null ? '待確認' : (r.correct ? '正確' : '錯誤'), r.ms || '', method]);
  const csv = '\uFEFF' + [head, ...body].map((line) => line.map((v) => '"' + String(v).replace(/"/g, '""') + '"').join(',')).join('\r\n');
  const url = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8' }));
  const a = document.createElement('a');
  a.href = url; a.download = '實驗結果_' + method + '_' + new Date().toISOString().slice(0, 10) + '.csv';
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 4000);
});

$('dataset').addEventListener('change', async () => {
  if ($('dataset').value === 'wic') await loadWic();
  else $('hint').textContent = '自建測試集：' + DATA.items.length + ' 題，' + Object.keys(DATA.senses).length + ' 個字';
});

loadData();
WLUtil.checkBuild();
