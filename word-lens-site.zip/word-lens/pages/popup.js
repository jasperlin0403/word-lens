const $ = (id) => document.getElementById(id);
const { send } = WLUtil;
const HINTS = {
  auto: '查詢卡停留 0.5 秒才呼叫 AI，快速滑過不消耗額度。',
  manual: '只顯示離線結果，按「AI 解釋」才呼叫。適合大量查字。',
  off: '完全離線：中文意思與音標仍可用，不消耗額度。'
};

async function getSettings() {
  const { settings = {} } = await chrome.storage.local.get('settings');
  return settings;
}
async function setSetting(key, value) {
  const s = await getSettings();
  s[key] = value;
  await chrome.storage.local.set({ settings: s });
}

function showMode(mode) {
  document.querySelectorAll('.seg button').forEach((b) => b.setAttribute('aria-pressed', String(b.dataset.mode === mode)));
  $('modeHint').textContent = HINTS[mode] || '';
}

async function showQuota() {
  const [r, chain, info] = await Promise.all([send({ type: 'quota-status' }), send({ type: 'model-chain' }), send({ type: 'provider-info' })]);
  if (!r.ok || !chain.ok) return;
  const q = r.data;
  const label = (id) => ((info.ok && info.data.models.find((m) => m.id === id)) || { label: id }).label;
  $('usage').textContent = '今天已呼叫 AI ' + q.today + ' 次（每日額度以太平洋時間計）';
  const active = chain.data.find((m) => !q.paused[m]);
  const p = $('paused');
  if (active) {
    $('current').textContent = '目前使用：' + label(active) + (active !== chain.data[0] ? '（主要模型額度已用完，自動改用備援）' : '');
    p.hidden = true;
  } else {
    const until = Math.min(...chain.data.map((m) => q.paused[m].until));
    const t = new Date(until).toLocaleTimeString('zh-TW', { hour: '2-digit', minute: '2-digit' });
    $('current').textContent = '';
    p.textContent = '所有可用模型的 AI 額度都已用完，約 ' + t + ' 自動恢復。期間自動改用離線結果。';
    p.hidden = false;
  }
}

async function showReview() {
  const r = await send({ type: 'review-stats' });
  if (!r.ok) return;
  const b = $('review');
  b.hidden = false;
  b.textContent = r.data.due ? '開始複習（今天有 ' + r.data.due + ' 個字）' : '今天的複習都完成了 ✓';
  b.className = r.data.due ? 'btn' : 'btn ghost';
}

async function load() {
  const s = await getSettings();
  const { words = {} } = await chrome.storage.local.get('words');
  $('enabled').checked = s.enabled !== false;
  $('highlight').checked = s.highlight !== false;
  $('hover').checked = s.hover !== false;
  $('count').textContent = Object.keys(words).length;
  showMode(s.aiMode || 'auto');
  const k = await send({ type: 'key-status' });
  $('nokey').hidden = !(k.ok && !k.data.set);
  showQuota();
  showReview();
}

for (const id of ['enabled', 'highlight', 'hover']) {
  $(id).addEventListener('change', (e) => setSetting(id, e.target.checked));
}
document.querySelectorAll('.seg button').forEach((b) =>
  b.addEventListener('click', async () => {
    showMode(b.dataset.mode);
    await setSetting('aiMode', b.dataset.mode);
  })
);

let activeTab = null;
chrome.tabs.query({ active: true, currentWindow: true }).then(([t]) => {
  activeTab = t;
  const url = (t && t.url) || '';
  if (/^(https?|file):/i.test(url)) {
    $('pdfHere').hidden = false;
    if (/\.pdf($|[?#])/i.test(url)) $('pdfHere').textContent = '用 PDF 閱讀器開啟這份 PDF';
  }
});
$('pdfHere').addEventListener('click', () => {
  send({ type: 'open-pdf', tabId: activeTab.id, url: activeTab.url });
  window.close();
});
$('pdfLocal').addEventListener('click', () => { send({ type: 'open-pdf' }); window.close(); });
$('review').addEventListener('click', () => { send({ type: 'open-review' }); window.close(); });
$('book').addEventListener('click', () => { send({ type: 'open-wordbook' }); window.close(); });
$('opts').addEventListener('click', () => { chrome.runtime.openOptionsPage(); window.close(); });

// 網頁版：改用觸控的說明，隱藏只適用於電腦版的選項
if (globalThis.WL_WEB) {
  $('tip').textContent = '在「📖 閱讀」或 PDF 裡點一下英文單字即可查詢；選取整句後按「翻譯整句」。';
  $('hoverRow').hidden = true;
  $('pdfbox').hidden = true;
}

load();

WLUtil.checkBuild();
