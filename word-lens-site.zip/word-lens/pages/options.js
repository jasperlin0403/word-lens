const $ = (id) => document.getElementById(id);
const { send } = WLUtil;

function setStatus(text, kind) {
  $('status').textContent = text;
  $('status').className = 'status' + (kind ? ' ' + kind : '');
}

async function showKey() {
  const r = await send({ type: 'key-status' });
  $('keyStatus').textContent = r.ok && r.data.set ? '目前已設定：' + r.data.masked : '尚未設定金鑰。';
}

async function load() {
  const { settings = {} } = await chrome.storage.local.get('settings');
  const info = await send({ type: 'provider-info' });
  const models = info.ok ? info.data.models : [];
  const sel = $('modelSel');
  for (const m of models) sel.appendChild(new Option(m.label + '（每天約 ' + m.rpd.toLocaleString() + ' 次' + (m.note ? '，' + m.note : '') + '）', m.id));
  sel.appendChild(new Option('自行輸入模型名稱…', '__custom'));
  const model = settings.model || (models[0] && models[0].id) || '';
  if (models.some((m) => m.id === model)) sel.value = model;
  else {
    sel.value = '__custom';
    $('modelCustom').value = model;
    $('customWrap').hidden = false;
  }
  $('autoFallback').checked = settings.autoFallback !== false;
  $('gemmaBackup').checked = !!settings.gemmaBackup;
  showKey();
}

async function setSetting(key, value) {
  const { settings = {} } = await chrome.storage.local.get('settings');
  await chrome.storage.local.set({ settings: { ...settings, [key]: value } });
}
$('autoFallback').addEventListener('change', (e) => setSetting('autoFallback', e.target.checked));
$('gemmaBackup').addEventListener('change', (e) => setSetting('gemmaBackup', e.target.checked));

$('testGemma').addEventListener('click', async () => {
  const out = $('gemmaResult');
  out.className = 'status';
  out.textContent = '測試中（約需數秒）…';
  $('testGemma').disabled = true;
  const info = await send({ type: 'provider-info' });
  const r = await send({ type: 'test-model', model: info.ok ? info.data.gemma : 'gemma-4-26b-a4b-it' });
  $('testGemma').disabled = false;
  if (!r.ok) {
    out.className = 'status err';
    out.textContent = '測試失敗：' + r.error.message + '\n建議先不要啟用 Gemma 備援。';
    return;
  }
  const d = r.data;
  const lines = [
    (d.ok ? '✅ 測試通過' : '⚠️ 測試有問題') + '（回應時間 ' + (d.ms / 1000).toFixed(1) + ' 秒）',
    d.missing.length ? '缺少欄位：' + d.missing.join('、') : '回傳格式：完整',
    d.simplified ? '中文：出現簡體字' : '中文：繁體',
    '範例 ─ 中文意思：' + d.sample.zh,
    '範例 ─ 本句意思：' + d.sample.context_zh
  ];
  out.className = 'status ' + (d.ok ? 'ok' : 'err');
  out.textContent = lines.join('\n') + (d.ok ? '\n可以勾選上方的「加入 Gemma 4 作為第二備援」。' : '\n建議先不要啟用 Gemma 備援。');
});

$('modelSel').addEventListener('change', () => { $('customWrap').hidden = $('modelSel').value !== '__custom'; });
$('toggle').addEventListener('click', () => {
  const i = $('apiKey');
  const show = i.type === 'password';
  i.type = show ? 'text' : 'password';
  $('toggle').textContent = show ? '隱藏' : '顯示';
});

$('save').addEventListener('click', async () => {
  const key = $('apiKey').value.trim();
  const model = $('modelSel').value === '__custom' ? $('modelCustom').value.trim() : $('modelSel').value;
  if (!model) return setStatus('請輸入模型名稱。', 'err');
  const { settings = {} } = await chrome.storage.local.get('settings');
  await chrome.storage.local.set({ settings: { ...settings, model } });
  if (key) {
    await send({ type: 'set-key', key });
    $('apiKey').value = '';
  }
  await showKey();
  const ks = await send({ type: 'key-status' });
  if (!(ks.ok && ks.data.set)) return setStatus('已儲存。尚未填入金鑰，AI 功能暫時無法使用（離線查詢仍可用）。', 'err');
  setStatus('已儲存，正在測試連線…');
  $('save').disabled = true;
  const r = await send({ type: 'test' });
  $('save').disabled = false;
  if (r.ok) setStatus(globalThis.WL_WEB ? '連線成功！回到「📖 閱讀」貼上英文文章，點一下單字試試看。' : '連線成功！回到英文網頁，雙擊單字或按住 Ctrl 指著單字試試看。', 'ok');
  else setStatus('測試失敗：' + r.error.message, 'err');
});

load();

WLUtil.checkBuild();

// 網頁版：隱藏只適用於電腦版 Chrome 的說明
if (globalThis.WL_WEB) {
  document.querySelectorAll('h2').forEach((h) => {
    if (/本機的 \.txt/.test(h.textContent)) {
      const panel = h.nextElementSibling;
      h.remove();
      if (panel) panel.remove();
    }
  });
}
