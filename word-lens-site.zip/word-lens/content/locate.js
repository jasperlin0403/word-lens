// 找出游標下的單字、取出單字所在的句子（支援網頁元件 Shadow DOM、禁止選取的網頁、PDF 文字層）
(() => {
  const WL = globalThis.__WL;
  if (!WL || WL.dead) return;

  // ---------- 找出游標下的單字 ----------
  function caretAt(x, y, roots) {
    if (document.caretPositionFromPoint) {
      try {
        const p = roots && roots.length
          ? document.caretPositionFromPoint(x, y, { shadowRoots: roots })
          : document.caretPositionFromPoint(x, y);
        if (p && p.offsetNode) return { node: p.offsetNode, offset: p.offset };
      } catch (e) { /* 改用下一種方法 */ }
    }
    if (document.caretRangeFromPoint) {
      try {
        const r = document.caretRangeFromPoint(x, y);
        if (r) return { node: r.startContainer, offset: r.startOffset };
      } catch (e) { /* 忽略 */ }
    }
    return null;
  }

  function rectHas(r, x, y, pad) {
    return x >= r.left - pad && x <= r.right + pad && y >= r.top - pad && y <= r.bottom + pad;
  }

  function wordFromCaret(node, offset, x, y) {
    if (!node || node.nodeType !== 3) return null;
    const text = node.data;
    const isW = (c) => /[A-Za-z'’-]/.test(c || '');
    let a = offset;
    if (!isW(text[a]) && isW(text[a - 1])) a--;
    if (!isW(text[a])) return null;
    while (a > 0 && isW(text[a - 1])) a--;
    let b = a;
    while (b < text.length && isW(text[b])) b++;
    const raw = text.slice(a, b);
    const lead = raw.length - raw.replace(/^[^A-Za-z]+/, '').length;
    const word = raw.replace(/^[^A-Za-z]+|[^A-Za-z]+$/g, '');
    if (!word) return null;
    const range = document.createRange();
    range.setStart(node, a + lead);
    range.setEnd(node, a + lead + word.length);
    const rects = [...range.getClientRects()];
    if (!rects.some((r) => rectHas(r, x, y, 3))) return null;
    return { word, range };
  }

  // 備援：直接逐字比對文字位置（網站禁止選取文字時使用）
  function hitTestText(x, y, startEl) {
    let elm = startEl && startEl.nodeType === 1 ? startEl : null;
    if (!elm) elm = document.elementFromPoint(x, y);
    if (!elm) return null;
    const walker = document.createTreeWalker(elm, NodeFilter.SHOW_TEXT);
    const re = /[A-Za-z]+(?:['’-][A-Za-z]+)*/g;
    let n;
    let count = 0;
    while ((n = walker.nextNode()) && count < 300) {
      count++;
      if (!/[A-Za-z]/.test(n.data)) continue;
      const whole = document.createRange();
      whole.selectNodeContents(n);
      if (![...whole.getClientRects()].some((r) => rectHas(r, x, y, 2))) continue;
      re.lastIndex = 0;
      let m;
      while ((m = re.exec(n.data))) {
        const r = document.createRange();
        r.setStart(n, m.index);
        r.setEnd(n, m.index + m[0].length);
        if ([...r.getClientRects()].some((q) => rectHas(q, x, y, 2))) return { word: m[0], range: r };
      }
    }
    return null;
  }

  function wordRangeAtPoint(x, y, path) {
    const roots = (path || []).filter((n) => typeof ShadowRoot !== 'undefined' && n instanceof ShadowRoot);
    const c = caretAt(x, y, roots);
    const hit = c ? wordFromCaret(c.node, c.offset, x, y) : null;
    if (hit) return hit;
    const deepest = (path || []).find((n) => n && n.nodeType === 1);
    return hitTestText(x, y, deepest);
  }

  // ---------- 取出單字所在的句子 ----------
  function extractSentence(range) {
    try {
      const node = range.startContainer;
      const elNode = node.nodeType === 1 ? node : node.parentElement;
      if (!elNode) return '';
      const root = elNode.getRootNode();
      const block =
        elNode.closest('p, li, dd, dt, td, th, blockquote, h1, h2, h3, h4, h5, h6, figcaption, pre, div, article, section') ||
        (typeof ShadowRoot !== 'undefined' && root instanceof ShadowRoot ? root : document.body);
      // 逐一走訪文字：<br>（PDF 換行）視為空格；行尾連字號（manage-⏎ment）直接接回
      let full = '';
      let offset = -1;
      const walker = document.createTreeWalker(block, NodeFilter.SHOW_TEXT | NodeFilter.SHOW_ELEMENT);
      let n = walker.currentNode;
      while (n) {
        if (n.nodeType === 3) {
          if (n === range.startContainer) offset = full.length + range.startOffset;
          full += n.data;
        } else if (n.tagName === 'BR') {
          if (/[A-Za-z]-$/.test(full)) full = full.slice(0, -1);
          else full += ' ';
        } else if (n === range.startContainer) {
          offset = full.length;
        }
        if (full.length > 200000) break;
        n = walker.nextNode();
      }
      if (offset < 0) offset = 0;
      const ends = /[.!?]/;

      let start = Math.max(0, offset - 600);
      for (let i = offset - 1; i >= Math.max(0, offset - 600); i--) {
        const ch = full[i];
        if (ch === '\n') { start = i + 1; break; }
        if (ends.test(ch) && /\s/.test(full[i + 1] || '')) { start = i + 1; break; }
        if (i === 0) start = 0;
      }
      let end = Math.min(full.length, offset + 600);
      for (let i = offset; i < Math.min(full.length, offset + 600); i++) {
        const ch = full[i];
        if (ch === '\n') { end = i; break; }
        if (ends.test(ch) && (i + 1 >= full.length || /[\s"'”’)]/.test(full[i + 1]))) { end = i + 1; break; }
      }
      let s = full.slice(start, end).replace(/\s+/g, ' ').trim();
      if (s.length > 500) s = s.slice(0, 500) + '…';
      return s;
    } catch (e) {
      return '';
    }
  }

  WL.locate = { wordRangeAtPoint, extractSentence };
})();
