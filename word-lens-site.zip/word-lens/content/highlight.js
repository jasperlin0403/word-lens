// 生詞本中的字在網頁上自動標色（CSS Custom Highlight API，不改動網頁結構）
(() => {
  const WL = globalThis.__WL;
  if (!WL || WL.dead) return;

  // ---------- 生詞本標色 ----------
  const LEVELS = [1, 2, 3, 4]; // 5 級（已掌握）不標色
  const hlName = (lv) => 'word-lens-l' + lv;
  const SKIP_TAGS = new Set(['SCRIPT', 'STYLE', 'NOSCRIPT', 'TEXTAREA', 'INPUT', 'SELECT', 'CODE', 'SVG']);
  let hlTimer = null;
  let observer = null;
  let lastSig = '';

  function wordsSignature() {
    return Object.entries(WL.state.words)
      .map(([k, v]) => k + ':' + (v.level || 1) + ':' + (v.forms || []).join(','))
      .sort()
      .join('|');
  }

  // 建立「字形 → 熟悉度」對照表與比對用的正規表示式（字尾 -s/-es/-ed/-d/-ing 自動對應）
  function buildMatcher() {
    const levelOf = new Map();
    for (const [k, v] of Object.entries(WL.state.words)) {
      const lv = v.level || 1;
      if (lv >= 5) continue;
      for (const f of [k, ...(v.forms || [])]) levelOf.set(String(f).toLowerCase(), lv);
    }
    const list = [...levelOf.keys()]
      .filter((s) => s.length > 1 && /^[a-z][a-z '’-]*[a-z]$/.test(s))
      .sort((a, b) => b.length - a.length)
      .map(WL.U.escapeRe);
    if (!list.length) return null;
    return { re: new RegExp('\\b(' + list.join('|') + ')(?:s|es|ed|d|ing)?\\b', 'gi'), levelOf };
  }

  function clearHighlights() {
    if (typeof CSS === 'undefined' || !CSS.highlights) return;
    for (const lv of LEVELS) CSS.highlights.delete(hlName(lv));
  }

  function applyHighlights() {
    if (WL.dead) return;
    if (typeof CSS === 'undefined' || !CSS.highlights || typeof Highlight === 'undefined') return;
    clearHighlights();
    if (!WL.state.settings.enabled || !WL.state.settings.highlight) return;
    const matcher = buildMatcher();
    const root = document.body;
    if (!matcher || !root) return;
    const groups = {};
    for (const lv of LEVELS) groups[lv] = new Highlight();
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
      acceptNode(n) {
        const p = n.parentElement;
        if (!p || SKIP_TAGS.has(p.tagName.toUpperCase())) return NodeFilter.FILTER_REJECT;
        if (p.isContentEditable) return NodeFilter.FILTER_REJECT;
        if (!/[A-Za-z]/.test(n.data)) return NodeFilter.FILTER_REJECT;
        return NodeFilter.FILTER_ACCEPT;
      }
    });
    let n;
    let count = 0;
    while ((n = walker.nextNode()) && count < 50000) {
      count++;
      matcher.re.lastIndex = 0;
      let m;
      while ((m = matcher.re.exec(n.data))) {
        const lv = matcher.levelOf.get(m[1].toLowerCase()) || 1;
        const r = new Range();
        r.setStart(n, m.index);
        r.setEnd(n, m.index + m[0].length);
        groups[lv].add(r);
      }
    }
    for (const lv of LEVELS) if (groups[lv].size) CSS.highlights.set(hlName(lv), groups[lv]);
  }

  function scheduleHighlight(delay = 600) {
    clearTimeout(hlTimer);
    hlTimer = setTimeout(() => {
      if ('requestIdleCallback' in window) requestIdleCallback(applyHighlights, { timeout: 2000 });
      else applyHighlights();
    }, delay);
  }

  function updateObserver() {
    const need = WL.state.settings.enabled && WL.state.settings.highlight && Object.keys(WL.state.words).length > 0;
    if (need && !observer && document.body) {
      observer = new MutationObserver(() => scheduleHighlight(800));
      observer.observe(document.body, { childList: true, subtree: true, characterData: true });
    } else if (!need && observer) {
      observer.disconnect();
      observer = null;
    }
  }

  function refreshAll(force) {
    if (WL.dead) return;
    if (!document.body) {
      document.addEventListener('DOMContentLoaded', () => refreshAll(true), { once: true });
      return;
    }
    const sig = wordsSignature() + '#' + WL.state.settings.enabled + WL.state.settings.highlight;
    if (!force && sig === lastSig) return;
    lastSig = sig;
    updateObserver();
    scheduleHighlight(force ? 0 : 300);
  }

  WL.onShutdown(() => {
    if (observer) observer.disconnect();
    clearTimeout(hlTimer);
    clearHighlights();
  });

  WL.highlight = { refresh: refreshAll };
})();
