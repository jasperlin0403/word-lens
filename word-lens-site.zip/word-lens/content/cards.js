// 單字查詢卡與整句翻譯卡
// 資料分三層：離線詞典（瞬間）→ 線上英英字典 → AI（依「AI 模式」決定何時呼叫）
(() => {
  const WL = globalThis.__WL;
  if (!WL || WL.dead) return;
  const { el, send, speak } = WL.U;
  const ui = WL.ui;

  const AI_DELAY = 500; // 自動模式：查詢卡停留 0.5 秒才呼叫 AI，快速滑過不消耗額度
  const LEVEL_NAMES = ['新字', '認得', '學習中', '快熟了', '已掌握'];

  // 熟悉度選擇列（只有存在生詞本裡的字才顯示）
  function levelRow(word) {
    const row = el('div', 'wl-levels');
    row.hidden = true;
    row.appendChild(el('span', 'wl-lv-label', '熟悉度'));
    const btns = LEVEL_NAMES.map((name, i) => {
      const b = el('button', 'wl-lv', name);
      b.title = '設為「' + name + '」' + (i === 4 ? '（網頁上不再標色）' : '');
      b.addEventListener('click', async () => {
        const r = await send({ type: 'set-level', word, level: i + 1 });
        if (r.ok && r.data.saved) show(r.data.level);
      });
      row.appendChild(b);
      return b;
    });
    function show(level) {
      row.hidden = false;
      btns.forEach((b, i) => b.classList.toggle('on', i + 1 === level));
      ui.place();
    }
    return { row, show };
  }

  function openShell(rect, anchorNode, titleNode) {
    const { c, token } = ui.openCard(rect, anchorNode);
    const stale = () => token !== ui.token;
    const head = el('div', 'wl-head');
    head.appendChild(titleNode);
    return { c, stale, head };
  }

  function iconBtn(text, label, onClick) {
    const b = el('button', 'wl-icon', text);
    b.title = label;
    b.setAttribute('aria-label', label);
    b.addEventListener('click', onClick);
    return b;
  }

  // ---------- 單字查詢卡 ----------
  function showWordCard(word, sentence, rect, anchorNode) {
    const { c, stale, head } = openShell(rect, anchorNode, el('span', 'wl-word', word));
    const data = { off: null, dict: null, dictErr: null, ai: null, dictDone: false };

    const phon = el('span', 'wl-phon', '');
    head.appendChild(phon);
    head.appendChild(el('span', 'wl-spacer'));
    head.appendChild(iconBtn('🔊', '發音', () => speak(word, data.dict && data.dict.audio)));
    head.appendChild(iconBtn('✕', '關閉（Esc）', ui.closeCard));
    c.appendChild(head);

    const tags = el('div');
    c.appendChild(tags);
    const lv = levelRow(word);
    c.appendChild(lv.row);
    const tagSet = new Set();
    const addTag = (cls, text) => {
      if (tagSet.has(text)) return;
      tagSet.add(text);
      tags.appendChild(el('span', cls, text));
    };

    const zh = ui.section('中文意思');
    ui.skeleton(zh.body, 1);
    const ctx = ui.section('在這句話裡');
    const en = ui.section('英英解釋與例句');
    ui.skeleton(en.body, 2);
    c.append(zh.s, ctx.s, en.s);

    const foot = el('div', 'wl-foot');
    const saveBtn = el('button', 'wl-btn', '加入生詞本');
    saveBtn.disabled = true;
    const bookBtn = el('button', 'wl-btn ghost', '開啟生詞本');
    bookBtn.addEventListener('click', () => send({ type: 'open-wordbook' }));
    foot.append(saveBtn, bookBtn);
    c.appendChild(foot);

    const quote = () => (sentence ? ui.quoteWithMark(sentence, word) : el('p', 'wl-muted', '沒有抓到所在的句子。'));
    ctx.body.appendChild(quote());
    ui.place();

    // --- 各區塊依目前資料重新繪製 ---
    function renderPhonetic() {
      phon.textContent = (data.dict && data.dict.phonetic) || (data.off && data.off.phonetic) || (data.ai && data.ai.phonetic) || '';
    }

    function renderZh() {
      if (data.off && data.off.found) {
        zh.body.textContent = '';
        for (const line of data.off.lines) {
          const m = /^((?:[a-z]+\.\s*(?:&\s*[a-z]+\.\s*)?)|\[[^\]]+\]\s*)(.*)$/i.exec(line);
          const p = el('p', 'wl-zhline');
          if (m) p.append(el('span', 'wl-zp', m[1].trim()), document.createTextNode(m[2]));
          else p.textContent = line;
          zh.body.appendChild(p);
        }
      } else if (data.ai && data.ai.zh) {
        zh.body.textContent = '';
        zh.body.appendChild(el('p', 'wl-zh', data.ai.zh));
      } else if (data.off && !data.off.found) {
        zh.body.textContent = '';
        zh.body.appendChild(el('p', 'wl-muted', '離線詞典沒有收錄這個字' + (WL.state.settings.aiMode === 'off' ? '。' : '，請參考 AI 說明。')));
      }
    }

    function renderEn() {
      en.body.textContent = '';
      if (data.dict && !data.dict.notFound) {
        for (const g of data.dict.meanings) {
          en.body.appendChild(el('div', 'wl-enpos', g.pos));
          for (const d of g.defs) {
            en.body.appendChild(el('p', 'wl-def', d.def));
            if (d.example) en.body.appendChild(el('p', 'wl-ex', '“' + d.example + '”'));
          }
        }
      } else if (data.ai && data.ai.en_def) {
        en.body.appendChild(el('p', 'wl-def', data.ai.en_def));
        if (data.ai.en_example) en.body.appendChild(el('p', 'wl-ex', '“' + data.ai.en_example + '”'));
        en.body.appendChild(el('p', 'wl-src', '（由 AI 提供）'));
      } else if (!data.dictDone) {
        ui.skeleton(en.body, 2);
      } else {
        en.body.appendChild(el('p', 'wl-muted', data.dictErr ? data.dictErr.message : '英英字典沒有收錄這個字。'));
      }
    }

    function renderAI(ai) {
      data.ai = ai;
      if (ai.pos) addTag('wl-pos', ai.pos);
      if (ai.phrase && ai.phrase.toLowerCase() !== word.toLowerCase()) addTag('wl-phrase', '片語：' + ai.phrase);
      if (!(data.off && data.off.found) && ai.lemma && ai.lemma.toLowerCase() !== word.toLowerCase()) addTag('wl-phrase', '原形：' + ai.lemma);
      ctx.body.textContent = '';
      if (ai.context_zh) ctx.body.appendChild(el('p', 'wl-p', ai.context_zh));
      ctx.body.appendChild(quote());
      if (ai.sentence_zh) ctx.body.appendChild(el('p', 'wl-muted', ai.sentence_zh));
      renderZh();
      renderEn();
      renderPhonetic();
    }

    function refreshSave() {
      const has = (data.off && data.off.found) || (data.dict && !data.dict.notFound) || data.ai;
      if (has && saveBtn.disabled && !saveBtn.dataset.done) saveBtn.disabled = false;
    }

    function done() {
      if (stale()) return;
      refreshSave();
      ui.place();
    }

    // --- AI：依模式決定何時呼叫 ---
    function requestAI() {
      ctx.body.textContent = '';
      ctx.body.appendChild(quote());
      const sk = el('div');
      ui.skeleton(sk, 2);
      ctx.body.appendChild(sk);
      ui.place();
      send({ type: 'ai-word', word, sentence }).then((r) => {
        if (stale()) return;
        if (r.ok) renderAI(r.data);
        else {
          sk.remove();
          ui.showError(ctx.body, r.error, true);
          if (!(data.off && data.off.found)) renderZh();
        }
        done();
      });
    }

    function offerAI() {
      const mode = WL.state.settings.aiMode;
      if (mode === 'auto') {
        setTimeout(() => { if (!stale()) requestAI(); }, AI_DELAY);
      } else if (mode === 'manual') {
        const b = el('button', 'wl-ai-btn', '✨ AI 解釋這個字在本句的意思（使用 1 次額度）');
        b.addEventListener('click', () => { b.remove(); requestAI(); });
        ctx.body.appendChild(b);
      } else {
        ctx.body.appendChild(el('p', 'wl-note', 'AI 已關閉，目前只顯示離線結果（可在工具列圖示開啟）。'));
      }
      ui.place();
    }

    // 先查 AI 快取（免費）；沒有快取才依模式處理
    send({ type: 'ai-word', word, sentence, cacheOnly: true }).then((r) => {
      if (stale()) return;
      if (r.ok && r.data && r.data !== true) renderAI(r.data);
      else offerAI();
      done();
    });

    // --- 離線詞典（瞬間） ---
    send({ type: 'offline', word }).then((r) => {
      if (stale()) return;
      data.off = r.ok ? r.data : { found: false };
      if (data.off.found && data.off.lemma !== word.toLowerCase()) addTag('wl-phrase', '原形：' + data.off.lemma);
      renderZh();
      renderPhonetic();
      done();
    });

    // --- 線上英英字典 ---
    send({ type: 'dict', word }).then((r) => {
      if (stale()) return;
      data.dictDone = true;
      if (r.ok) data.dict = r.data;
      else data.dictErr = r.error;
      renderEn();
      renderPhonetic();
      done();
    });

    // --- 生詞本 ---
    let alreadySaved = false;
    send({ type: 'touch', word }).then((r) => {
      if (stale()) return;
      alreadySaved = !!(r.ok && r.data && r.data.saved);
      if (alreadySaved) {
        saveBtn.textContent = '已在生詞本，加入這個例句';
        lv.show(r.data.level || 1);
      }
    });

    saveBtn.addEventListener('click', async () => {
      saveBtn.disabled = true;
      const { off, dict, ai } = data;
      const hasOff = off && off.found;
      const hasDict = dict && !dict.notFound;
      const firstDef = hasDict && dict.meanings[0] && dict.meanings[0].defs[0];
      const entry = {
        word,
        lemma: (hasOff && off.lemma) || (ai && ai.lemma) || word,
        phonetic: (hasDict && dict.phonetic) || (hasOff && off.phonetic) || (ai ? ai.phonetic : ''),
        audio: hasDict ? dict.audio : '',
        pos: ai ? ai.pos : '',
        zh: (ai && ai.zh) || (hasOff ? off.lines.join('；') : ''),
        phrase: ai ? ai.phrase : '',
        en_def: firstDef ? firstDef.def : ai ? ai.en_def : '',
        en_example: firstDef ? firstDef.example : ai ? ai.en_example : '',
        context: sentence
          ? {
              sentence,
              sentence_zh: ai ? ai.sentence_zh : '',
              context_zh: ai ? ai.context_zh : '',
              url: location.href,
              title: document.title,
              date: new Date().toISOString()
            }
          : null
      };
      const r = await send({ type: 'save-word', entry });
      if (stale()) return;
      if (r.ok) {
        saveBtn.dataset.done = '1';
        saveBtn.textContent = alreadySaved ? '已加入這個例句 ✓' : '已加入生詞本 ✓';
        lv.show(r.data.level || 1);
      } else {
        saveBtn.disabled = false;
        saveBtn.textContent = '儲存失敗，再試一次';
      }
    });
  }

  // ---------- 整句翻譯卡（使用者主動按下，一律直接呼叫；AI 關閉時提示） ----------
  function showSentenceCard(text, rect, anchorNode) {
    const { c, stale, head } = openShell(rect, anchorNode, el('span', 'wl-title', '整句翻譯與解析'));
    head.appendChild(el('span', 'wl-spacer'));
    head.appendChild(iconBtn('🔊', '朗讀原文', () => speak(text)));
    head.appendChild(iconBtn('✕', '關閉（Esc）', ui.closeCard));
    c.appendChild(head);

    const orig = el('div', 'wl-quote wl-orig', text);
    orig.title = '點一下展開全文';
    orig.addEventListener('click', () => { orig.classList.toggle('open'); ui.place(); });
    c.appendChild(orig);

    const tr = ui.section('中文翻譯');
    ui.skeleton(tr.body, 3);
    c.appendChild(tr.s);
    ui.place();

    const mode = WL.state.settings.aiMode;
    send({ type: 'ai-sentence', text, cacheOnly: mode === 'off' }).then((r) => {
      if (stale()) return;
      if (r.ok && !r.data) {
        ui.showError(tr.body, { code: 'AI_OFF', message: 'AI 已關閉，整句翻譯需要 AI（可在工具列圖示開啟）。' });
      } else if (!r.ok) {
        ui.showError(tr.body, r.error);
      } else {
        renderSentence(c, tr, r.data, text, rect, anchorNode);
      }
      ui.place();
    });
  }

  function renderSentence(c, tr, d, text, rect, anchorNode) {
    tr.body.textContent = '';
    tr.body.appendChild(el('p', 'wl-zh', d.translation || '（沒有取得翻譯）'));
    if (d.structure) {
      const st = ui.section('句子結構');
      st.body.appendChild(el('p', 'wl-p', d.structure));
      c.appendChild(st.s);
    }
    if (d.grammar.length) {
      const gr = ui.section('文法重點');
      const ul = el('ul', 'wl-list');
      for (const g of d.grammar) {
        const li = el('li');
        li.append(el('b', null, g.point), document.createTextNode('：' + g.explain));
        ul.appendChild(li);
      }
      gr.body.appendChild(ul);
      c.appendChild(gr.s);
    }
    if (d.vocab.length) {
      const vo = ui.section('值得學的字（點一下查詳細）');
      const chips = el('div', 'wl-chips');
      for (const v of d.vocab) {
        const chip = el('button', 'wl-chip', v.word + '　' + v.zh);
        chip.addEventListener('click', () => {
          const anchor = ui.card ? ui.card._anchor : rect;
          showWordCard(v.word.trim(), text.length <= 500 ? text : text.slice(0, 500), anchor, anchorNode);
        });
        chips.appendChild(chip);
      }
      vo.body.appendChild(chips);
      c.appendChild(vo.s);
    }
  }

  WL.cards = { showWordCard, showSentenceCard };
})();
