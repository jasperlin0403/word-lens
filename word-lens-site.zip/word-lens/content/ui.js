// 查詢卡的外殼：Shadow DOM 隔離樣式、放在瀏覽器最上層、位置校正、共用區塊
(() => {
  const WL = globalThis.__WL;
  if (!WL || WL.dead) return;
  const { el, escapeRe, send } = WL.U;

  let host = null;
  let shadow = null;
  let card = null;
  let floatBtn = null;
  let cardToken = 0;
  let openScrollY = 0;

  const CSS_TEXT = `
    :host { all: initial; }
    * { box-sizing: border-box; }
    button { font-family: inherit; }
    .wl-card {
      position: fixed; width: 360px; max-width: calc(100vw - 16px);
      max-height: min(72vh, 560px); overflow: auto;
      background: #FFFFFF; color: #12303F;
      border: 1px solid #BFDCE8; border-top: 4px solid #1F7AA0; border-radius: 10px;
      box-shadow: 0 12px 32px rgba(18, 48, 63, 0.22);
      font: 14px/1.6 -apple-system, "Segoe UI", "Noto Sans TC", "PingFang TC", "Microsoft JhengHei", sans-serif;
      padding: 14px 16px 12px; text-align: left;
      animation: wl-in .14s ease-out;
    }
    @keyframes wl-in { from { opacity: 0; transform: translateY(4px); } to { opacity: 1; transform: none; } }
    @media (prefers-reduced-motion: reduce) { .wl-card, .wl-skel { animation: none; } }
    .wl-head { display: flex; align-items: center; gap: 8px; flex-wrap: nowrap; }
    .wl-head .wl-word, .wl-head .wl-phon, .wl-head .wl-title { min-width: 0; overflow-wrap: anywhere; }
    .wl-head .wl-icon { flex: 0 0 auto; }
    .wl-word { font: 600 24px/1.2 Georgia, "Times New Roman", serif; color: #0E3A4F; word-break: break-word; }
    .wl-title { font-weight: 600; font-size: 15px; color: #0E3A4F; }
    .wl-phon { color: #4F7A8C; font-size: 13px; }
    .wl-spacer { flex: 1; }
    .wl-icon {
      border: 0; background: #E6F3F8; color: #0E3A4F; border-radius: 6px;
      width: 28px; height: 28px; cursor: pointer; font-size: 14px; line-height: 28px; padding: 0; text-align: center;
    }
    .wl-icon:hover { background: #CFE8F2; }
    button:focus-visible { outline: 2px solid #1F7AA0; outline-offset: 2px; }
    .wl-pos { display: inline-block; margin-top: 6px; margin-right: 6px; font-size: 12px; color: #FFFFFF; background: #1F7AA0; border-radius: 4px; padding: 0 7px; }
    .wl-phrase { display: inline-block; margin-top: 6px; margin-right: 6px; font-size: 12px; color: #0E3A4F; background: #FFE9A8; border-radius: 4px; padding: 0 7px; }
    .wl-sec { margin-top: 12px; }
    .wl-sec h4 { margin: 0 0 4px; font-size: 12px; font-weight: 600; color: #1F7AA0; }
    .wl-zh { font-size: 16px; font-weight: 600; color: #12303F; margin: 0; }
    .wl-zhline { margin: 0 0 2px; font-size: 14.5px; color: #12303F; }
    .wl-zhline .wl-zp { color: #1F7AA0; font-size: 12.5px; font-style: italic; margin-right: 6px; }
    .wl-src { font-size: 11.5px; color: #7C98A4; margin: 2px 0 0; }
    .wl-note { font-size: 12.5px; color: #5E7F8D; background: #F2F8FB; border-radius: 6px; padding: 6px 8px; margin: 4px 0 0; }
    .wl-ai-btn { margin-top: 6px; border: 1px dashed #1F7AA0; background: #FFFFFF; color: #1F7AA0; border-radius: 7px; padding: 5px 10px; font-size: 12.5px; cursor: pointer; }
    .wl-ai-btn:hover { background: #E6F3F8; }
    .wl-levels { display: flex; align-items: center; gap: 4px; margin-top: 8px; flex-wrap: wrap; }
    .wl-levels[hidden] { display: none; }
    .wl-lv-label { font-size: 12px; color: #1F7AA0; font-weight: 600; margin-right: 2px; }
    .wl-lv { border: 1px solid #BFDCE8; background: #FFFFFF; color: #23485A; border-radius: 12px; padding: 1px 8px; font-size: 12px; cursor: pointer; }
    .wl-lv:hover { background: #E6F3F8; }
    .wl-lv.on { background: #1F7AA0; border-color: #1F7AA0; color: #FFFFFF; font-weight: 600; }
    .wl-p { margin: 0 0 4px; }
    .wl-quote {
      margin: 6px 0 4px; padding: 6px 10px; background: #F2F8FB; border-left: 3px solid #9FCDE0;
      border-radius: 0 6px 6px 0; font-family: Georgia, "Times New Roman", serif; font-size: 13.5px; color: #23485A;
    }
    .wl-quote mark { background: #FFE9A8; color: inherit; padding: 0 2px; border-radius: 2px; }
    .wl-orig { display: -webkit-box; -webkit-line-clamp: 4; -webkit-box-orient: vertical; overflow: hidden; cursor: pointer; }
    .wl-orig.open { display: block; }
    .wl-muted { color: #5E7F8D; font-size: 13px; margin: 0; }
    .wl-enpos { font-style: italic; color: #1F7AA0; font-size: 12.5px; margin-top: 6px; }
    .wl-def { margin: 2px 0; }
    .wl-ex { color: #4F7A8C; font-style: italic; font-size: 13px; margin: 0 0 6px; }
    .wl-list { margin: 0; padding-left: 18px; }
    .wl-list li { margin-bottom: 4px; }
    .wl-list b { color: #0E3A4F; }
    .wl-chips { display: flex; flex-wrap: wrap; gap: 6px; }
    .wl-chip {
      border: 1px solid #BFDCE8; background: #F2F8FB; border-radius: 14px; padding: 3px 10px;
      font-size: 13px; cursor: pointer; color: #0E3A4F;
    }
    .wl-chip:hover { background: #E1F0F6; }
    .wl-foot { display: flex; gap: 8px; margin-top: 14px; padding: 10px 0 2px; border-top: 1px solid #E1EEF3; position: sticky; bottom: -12px; background: #FFFFFF; }
    .wl-btn {
      flex: 1; border: 1px solid #1F7AA0; background: #1F7AA0; color: #FFFFFF; border-radius: 7px;
      padding: 7px 10px; font-size: 13px; font-weight: 600; line-height: 1.2; cursor: pointer;
    }
    .wl-btn.ghost { background: #FFFFFF; color: #1F7AA0; }
    .wl-btn:disabled { opacity: .55; cursor: default; }
    .wl-err { color: #A33A2B; font-size: 13px; margin: 0; }
    .wl-link { background: none; border: 0; color: #1F7AA0; text-decoration: underline; cursor: pointer; padding: 0; font-size: 13px; }
    .wl-skel {
      height: 12px; border-radius: 4px; margin: 6px 0;
      background: linear-gradient(90deg, #E6F0F4, #F4F9FB, #E6F0F4); background-size: 200% 100%;
      animation: wl-sh 1.2s linear infinite;
    }
    .wl-skel.short { width: 55%; }
    @keyframes wl-sh { to { background-position: -200% 0; } }
    .wl-trans-btn {
      position: fixed; border: 0; background: #1F7AA0; color: #FFFFFF; border-radius: 16px;
      padding: 5px 12px; font: 600 12.5px/1.2 -apple-system, "Segoe UI", "Noto Sans TC", "PingFang TC", "Microsoft JhengHei", sans-serif;
      box-shadow: 0 4px 12px rgba(18, 48, 63, 0.25); cursor: pointer;
    }
    .wl-trans-btn:hover { background: #17668A; }
    .wl-float { position: fixed; display: flex; gap: 6px; }
    .wl-float .wl-trans-btn { position: static; }
    .wl-chipwrap { display: inline-flex; align-items: center; gap: 3px; }
    .wl-plus { border: 1px solid #1F7AA0; background: #FFFFFF; color: #1F7AA0; border-radius: 50%; width: 24px; height: 24px; font-size: 14px; line-height: 22px; padding: 0; cursor: pointer; flex: 0 0 auto; }
    .wl-plus:hover { background: #E6F3F8; }
    .wl-plus:disabled { border-color: #2F7D4F; color: #2F7D4F; cursor: default; }
  `;

  // 查詢卡所在的容器：若單字位於「強制回應視窗」（modal dialog）內，就放進該視窗，否則放在頁面最上層
  function modalFor(node) {
    const e = node && (node.nodeType === 1 ? node : node.parentElement);
    const d = e && e.closest ? e.closest('dialog') : null;
    try {
      return d && d.open && d.matches(':modal') ? d : null;
    } catch (err) {
      return null;
    }
  }

  function ensureHost(anchorNode) {
    if (!host) {
      host = document.createElement('div');
      host.setAttribute('data-word-lens', '');
      host.style.cssText =
        'all:initial !important;position:fixed !important;top:0 !important;left:0 !important;width:0 !important;height:0 !important;overflow:visible !important;z-index:2147483647 !important;margin:0 !important;padding:0 !important;border:0 !important;background:transparent !important;display:block !important;';
      shadow = host.attachShadow({ mode: 'closed' });
      const style = document.createElement('style');
      style.textContent = CSS_TEXT;
      shadow.appendChild(style);
    }
    const parent = modalFor(anchorNode) || document.documentElement;
    if (host.parentNode !== parent) parent.appendChild(host);
    // 放進瀏覽器的「最上層」（top layer），才不會被網站的彈出視窗蓋住
    if (typeof host.showPopover === 'function') {
      try {
        if (!host.hasAttribute('popover')) host.setAttribute('popover', 'manual');
        if (host.matches(':popover-open')) host.hidePopover();
        host.showPopover();
      } catch (e) { /* 舊版瀏覽器：維持最高 z-index */ }
    }
  }

  function closeCard() {
    if (card) card.remove();
    card = null;
    cardToken++;
  }

  function hideFloatBtn() {
    if (floatBtn) floatBtn.remove();
    floatBtn = null;
  }

  // 定位後再量一次實際位置並校正（外層容器有 transform 時，fixed 定位會偏移）
  function setPos(elm, left, top) {
    elm.style.left = left + 'px';
    elm.style.top = top + 'px';
    const r = elm.getBoundingClientRect();
    const dx = r.left - left;
    const dy = r.top - top;
    if (Math.abs(dx) > 1 || Math.abs(dy) > 1) {
      elm.style.left = left - dx + 'px';
      elm.style.top = top - dy + 'px';
    }
  }

  function openCard(anchorRect, anchorNode) {
    closeCard();
    ensureHost(anchorNode);
    card = el('div', 'wl-card');
    card.setAttribute('role', 'dialog');
    card._anchor = anchorRect;
    card._node = anchorNode;
    shadow.appendChild(card);
    openScrollY = window.scrollY;
    WL.lastCardAt = Date.now();
    return { c: card, token: cardToken };
  }

  function place() {
    if (!card) return;
    const a = card._anchor;
    const w = card.offsetWidth;
    const h = card.offsetHeight;
    const vw = window.innerWidth;
    const vh = window.innerHeight;
    const left = Math.min(Math.max(8, a.left), Math.max(8, vw - w - 8));
    let top = a.bottom + 8;
    if (top + h > vh - 8) {
      const above = a.top - h - 8;
      top = above >= 8 ? above : Math.max(8, vh - h - 8);
    }
    setPos(card, left, top);
  }

  function section(title) {
    const s = el('div', 'wl-sec');
    s.appendChild(el('h4', null, title));
    const body = el('div');
    s.appendChild(body);
    return { s, body };
  }

  function skeleton(body, lines = 2) {
    body.textContent = '';
    for (let i = 0; i < lines; i++) body.appendChild(el('div', 'wl-skel' + (i === lines - 1 ? ' short' : '')));
  }

  function showError(body, err, append) {
    if (!append) body.textContent = '';
    // 額度暫停、AI 關閉屬於預期狀態：用灰色提示，不用紅色錯誤
    const expected = err.code === 'PAUSED' || err.code === 'AI_OFF';
    body.appendChild(el('p', expected ? 'wl-note' : 'wl-err', err.message));
    if (['NO_KEY', 'BAD_KEY', 'BAD_MODEL', 'MODEL_NOT_FREE'].includes(err.code)) {
      const link = el('button', 'wl-link', '前往設定');
      link.addEventListener('click', () => send({ type: 'open-options' }));
      body.appendChild(link);
    }
  }

  function quoteWithMark(sentence, word) {
    const q = el('div', 'wl-quote');
    const w = escapeRe(word);
    const stem = word.length > 3 ? escapeRe(word.replace(/(e|y|ies|es|s|ed|ing)$/i, '')) : w;
    const candidates = [
      new RegExp('\\b' + w + '\\b', 'i'),
      new RegExp('\\b' + w + '[a-z]*', 'i'),
      new RegExp('\\b' + stem + '[a-z]*', 'i')
    ];
    let m = null;
    for (const re of candidates) {
      m = re.exec(sentence);
      if (m) break;
    }
    if (!m) {
      q.textContent = sentence;
      return q;
    }
    q.appendChild(document.createTextNode(sentence.slice(0, m.index)));
    q.appendChild(el('mark', null, m[0]));
    q.appendChild(document.createTextNode(sentence.slice(m.index + m[0].length)));
    return q;
  }

  // 浮動按鈕（「查單字」「查片語」「翻譯整句」），可同時顯示多顆
  function showFloatBtns(list, lastRect, anchorNode) {
    if (card) return;
    hideFloatBtn();
    ensureHost(anchorNode);
    const g = el('div', 'wl-float');
    for (const { label, onClick } of list) {
      const b = el('button', 'wl-trans-btn', label);
      b.addEventListener('mousedown', (ev) => ev.preventDefault());
      b.addEventListener('click', () => {
        hideFloatBtn();
        onClick();
      });
      g.appendChild(b);
    }
    shadow.appendChild(g);
    const left = Math.min(Math.max(8, lastRect.right + 6), window.innerWidth - g.offsetWidth - 8);
    const top = Math.min(Math.max(8, lastRect.bottom + 6), window.innerHeight - 36);
    setPos(g, left, top);
    floatBtn = g;
  }
  const showFloatBtn = (label, lastRect, anchorNode, onClick) => showFloatBtns([{ label, onClick }], lastRect, anchorNode);

  WL.onShutdown(() => {
    closeCard();
    hideFloatBtn();
    if (host) host.remove();
  });

  WL.ui = {
    openCard, closeCard, place, section, skeleton, showError, quoteWithMark, showFloatBtn, showFloatBtns, hideFloatBtn,
    get card() { return card; },
    get token() { return cardToken; },
    get openScrollY() { return openScrollY; },
    isOurs: (e) => !!host && e.composedPath().includes(host),
    hasFloatBtn: () => !!floatBtn
  };
})();
