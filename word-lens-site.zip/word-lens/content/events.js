// 使用者操作：雙擊、選取、按住 Ctrl 指著單字、鍵盤；以及載入設定與生詞本
(() => {
  const WL = globalThis.__WL;
  if (!WL || WL.dead) return;
  const { WORD_RE } = WL.U;
  const { ui, cards, locate, highlight } = WL;
  const S = () => WL.state.settings;
  const WEB = !!globalThis.WL_WEB; // 網頁版（iPad 等觸控裝置）
  // PDF 閱讀器開著螢光筆／橡皮擦時，選取文字是用來標記，不顯示查字按鈕
  const toolActive = () => document.body && (document.body.classList.contains('marking') || document.body.classList.contains('erasing'));

  function isEditable(node) {
    if (!node || node.nodeType !== 1) return false;
    if (node.isContentEditable) return true;
    return !!(node.closest && node.closest('input, textarea, select'));
  }

  function openWord(word, range) {
    ui.hideFloatBtn();
    cards.showWordCard(word, locate.extractSentence(range), range.getBoundingClientRect(), range.startContainer);
  }

  // ---------- 雙擊 ----------
  WL.onWin('dblclick', (e) => {
    if (!S().enabled || ui.isOurs(e)) return;
    const path = e.composedPath();
    if (isEditable(path[0])) return;
    const hit = locate.wordRangeAtPoint(e.clientX, e.clientY, path);
    if (hit && hit.word.length <= 40 && WORD_RE.test(hit.word)) return openWord(hit.word, hit.range);
    const sel = window.getSelection();
    if (!sel || sel.rangeCount === 0) return;
    const raw = sel.toString().trim().replace(/^[^A-Za-z]+|[^A-Za-z]+$/g, '');
    if (raw && raw.length <= 40 && WORD_RE.test(raw)) openWord(raw, sel.getRangeAt(0));
  });

  // ---------- 選取文字 → 「查單字」或「翻譯整句」按鈕 ----------
  function handleSelection() {
    if (WL.dead || !S().enabled || toolActive() || Date.now() - WL.lastCardAt < 700) return;
    const sel = window.getSelection();
    if (!sel || sel.isCollapsed || sel.rangeCount === 0) return;
    const text = sel.toString().replace(/\s+/g, ' ').trim();
    if (!text) return;
    const range = sel.getRangeAt(0);
    const rects = range.getClientRects();
    const last = rects.length ? rects[rects.length - 1] : range.getBoundingClientRect();
    const full = range.getBoundingClientRect();
    const anchor = range.startContainer;
    const word = text.replace(/^[^A-Za-z]+|[^A-Za-z]+$/g, '');
    if (!/\s/.test(text) && word.length <= 40 && WORD_RE.test(word)) {
      const sentence = locate.extractSentence(range);
      ui.showFloatBtn('查單字', last, anchor, () => cards.showWordCard(word, sentence, full, anchor));
      return;
    }
    if (text.length < 3 || text.length > 2000) return;
    if ((text.match(/[A-Za-z]{2,}/g) || []).length < 2) return;
    // 2–6 個英文字 → 可能是片語：同時提供「查片語」（可加入生詞本）與「翻譯整句」
    const tokens = text.split(/\s+/).map((t) => t.replace(/^[^A-Za-z]+|[^A-Za-z]+$/g, ''));
    if (text.length <= 60 && tokens.length >= 2 && tokens.length <= 6 && tokens.every((t) => WORD_RE.test(t))) {
      const phrase = tokens.join(' ');
      const sentence = locate.extractSentence(range);
      ui.showFloatBtns([
        { label: '查片語', onClick: () => cards.showWordCard(phrase, sentence, full, anchor) },
        { label: '翻譯整句', onClick: () => cards.showSentenceCard(text, full, anchor) }
      ], last, anchor);
      return;
    }
    ui.showFloatBtn('翻譯整句', last, anchor, () => cards.showSentenceCard(text, full, anchor));
  }

  WL.onWin('mouseup', (e) => {
    if (WEB || !S().enabled || ui.isOurs(e) || e.detail === 2) return;
    if (isEditable(e.composedPath()[0])) return;
    setTimeout(handleSelection, 300);
  });

  if (WEB) {
    // 觸控選取不會觸發滑鼠事件：選取停止一下子後再顯示按鈕
    let selTimer = null;
    document.addEventListener('selectionchange', () => {
      clearTimeout(selTimer);
      selTimer = setTimeout(() => {
        const sel = window.getSelection();
        const n = sel && sel.anchorNode;
        const elm = n && (n.nodeType === 1 ? n : n.parentElement);
        if (elm && isEditable(elm)) return;
        handleSelection();
      }, 600);
    });
    WL.onShutdown(() => clearTimeout(selTimer));

    // 點一下單字即查詢（只在標示 data-wl-tap 的閱讀區，例如貼上的文章、PDF）
    WL.onWin('click', (e) => {
      if (!S().enabled || ui.isOurs(e) || toolActive()) return;
      const path = e.composedPath();
      if (!path.some((n) => n && n.nodeType === 1 && n.hasAttribute && n.hasAttribute('data-wl-tap'))) return;
      const sel = window.getSelection();
      if (sel && !sel.isCollapsed) return;
      const hit = locate.wordRangeAtPoint(e.clientX, e.clientY, path);
      if (hit && hit.word.length <= 40 && WORD_RE.test(hit.word)) openWord(hit.word, hit.range);
    });
  }

  // ---------- 按住 Ctrl 指著單字 ----------
  let lastMouse = null;
  let hoverTimer = null;
  let lastHoverKey = '';

  function hoverLookup() {
    if (WL.dead || !lastMouse || lastMouse.inUI || !S().enabled || !S().hover) return;
    const hit = locate.wordRangeAtPoint(lastMouse.x, lastMouse.y, lastMouse.path);
    if (!hit || hit.word.length > 40 || !WORD_RE.test(hit.word)) return;
    const r = hit.range.getBoundingClientRect();
    const key = hit.word + '@' + Math.round(r.left) + ',' + Math.round(r.top);
    if (ui.card && key === lastHoverKey) return;
    lastHoverKey = key;
    openWord(hit.word, hit.range);
  }

  const scheduleHover = (ms) => {
    clearTimeout(hoverTimer);
    hoverTimer = setTimeout(hoverLookup, ms);
  };

  WL.onWin('mousemove', (e) => {
    lastMouse = { x: e.clientX, y: e.clientY, path: e.composedPath(), inUI: ui.isOurs(e) };
    if (!e.ctrlKey || e.buttons || lastMouse.inUI) return clearTimeout(hoverTimer);
    if (S().enabled && S().hover) scheduleHover(220);
  }, { capture: true, passive: true });

  WL.onWin('keydown', (e) => {
    if (e.key === 'Escape') {
      ui.closeCard();
      ui.hideFloatBtn();
    } else if (e.key === 'Control') {
      // 游標已停在字上時按下 Ctrl 也會查詢；稍等一下，避免與 Ctrl+C 等快捷鍵衝突
      if (!e.repeat && S().enabled && S().hover) scheduleHover(350);
    } else {
      clearTimeout(hoverTimer);
    }
  });

  WL.onWin('wheel', () => clearTimeout(hoverTimer), { capture: true, passive: true });

  WL.onWin('mousedown', (e) => {
    clearTimeout(hoverTimer);
    if (ui.isOurs(e)) return;
    ui.closeCard();
    ui.hideFloatBtn();
  });

  document.addEventListener('selectionchange', () => {
    if (WL.dead || !ui.hasFloatBtn()) return;
    const sel = window.getSelection();
    if (!sel || sel.isCollapsed) ui.hideFloatBtn();
  });

  WL.onWin('scroll', () => {
    ui.hideFloatBtn();
    if (ui.card && Math.abs(window.scrollY - ui.openScrollY) > 120) ui.closeCard();
  }, { passive: true });

  WL.onShutdown(() => clearTimeout(hoverTimer));

  // ---------- 載入設定與生詞本（只讀 settings 與 words；API 金鑰不在這裡） ----------
  try {
    chrome.storage.local.get(['settings', 'words'], (res) => {
      if (chrome.runtime.lastError || WL.dead) return;
      Object.assign(WL.state.settings, (res && res.settings) || {});
      WL.state.words = (res && res.words) || {};
      highlight.refresh(true);
    });
    const onChange = (changes, area) => {
      if (area !== 'local' || WL.dead) return;
      if (changes.settings) {
        Object.assign(WL.state.settings, changes.settings.newValue || {});
        if (!S().enabled) {
          ui.closeCard();
          ui.hideFloatBtn();
        }
      }
      if (changes.words) WL.state.words = changes.words.newValue || {};
      if (changes.settings || changes.words) highlight.refresh(false);
    };
    chrome.storage.onChanged.addListener(onChange);
    WL.onShutdown(() => chrome.storage.onChanged.removeListener(onChange));
  } catch (e) {
    WL.shutdown();
  }
})();
