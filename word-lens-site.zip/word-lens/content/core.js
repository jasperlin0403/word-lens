// 網頁端核心：命名空間、設定狀態、新舊版本交接
// 載入順序（見 manifest）：shared/util.js → core → locate → ui → cards → highlight → events
// 每個檔案都以 const WL = globalThis.__WL 取得「這一次載入」的命名空間；
// 擴充功能更新後重新注入時會建立新的命名空間，舊版自動停用。
(() => {
  const WL = {
    id: Math.random().toString(36).slice(2),
    dead: false,
    U: globalThis.WLUtil,
    state: {
      settings: { enabled: true, highlight: true, hover: true, aiMode: 'auto' },
      words: {}
    },
    lastCardAt: 0
  };

  const cleanups = [];
  WL.onShutdown = (fn) => cleanups.push(fn);
  WL.shutdown = () => {
    if (WL.dead) return;
    WL.dead = true;
    for (const fn of cleanups) {
      try { fn(); } catch (e) { /* 忽略 */ }
    }
  };

  // 在 window 的捕獲階段最先接收事件，避免被網站攔截；停用後自動失效
  WL.onWin = (type, fn, opts) => window.addEventListener(type, (e) => { if (!WL.dead) fn(e); }, opts || true);

  try {
    document.dispatchEvent(new CustomEvent('wordlens-takeover', { detail: WL.id }));
  } catch (e) { /* 忽略 */ }
  document.addEventListener('wordlens-takeover', (e) => {
    if (e.detail !== WL.id) WL.shutdown();
  });

  globalThis.__WL = WL;
})();
