// 點字學英文 — PDF 閱讀器（以 Mozilla pdf.js 為核心）
// 查字、翻譯、標色由同頁載入的 content.js 負責；本檔負責開檔、翻頁、縮放、搜尋、目錄、螢光筆、閱讀進度

import * as pdfjsLib from './lib/pdf.min.mjs';
import * as G from './marks-geometry.mjs';
import { annotatedPdf, marksText } from './export.mjs';
globalThis.pdfjsLib = pdfjsLib;
const pdfjsViewer = await import('./lib/pdf_viewer.mjs');

const LIB = new URL('./lib/', import.meta.url).href;

// 載入查字功能（與網頁端相同的程式）
if (!globalThis.WLUtil) {
  await new Promise((resolve) => {
    const s = document.createElement('script');
    s.src = chrome.runtime.getURL('shared/util.js');
    s.onload = s.onerror = resolve;
    document.head.appendChild(s);
  });
}
await globalThis.WLUtil.loadContent();
const { send, el } = globalThis.WLUtil;
pdfjsLib.GlobalWorkerOptions.workerSrc = LIB + 'pdf.worker.min.mjs';

const $ = (id) => document.getElementById(id);

// ---------- pdf.js 閱讀元件 ----------
const container = $('viewerContainer');
const WEB = !!globalThis.WL_WEB;
if (WEB) {
  $('btnHome').hidden = false;
  container.setAttribute('data-wl-tap', ''); // 網頁版：點一下單字即查詢
  $('homeIntro').textContent = '點一下英文單字即可查詢；選取句子可翻譯；螢光筆請先選取文字再按確認；會自動記住讀到哪一頁。';
  $('dropHint').textContent = '按這裡從「檔案」App 選擇 PDF';
  document.querySelector('#drop strong').textContent = '開啟 PDF';
}
const eventBus = new pdfjsViewer.EventBus();
const linkService = new pdfjsViewer.PDFLinkService({ eventBus, externalLinkTarget: pdfjsViewer.LinkTarget.BLANK });
const findController = new pdfjsViewer.PDFFindController({ eventBus, linkService });
const pdfViewer = new pdfjsViewer.PDFViewer({ container, eventBus, linkService, findController });
linkService.setViewer(pdfViewer);

let doc = null;
let originalBytes = null; // 原始 PDF（匯出時使用；PDF 引擎讀取後會接管原資料，所以另存一份）
let loadingTask = null;
let fp = '';
let meta = { name: '', url: '' };
let marks = [];
let pendingRestore = null;
let tool = 'none'; // none｜marker｜eraser
let markerColor = 'yellow';
let undoStack = [];
let redoStack = [];

// ---------- 儲存（chrome.storage.local） ----------
const store = {
  async get(key) {
    const r = await chrome.storage.local.get(key);
    return r[key];
  },
  async set(key, val) {
    await chrome.storage.local.set({ [key]: val });
  }
};

// ---------- 開啟 PDF ----------
function showHomeError(msg) {
  $('loading').hidden = true;
  $('home').hidden = false;
  const e = $('homeError');
  e.textContent = msg;
  e.hidden = !msg;
}

function nameFromUrl(url) {
  try {
    const u = new URL(url);
    const last = decodeURIComponent(u.pathname.split('/').filter(Boolean).pop() || '');
    return last || u.hostname;
  } catch (e) {
    return 'PDF';
  }
}

function nameFromDisposition(h) {
  if (!h) return '';
  const star = /filename\*\s*=\s*[^']*''([^;]+)/i.exec(h);
  if (star) {
    try { return decodeURIComponent(star[1].trim().replace(/"/g, '')); } catch (e) { /* 忽略 */ }
  }
  const plain = /filename\s*=\s*"?([^";]+)"?/i.exec(h);
  return plain ? plain[1].trim() : '';
}

function isPdfBytes(buf) {
  const head = new Uint8Array(buf.slice(0, 1024));
  let s = '';
  for (const b of head) s += String.fromCharCode(b);
  return s.includes('%PDF');
}

function readFileUrl(url) {
  // fetch() 不支援 file:// 網址，本機檔改用 XHR（需開啟「允許存取檔案網址」）
  return new Promise((resolve, reject) => {
    const x = new XMLHttpRequest();
    x.open('GET', url);
    x.responseType = 'arraybuffer';
    x.onload = () => (x.response && x.response.byteLength ? resolve(x.response) : reject(new Error('empty')));
    x.onerror = () => reject(new Error('file-denied'));
    x.send();
  });
}

async function loadFromUrl(url) {
  $('loading').hidden = false;
  if (/^(blob|data):/i.test(url)) {
    showHomeError('這個 PDF 是網站暫時產生的，無法直接讀取。\n請先把 PDF 下載到電腦，再按「開啟檔案」選擇它。');
    return;
  }
  let buf;
  let name = nameFromUrl(url);
  try {
    if (/^file:/i.test(url)) {
      buf = await readFileUrl(url);
    } else {
      const res = await fetch(url, { credentials: 'include' });
      if (!res.ok) throw new Error('http-' + res.status);
      name = nameFromDisposition(res.headers.get('content-disposition')) || name;
      buf = await res.arrayBuffer();
    }
  } catch (e) {
    const msg = String(e.message || e);
    if (msg === 'file-denied') {
      showHomeError('無法讀取電腦裡的這個檔案。\n請到 chrome://extensions →「點字學英文」的「詳細資料」→ 開啟「允許存取檔案網址」；或直接按上方區塊選擇檔案。');
    } else if (/^http-(401|403)$/.test(msg)) {
      showHomeError('網站拒絕讀取（可能需要登入）。\n請先在原網站把 PDF 下載到電腦，再按上方區塊選擇檔案。');
    } else {
      showHomeError('無法下載這個 PDF（' + msg + '）。\n請先在原網站把 PDF 下載到電腦，再按上方區塊選擇檔案。');
    }
    return;
  }
  if (!isPdfBytes(buf)) {
    showHomeError('這個網址回傳的不是 PDF，可能需要先登入原網站。\n請先把 PDF 下載到電腦，再按上方區塊選擇檔案。');
    return;
  }
  await openDocument(buf, { name, url });
}

async function loadFromFile(file) {
  if (!file) return;
  if (!/\.pdf$/i.test(file.name) && file.type !== 'application/pdf') {
    showHomeError('請選擇 PDF 檔案。');
    return;
  }
  $('loading').hidden = false;
  const buf = await file.arrayBuffer();
  if (!isPdfBytes(buf)) {
    showHomeError('這個檔案不是有效的 PDF。');
    return;
  }
  // 本機檔案：把網址列清掉，避免重新整理時載入舊網址
  history.replaceState(null, '', location.pathname);
  await openDocument(buf, { name: file.name, url: '' });
}

async function openDocument(buf, m) {
  showHomeError('');
  $('loading').hidden = false;
  try {
    if (loadingTask) await loadingTask.destroy();
  } catch (e) { /* 忽略 */ }
  const bytes = new Uint8Array(buf);
  originalBytes = bytes.slice();
  loadingTask = pdfjsLib.getDocument({
    data: bytes,
    cMapUrl: LIB + 'cmaps/',
    cMapPacked: true,
    standardFontDataUrl: LIB + 'standard_fonts/',
    wasmUrl: LIB + 'wasm/',
    iccUrl: LIB + 'iccs/'
  });
  loadingTask.onPassword = (update, reason) => {
    const p = prompt(reason === pdfjsLib.PasswordResponses.INCORRECT_PASSWORD ? '密碼錯誤，請重新輸入 PDF 密碼：' : '這份 PDF 有密碼保護，請輸入密碼：');
    if (p === null) loadingTask.destroy();
    else update(p);
  };
  try {
    doc = await loadingTask.promise;
  } catch (e) {
    showHomeError('無法開啟這份 PDF：' + (e && e.message ? e.message : e));
    return;
  }

  meta = m;
  fp = (doc.fingerprints && doc.fingerprints[0]) || m.name;
  let title = m.name;
  try {
    const md = await doc.getMetadata();
    const t = md && md.info && md.info.Title;
    if (t && t.trim().length > 3 && !/^untitled$|^microsoft word/i.test(t.trim())) title = t.trim();
  } catch (e) { /* 忽略 */ }
  $('docTitle').textContent = title;
  $('docTitle').title = m.name;
  document.title = title + '｜PDF 閱讀器';
  meta.title = title;

  const pr = await send({ type: 'pdf-progress-get', fp });
  pendingRestore = pr.ok ? pr.data || null : null;
  const allMarks = (await store.get('pdfMarks')) || {};
  marks = allMarks[fp] || [];
  undoStack = [];
  redoStack = [];
  updateUndo();

  pdfViewer.setDocument(doc);
  linkService.setDocument(doc, null);
  $('pageCount').textContent = '/ ' + doc.numPages;
  $('home').hidden = true;
  $('loading').hidden = true;

  $('btnExport').disabled = false;
  buildOutline();
  buildThumbs();
  buildMarksPanel();
  saveProgress(true);
}

eventBus.on('pagesinit', () => {
  const p = pendingRestore;
  pdfViewer.currentScaleValue = (p && p.scale) || 'page-width';
  if (p && p.page > 1 && doc) pdfViewer.currentPageNumber = Math.min(p.page, doc.numPages);
  pendingRestore = null;
});

// ---------- 閱讀進度與最近開啟 ----------
let saveTimer = null;
function saveProgress(now) {
  clearTimeout(saveTimer);
  const run = async () => {
    if (!doc || !fp) return;
    await send({
      type: 'pdf-progress-set',
      fp,
      data: {
        page: pdfViewer.currentPageNumber || 1,
        pages: doc.numPages,
        scale: pdfViewer.currentScaleValue || 'page-width',
        name: meta.title || meta.name,
        file: meta.name,
        url: meta.url || '',
        time: Date.now()
      }
    });
  };
  if (now) run();
  else saveTimer = setTimeout(run, 800);
}

async function renderRecent() {
  const r = await send({ type: 'pdf-progress-list' });
  const list = r.ok ? r.data : [];
  const ul = $('recent');
  ul.textContent = '';
  if (!list.length) {
    ul.appendChild(el('li', 'muted', '還沒有開啟過 PDF。'));
    return;
  }
  for (const r of list) {
    const li = el('li');
    li.appendChild(el('div', 'n', r.name));
    const d = el('div', 'd');
    d.append('上次讀到第 ' + r.page + ' / ' + r.pages + ' 頁 · ' + new Date(r.time).toLocaleDateString('zh-TW') + ' · ');
    if (r.url) {
      const a = el('a', null, '繼續閱讀');
      a.addEventListener('click', () => {
        location.search = '?file=' + encodeURIComponent(r.url);
      });
      d.appendChild(a);
    } else {
      d.append('本機檔案「' + r.file + '」：重新選擇該檔案即可回到上次頁數');
    }
    li.appendChild(d);
    ul.appendChild(li);
  }
}

// ---------- 工具列：翻頁與縮放 ----------
eventBus.on('pagechanging', ({ pageNumber }) => {
  $('pageInput').value = pageNumber;
  document.querySelectorAll('.thumb.cur').forEach((t) => t.classList.remove('cur'));
  const t = document.querySelector('.thumb[data-page="' + pageNumber + '"]');
  if (t) t.classList.add('cur');
  saveProgress();
});

eventBus.on('scalechanging', ({ scale, presetValue }) => {
  const sel = $('zoomSelect');
  const opt = [...sel.options].find((o) => o.value === String(presetValue || scale));
  if (opt && opt.value !== 'custom') {
    sel.value = opt.value;
    $('zoomCustom').hidden = true;
  } else {
    $('zoomCustom').hidden = false;
    $('zoomCustom').textContent = Math.round(scale * 100) + '%';
    sel.value = 'custom';
  }
  saveProgress();
});

$('btnPrev').addEventListener('click', () => { if (doc) pdfViewer.currentPageNumber = Math.max(1, pdfViewer.currentPageNumber - 1); });
$('btnNext').addEventListener('click', () => { if (doc) pdfViewer.currentPageNumber = Math.min(doc.numPages, pdfViewer.currentPageNumber + 1); });
$('pageInput').addEventListener('change', (e) => {
  if (!doc) return;
  const n = parseInt(e.target.value, 10);
  if (n >= 1 && n <= doc.numPages) pdfViewer.currentPageNumber = n;
  else e.target.value = pdfViewer.currentPageNumber;
});
$('zoomSelect').addEventListener('change', (e) => {
  if (doc && e.target.value !== 'custom') pdfViewer.currentScaleValue = e.target.value;
  container.focus({ preventScroll: true }); // 讓 H、E、Ctrl+Z 等快捷鍵立即可用
});
$('pageInput').addEventListener('keydown', (e) => {
  if (e.key === 'Enter') container.focus({ preventScroll: true }); // 觸發 change 並把焦點還給閱讀區
});
$('btnZoomIn').addEventListener('click', () => doc && pdfViewer.increaseScale());
$('btnZoomOut').addEventListener('click', () => doc && pdfViewer.decreaseScale());

// ---------- 開檔 ----------
$('btnOpen').addEventListener('click', () => $('fileInput').click());
$('drop').addEventListener('click', () => $('fileInput').click());
$('drop').addEventListener('keydown', (e) => { if (e.key === 'Enter' || e.key === ' ') $('fileInput').click(); });
$('fileInput').addEventListener('change', (e) => {
  loadFromFile(e.target.files[0]);
  e.target.value = '';
});
document.addEventListener('dragover', (e) => {
  e.preventDefault();
  $('drop').classList.add('over');
});
document.addEventListener('dragleave', () => $('drop').classList.remove('over'));
document.addEventListener('drop', (e) => {
  e.preventDefault();
  $('drop').classList.remove('over');
  const f = e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0];
  if (f) loadFromFile(f);
});

// ---------- 全文搜尋 ----------
function find(type, previous) {
  const query = $('findInput').value;
  if (!query) {
    eventBus.dispatch('findbarclose', { source: window });
    $('findCount').textContent = '';
    return;
  }
  eventBus.dispatch('find', {
    source: window, type, query, caseSensitive: false, entireWord: false,
    highlightAll: true, findPrevious: !!previous, matchDiacritics: false
  });
}
$('findInput').addEventListener('input', () => find('', false));
$('findInput').addEventListener('keydown', (e) => {
  if (e.key === 'Enter') {
    e.preventDefault();
    find('again', e.shiftKey);
  } else if (e.key === 'Escape') {
    $('findInput').value = '';
    find('', false);
  }
});
$('findNext').addEventListener('click', () => find('again', false));
$('findPrev').addEventListener('click', () => find('again', true));
eventBus.on('updatefindmatchescount', ({ matchesCount }) => showCount(matchesCount));
eventBus.on('updatefindcontrolstate', ({ state, matchesCount }) => {
  if (state === pdfjsViewer.FindState.NOT_FOUND) $('findCount').textContent = '找不到';
  else showCount(matchesCount);
});
function showCount(m) {
  if (!m || !$('findInput').value) return;
  $('findCount').textContent = m.total ? m.current + ' / ' + m.total : '';
}

// ---------- 側欄：目錄、頁面、標記 ----------
function setSidebar(open) {
  $('sidebar').hidden = !open;
  document.body.classList.toggle('side-open', open);
}

// 閱讀區大小改變（開關側欄、調整視窗）時，重新套用「符合寬度／整頁／自動」
// （等 pdf.js 更新它內部記錄的容器尺寸後再套用，否則會用到舊寬度）
let resizeTimer = null;
new ResizeObserver(() => {
  clearTimeout(resizeTimer);
  resizeTimer = setTimeout(() => {
    if (!doc) return;
    const v = pdfViewer.currentScaleValue;
    if (v === 'page-width' || v === 'page-fit' || v === 'auto') pdfViewer.currentScaleValue = v;
  }, 60);
}).observe(container);
$('btnSidebar').addEventListener('click', () => setSidebar($('sidebar').hidden));
document.querySelectorAll('.tab').forEach((t) =>
  t.addEventListener('click', () => {
    document.querySelectorAll('.tab').forEach((x) => x.classList.toggle('on', x === t));
    for (const name of ['outline', 'pages', 'marks']) $('panel-' + name).hidden = name !== t.dataset.tab;
  })
);

async function buildOutline() {
  const panel = $('panel-outline');
  panel.textContent = '';
  let outline = null;
  try {
    outline = await doc.getOutline();
  } catch (e) { /* 忽略 */ }
  if (!outline || !outline.length) {
    panel.appendChild(el('div', 'empty', '這份 PDF 沒有內建目錄，請改用「頁面」分頁。'));
    return;
  }
  const build = (items) => {
    const ul = el('ul');
    for (const it of items) {
      const li = el('li');
      const a = el('a', null, it.title || '（無標題）');
      a.addEventListener('click', () => {
        if (it.dest) linkService.goToDestination(it.dest);
        else if (it.url) window.open(it.url, '_blank', 'noopener');
      });
      li.appendChild(a);
      if (it.items && it.items.length) li.appendChild(build(it.items));
      ul.appendChild(li);
    }
    return ul;
  };
  const wrap = el('div', 'outline');
  wrap.appendChild(build(outline));
  panel.appendChild(wrap);
}

let thumbObserver = null;
function buildThumbs() {
  const panel = $('panel-pages');
  panel.textContent = '';
  if (thumbObserver) thumbObserver.disconnect();
  const myDoc = doc;
  thumbObserver = new IntersectionObserver(
    (entries) => {
      for (const en of entries) {
        if (!en.isIntersecting) continue;
        const btn = en.target;
        thumbObserver.unobserve(btn);
        renderThumb(myDoc, btn);
      }
    },
    { root: panel, rootMargin: '300px' }
  );
  for (let i = 1; i <= doc.numPages; i++) {
    const b = el('button', 'thumb');
    b.dataset.page = i;
    b.appendChild(el('div', 'ph'));
    b.appendChild(el('span', null, '第 ' + i + ' 頁'));
    b.addEventListener('click', () => { pdfViewer.currentPageNumber = i; });
    panel.appendChild(b);
    thumbObserver.observe(b);
  }
}

async function renderThumb(myDoc, btn) {
  try {
    const page = await myDoc.getPage(+btn.dataset.page);
    const base = page.getViewport({ scale: 1 });
    const dpr = window.devicePixelRatio || 1;
    const viewport = page.getViewport({ scale: (150 / base.width) * dpr });
    const canvas = document.createElement('canvas');
    canvas.width = Math.floor(viewport.width);
    canvas.height = Math.floor(viewport.height);
    await page.render({ canvas, viewport }).promise;
    if (myDoc !== doc) return;
    btn.querySelector('.ph')?.replaceWith(canvas);
  } catch (e) { /* 縮圖失敗不影響閱讀 */ }
}

// ---------- 螢光筆、橡皮擦、復原 ----------
// 幾何運算在 marks-geometry.mjs；這裡負責畫面、儲存與操作紀錄
const COLOR_HEX = { yellow: '#FFD84D', green: '#7EDC8A', pink: '#FF9EBB' };

function setTool(t) {
  tool = tool === t ? 'none' : t;
  $('btnMarker').setAttribute('aria-pressed', String(tool === 'marker'));
  $('btnEraser').setAttribute('aria-pressed', String(tool === 'eraser'));
  document.body.classList.toggle('marking', tool === 'marker');
  document.body.classList.toggle('erasing', tool === 'eraser');
}
$('btnMarker').addEventListener('click', () => setTool('marker'));
$('btnEraser').addEventListener('click', () => setTool('eraser'));
document.querySelectorAll('#colors .dot').forEach((d) =>
  d.addEventListener('click', () => {
    markerColor = d.dataset.color;
    document.querySelectorAll('#colors .dot').forEach((x) => x.classList.toggle('on', x === d));
    if (tool !== 'marker') setTool('marker');
  })
);

function pageLayer(pageNumber) {
  const pv = pdfViewer.getPageView(pageNumber - 1);
  return pv && pv.div ? pv.div : null;
}

function renderMarks(pageNumber) {
  const div = pageLayer(pageNumber);
  if (!div) return;
  div.querySelectorAll(':scope > .wl-marks').forEach((x) => x.remove());
  const mine = marks.filter((m) => m.page === pageNumber);
  if (!mine.length) return;
  const layer = el('div', 'wl-marks');
  for (const m of mine) {
    for (const [x, y, w, h] of m.rects) {
      const d = el('div', m.color);
      d.dataset.id = m.id;
      d.style.left = x * 100 + '%';
      d.style.top = y * 100 + '%';
      d.style.width = w * 100 + '%';
      d.style.height = h * 100 + '%';
      layer.appendChild(d);
    }
  }
  const canvasWrapper = div.querySelector(':scope > .canvasWrapper');
  if (canvasWrapper) canvasWrapper.after(layer);
  else div.prepend(layer);
}
eventBus.on('pagerendered', ({ pageNumber }) => renderMarks(pageNumber));

// 從文字層擷取標記範圍內的文字（標記被切割或合併後重新計算）
function textFor(pageNumber, rects) {
  const div = pageLayer(pageNumber);
  const tl = div && div.querySelector('.textLayer');
  if (!tl) return null;
  const ref = tl.getBoundingClientRect();
  const boxes = rects.map(([x, y, w, h]) => ({ l: ref.left + x * ref.width, t: ref.top + y * ref.height, r: ref.left + (x + w) * ref.width, b: ref.top + (y + h) * ref.height }));
  const walker = document.createTreeWalker(tl, NodeFilter.SHOW_TEXT);
  let out = '';
  let lastTop = null;
  const range = document.createRange();
  let n;
  while ((n = walker.nextNode())) {
    for (let i = 0; i < n.data.length; i++) {
      range.setStart(n, i);
      range.setEnd(n, i + 1);
      const c = range.getBoundingClientRect();
      if (!c.width) continue;
      const cx = c.left + c.width / 2;
      const cy = c.top + c.height / 2;
      if (!boxes.some((bx) => cx >= bx.l && cx <= bx.r && cy >= bx.t - 2 && cy <= bx.b + 2)) continue;
      if (lastTop !== null && Math.abs(c.top - lastTop) > c.height * 0.5 && !/\s$/.test(out)) out += ' ';
      out += n.data[i];
      lastTop = c.top;
    }
  }
  return out.replace(/\s+/g, ' ').trim();
}

function updateUndo() {
  $('btnUndo').disabled = !undoStack.length;
  $('btnRedo').disabled = !redoStack.length;
}

async function persist(affectedPages) {
  const all = (await store.get('pdfMarks')) || {};
  if (marks.length) all[fp] = marks;
  else delete all[fp];
  await store.set('pdfMarks', all);
  for (const p of affectedPages) renderMarks(p);
  buildMarksPanel();
  updateUndo();
}

// 所有變更都經過 commit：記錄上一步、重算被切割標記的文字、儲存、重繪
function commit(next) {
  const before = marks;
  undoStack.push(JSON.stringify(before));
  if (undoStack.length > 50) undoStack.shift();
  redoStack = [];
  marks = next
    .map((m) => {
      if (!m.dirty) return m;
      const { dirty, ...rest } = m;
      const t = textFor(rest.page, rest.rects);
      if (t === '') return null; // 切割後只剩空白（例如字與字之間的空格）：整段移除，避免殘留看不見的標記
      return t ? { ...rest, text: t.slice(0, 500) } : rest;
    })
    .filter(Boolean);
  const pages = new Set([...before, ...marks].map((m) => m.page));
  return persist(pages);
}

function undo() {
  if (!undoStack.length) return;
  const pages = new Set(marks.map((m) => m.page));
  redoStack.push(JSON.stringify(marks));
  marks = JSON.parse(undoStack.pop());
  marks.forEach((m) => pages.add(m.page));
  persist(pages);
}

function redo() {
  if (!redoStack.length) return;
  const pages = new Set(marks.map((m) => m.page));
  undoStack.push(JSON.stringify(marks));
  marks = JSON.parse(redoStack.pop());
  marks.forEach((m) => pages.add(m.page));
  persist(pages);
}
$('btnUndo').addEventListener('click', undo);
$('btnRedo').addEventListener('click', redo);

// 把目前選取的文字轉成「每頁的比例矩形」
function selectionByPage() {
  const sel = window.getSelection();
  if (!sel || sel.isCollapsed || !sel.rangeCount) return null;
  const range = sel.getRangeAt(0);
  if (!container.contains(range.commonAncestorContainer)) return null;
  const byPage = new Map();
  for (const r of range.getClientRects()) {
    if (r.width < 1 || r.height < 1) continue;
    const pageDiv = document.elementsFromPoint(r.left + r.width / 2, r.top + r.height / 2).find((x) => x.classList && x.classList.contains('page'));
    if (!pageDiv) continue;
    const n = +pageDiv.dataset.pageNumber;
    const ref = (pageDiv.querySelector('.textLayer') || pageDiv).getBoundingClientRect();
    if (!byPage.has(n)) byPage.set(n, []);
    byPage.get(n).push([(r.left - ref.left) / ref.width, (r.top - ref.top) / ref.height, r.width / ref.width, r.height / ref.height]);
  }
  return { text: sel.toString().replace(/\s+/g, ' ').trim(), byPage, clear: () => sel.removeAllRanges() };
}

function applySelection() {
  const s = selectionByPage();
  if (!s || !s.byPage.size) return;
  let next = marks;
  const time = Date.now();
  for (const [page, rects] of s.byPage) {
    const merged = G.mergeLine(rects);
    if (tool === 'marker') {
      const id = time.toString(36) + Math.random().toString(36).slice(2, 6);
      next = G.addMark(next, { id, page, color: markerColor, text: s.text.slice(0, 500), rects: merged, time });
    } else {
      next = G.eraseArea(next, page, merged);
    }
  }
  s.clear();
  commit(next);
}

// 電腦：放開滑鼠就標記
container.addEventListener('mouseup', (e) => {
  if (WEB || tool === 'none' || !doc || e.detail === 2) return; // 雙擊留給查單字
  setTimeout(applySelection, 0);
});

// 觸控（網頁版）：選取停止後顯示確認按鈕，避免拖曳選取時提早標記
if (WEB) {
  let selTimer = null;
  const btn = $('markConfirm');
  document.addEventListener('selectionchange', () => {
    clearTimeout(selTimer);
    btn.hidden = true;
    selTimer = setTimeout(() => {
      if (tool === 'none' || !doc) return;
      const sel = window.getSelection();
      if (!sel || sel.isCollapsed || !sel.rangeCount || !container.contains(sel.getRangeAt(0).commonAncestorContainer)) return;
      const rects = sel.getRangeAt(0).getClientRects();
      const last = rects[rects.length - 1];
      if (!last) return;
      btn.textContent = tool === 'marker' ? '✓ 標記選取的文字' : '✓ 擦除選取的文字';
      btn.classList.toggle('erase', tool === 'eraser');
      btn.hidden = false;
      btn.style.left = Math.min(last.right, window.innerWidth - btn.offsetWidth - 8) + 'px';
      btn.style.top = Math.min(last.bottom + 10, window.innerHeight - btn.offsetHeight - 8) + 'px';
    }, 450);
  });
  btn.addEventListener('mousedown', (e) => e.preventDefault()); // 保留選取範圍
  btn.addEventListener('click', () => {
    btn.hidden = true;
    applySelection();
  });
}

// ---------- 點擊已畫的螢光筆：小選單（改色／刪除）；橡皮擦模式直接擦掉整段 ----------
let lastDblAt = 0;
let menuMark = null;
container.addEventListener('dblclick', () => { lastDblAt = Date.now(); hideMenu(); });

function markAt(x, y) {
  const pageDiv = document.elementsFromPoint(x, y).find((n) => n.classList && n.classList.contains('page'));
  if (!pageDiv) return null;
  const ref = (pageDiv.querySelector('.textLayer') || pageDiv).getBoundingClientRect();
  return G.hitMark(marks, +pageDiv.dataset.pageNumber, (x - ref.left) / ref.width, (y - ref.top) / ref.height);
}

function hideMenu() {
  $('markMenu').hidden = true;
  menuMark = null;
}

container.addEventListener('click', (e) => {
  if (e.detail !== 1 || !doc) return;
  const sel = window.getSelection();
  if (sel && !sel.isCollapsed) return;
  const m = markAt(e.clientX, e.clientY);
  if (!m) return hideMenu();
  if (tool === 'eraser') return commit(G.removeMark(marks, m.id));
  if (WEB && tool === 'none') return hideMenu(); // 網頁版：點一下是查單字；要改色或刪除請先開螢光筆
  const x = e.clientX;
  const y = e.clientY;
  setTimeout(() => {
    if (Date.now() - lastDblAt < 400) return; // 其實是雙擊查字
    menuMark = m;
    const menu = $('markMenu');
    menu.hidden = false;
    menu.style.left = Math.min(x, window.innerWidth - menu.offsetWidth - 8) + 'px';
    menu.style.top = Math.max(8, y - menu.offsetHeight - 10) + 'px';
  }, 280);
});
document.querySelectorAll('#markMenu .dot').forEach((d) =>
  d.addEventListener('click', () => {
    if (menuMark) commit(G.recolor(marks, menuMark.id, d.dataset.color));
    hideMenu();
  })
);
$('menuDelete').addEventListener('click', () => {
  if (menuMark) commit(G.removeMark(marks, menuMark.id));
  hideMenu();
});
container.addEventListener('scroll', hideMenu, { passive: true });

function buildMarksPanel() {
  const panel = $('panel-marks');
  panel.textContent = '';
  if (!marks.length) {
    panel.appendChild(el('div', 'empty', '還沒有標記。按工具列的「🖍 螢光筆」（或按 H 鍵）後，選取文字即可標記；點一下已畫的標記可以改色或刪除。'));
    return;
  }
  const top = (m) => Math.min(...m.rects.map((r) => r[1]));
  const sorted = [...marks].sort((a, b) => a.page - b.page || top(a) - top(b));
  for (const m of sorted) {
    const item = el('div', 'mark-item');
    item.style.setProperty('--c', COLOR_HEX[m.color] || '#FFD84D');
    const t = el('div', 't', m.text || '（標記）');
    t.title = '跳到這個標記';
    t.addEventListener('click', () => jumpToMark(m));
    const row = el('div', 'm');
    row.appendChild(el('span', null, '第 ' + m.page + ' 頁'));
    const del = el('button', null, '刪除');
    del.addEventListener('click', () => commit(G.removeMark(marks, m.id)));
    row.appendChild(del);
    item.append(t, row);
    panel.appendChild(item);
  }
}

function jumpToMark(m) {
  pdfViewer.currentPageNumber = m.page;
  let tries = 0;
  const seek = () => {
    const d = container.querySelector('.wl-marks div[data-id="' + m.id + '"]');
    if (d) {
      d.scrollIntoView({ block: 'center' });
      container.querySelectorAll('.wl-marks div[data-id="' + m.id + '"]').forEach((x) => {
        x.classList.add('flash');
        setTimeout(() => x.classList.remove('flash'), 1500);
      });
    } else if (tries++ < 20) {
      setTimeout(seek, 100);
    }
  };
  seek();
}

// ---------- 匯出 ----------
function toast(msg, isErr) {
  const t = $('toast');
  t.textContent = msg;
  t.className = isErr ? 'err' : '';
  t.hidden = false;
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => { t.hidden = true; }, isErr ? 6000 : 3500);
}

function saveFile(name, data, type) {
  const url = URL.createObjectURL(new Blob([data], { type }));
  const a = document.createElement('a');
  a.href = url;
  a.download = name;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 5000);
}

const baseName = () => (meta.name || 'document').replace(/\.pdf$/i, '');

$('btnExport').addEventListener('click', (e) => {
  e.stopPropagation();
  const m = $('exportMenu');
  if (!m.hidden) { m.hidden = true; return; }
  const r = $('btnExport').getBoundingClientRect();
  m.hidden = false;
  m.style.top = r.bottom + 6 + 'px';
  m.style.left = Math.min(r.left, window.innerWidth - m.offsetWidth - 8) + 'px';
});
document.addEventListener('click', (e) => {
  if (!e.target.closest('#exportMenu') && e.target.id !== 'btnExport') $('exportMenu').hidden = true;
});

$('expPdf').addEventListener('click', async () => {
  $('exportMenu').hidden = true;
  if (!doc || !originalBytes) return;
  if (!marks.length) return toast('還沒有任何螢光筆標記。', true);
  toast('正在產生 PDF…');
  try {
    const out = await annotatedPdf({ bytes: originalBytes, pdfjsDoc: doc, marks });
    saveFile(baseName() + '（含標記）.pdf', out, 'application/pdf');
    toast('已匯出 PDF：' + marks.length + ' 則螢光筆已寫成標準註解。');
  } catch (err) {
    toast(err.message || String(err), true);
  }
});

$('expTxt').addEventListener('click', () => {
  $('exportMenu').hidden = true;
  if (!doc) return;
  if (!marks.length) return toast('還沒有任何螢光筆標記。', true);
  saveFile(baseName() + '_標記清單.txt', marksText({ marks, title: meta.title || meta.name, fileName: meta.name }), 'text/plain;charset=utf-8');
  toast('已匯出標記清單（' + marks.length + ' 則）。');
});

// ---------- 鍵盤快捷鍵 ----------
window.addEventListener('keydown', (e) => {
  const typing = /^(INPUT|TEXTAREA|SELECT)$/.test(document.activeElement && document.activeElement.tagName);
  const k = e.key.toLowerCase();
  if ((e.ctrlKey || e.metaKey) && k === 'f') {
    e.preventDefault();
    $('findInput').focus();
    $('findInput').select();
  } else if (!typing && (e.ctrlKey || e.metaKey) && k === 'z' && !e.shiftKey) {
    e.preventDefault();
    undo();
  } else if (!typing && (e.ctrlKey || e.metaKey) && (k === 'y' || (k === 'z' && e.shiftKey))) {
    e.preventDefault();
    redo();
  } else if (!typing && !e.ctrlKey && !e.metaKey && !e.altKey && doc && k === 'h') {
    setTool('marker');
  } else if (!typing && !e.ctrlKey && !e.metaKey && !e.altKey && doc && k === 'e') {
    setTool('eraser');
  } else if (e.key === 'Escape') {
    hideMenu();
  }
});

// ---------- 啟動 ----------
const fileParam = new URLSearchParams(location.search).get('file');
renderRecent();
if (fileParam) loadFromUrl(fileParam);
