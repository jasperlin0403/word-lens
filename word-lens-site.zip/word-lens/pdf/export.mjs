// PDF 匯出：①把螢光筆寫成 PDF 標準「重點標示」註解（預覽程式、GoodNotes、Adobe 等可再編輯或刪除）
//           ②匯出標記清單文字檔（依頁碼整理）
// 寫入 PDF 使用 pdf-lib（MIT 授權），第一次匯出時才載入。
const COLORS = { yellow: [1, 0.847, 0.302], green: [0.494, 0.863, 0.541], pink: [1, 0.62, 0.733] };
const NAMES = { yellow: '黃', green: '綠', pink: '粉紅' };
const f2 = (n) => Number(n.toFixed(2));

let libPromise = null;
function loadLib() {
  if (globalThis.PDFLib) return Promise.resolve(globalThis.PDFLib);
  if (!libPromise) {
    libPromise = new Promise((resolve, reject) => {
      const s = document.createElement('script');
      s.src = new URL('./lib/pdf-lib.min.js', import.meta.url).href;
      s.onload = () => resolve(globalThis.PDFLib);
      s.onerror = () => { libPromise = null; reject(new Error('無法載入匯出元件')); };
      document.head.appendChild(s);
    });
  }
  return libPromise;
}

function pdfDate(d) {
  const p = (n) => String(n).padStart(2, '0');
  return 'D:' + d.getFullYear() + p(d.getMonth() + 1) + p(d.getDate()) + p(d.getHours()) + p(d.getMinutes()) + p(d.getSeconds());
}

const topOf = (m) => Math.min(...m.rects.map((r) => r[1]));
const sorted = (marks) => [...marks].sort((a, b) => a.page - b.page || topOf(a) - topOf(b));

// bytes：原始 PDF（Uint8Array）；pdfjsDoc：用來換算頁面座標（含旋轉、裁切框）
export async function annotatedPdf({ bytes, pdfjsDoc, marks }) {
  const L = await loadLib();
  let out;
  try {
    out = await L.PDFDocument.load(bytes, { updateMetadata: false });
  } catch (e) {
    if (/encrypted/i.test(String(e && e.message))) throw new Error('這份 PDF 有加密保護，無法寫入註解；可以改匯出「標記清單」。');
    throw new Error('無法讀取這份 PDF 的內容：' + (e && e.message ? e.message : e));
  }
  const ctx = out.context;
  const pages = out.getPages();
  const now = pdfDate(new Date());
  for (const m of sorted(marks)) {
    const page = pages[m.page - 1];
    if (!page || !m.rects.length) continue;
    const vp = (await pdfjsDoc.getPage(m.page)).getViewport({ scale: 1 });
    const quads = [];
    const boxes = [];
    let x0 = Infinity; let y0 = Infinity; let x1 = -Infinity; let y1 = -Infinity;
    for (const [x, y, w, h] of m.rects) {
      const [ax, ay] = vp.convertToPdfPoint(x * vp.width, y * vp.height);
      const [bx, by] = vp.convertToPdfPoint((x + w) * vp.width, (y + h) * vp.height);
      const l = Math.min(ax, bx); const r = Math.max(ax, bx); const b = Math.min(ay, by); const t = Math.max(ay, by);
      quads.push(f2(l), f2(t), f2(r), f2(t), f2(l), f2(b), f2(r), f2(b)); // 左上、右上、左下、右下
      boxes.push([l, b, r - l, t - b]);
      x0 = Math.min(x0, l); y0 = Math.min(y0, b); x1 = Math.max(x1, r); y1 = Math.max(y1, t);
    }
    const c = COLORS[m.color] || COLORS.yellow;
    const rect = [f2(x0), f2(y0), f2(x1), f2(y1)];
    // 顯示外觀（有些閱讀器不會自己畫重點標示，需要附上外觀）
    const ops = ['q', '/GS0 gs', c.map((v) => v.toFixed(3)).join(' ') + ' rg']
      .concat(boxes.map(([bx, by, bw, bh]) => [bx, by, bw, bh].map((v) => v.toFixed(2)).join(' ') + ' re'))
      .concat(['f', 'Q'])
      .join('\n');
    const ap = ctx.register(ctx.stream(ops, {
      Type: 'XObject', Subtype: 'Form', BBox: rect,
      Resources: { ExtGState: { GS0: { Type: 'ExtGState', BM: 'Multiply', ca: 0.45, CA: 0.45 } } }
    }));
    const annot = ctx.obj({
      Type: 'Annot', Subtype: 'Highlight', Rect: rect, QuadPoints: quads, C: c, CA: 0.45, F: 4,
      Contents: L.PDFHexString.fromText(m.text || ''),
      T: L.PDFHexString.fromText('點字學英文'),
      M: L.PDFString.of(now),
      NM: L.PDFString.of('wordlens-' + m.id),
      AP: { N: ap }
    });
    page.node.addAnnot(ctx.register(annot));
  }
  return out.save();
}

export function marksText({ marks, title, fileName }) {
  const lines = [
    '《' + title + '》螢光筆標記',
    '檔案：' + fileName,
    '匯出時間：' + new Date().toLocaleString('zh-TW'),
    '共 ' + marks.length + ' 則',
    ''
  ];
  let page = 0;
  for (const m of sorted(marks)) {
    if (m.page !== page) {
      page = m.page;
      lines.push('', '第 ' + page + ' 頁');
    }
    lines.push('・［' + (NAMES[m.color] || '黃') + '］' + (m.text || '（無文字）'));
  }
  return '\uFEFF' + lines.join('\r\n') + '\r\n'; // BOM：Windows 記事本也能正確顯示中文
}
