// 螢光筆幾何運算（純函式，不碰畫面，方便測試）
// 座標皆為「頁面比例」[x, y, w, h]（0–1），縮放後仍對齊。
// 原則：標記之間永遠不重疊 → 同色相連合併為一段；不同色以新畫的顏色取代重疊部分。
export const EPS = 0.0015;

export function sameLine(a, b) {
  const top = Math.max(a[1], b[1]);
  const bottom = Math.min(a[1] + a[3], b[1] + b[3]);
  return bottom - top >= 0.5 * Math.min(a[3], b[3]);
}

export const hOverlap = (a, b, gap = 0) => a[0] < b[0] + b[2] + gap && b[0] < a[0] + a[2] + gap;
export const touches = (a, b, gap = 0) => sameLine(a, b) && hOverlap(a, b, gap);
export const overlapsAny = (rs, others, gap = 0) => rs.some((a) => others.some((b) => touches(a, b, gap)));
const round = (r) => r.map((v) => +v.toFixed(5));

// a 扣掉 b 覆蓋的水平範圍（同一行才扣）
export function subtract(a, b) {
  if (!touches(a, b)) return [a];
  const out = [];
  if (b[0] - a[0] > EPS) out.push(round([a[0], a[1], b[0] - a[0], a[3]]));
  const ar = a[0] + a[2];
  const br = b[0] + b[2];
  if (ar - br > EPS) out.push(round([br, a[1], ar - br, a[3]]));
  return out;
}

export const subtractAll = (rects, cutters) =>
  cutters.reduce((cur, c) => cur.flatMap((r) => subtract(r, c)), rects);

// 同一行相接或重疊的矩形合併成一段
export function mergeLine(rects) {
  const rs = rects.map((r) => [...r]).sort((a, b) => a[1] - b[1] || a[0] - b[0]);
  const out = [];
  for (const r of rs) {
    const last = out.find((o) => touches(o, r, EPS * 2));
    if (last) {
      const x = Math.min(last[0], r[0]);
      const y = Math.min(last[1], r[1]);
      const right = Math.max(last[0] + last[2], r[0] + r[2]);
      const bottom = Math.max(last[1] + last[3], r[1] + r[3]);
      last.splice(0, 4, x, y, right - x, bottom - y);
    } else {
      out.push(r);
    }
  }
  return out.map(round);
}

const sameRects = (a, b) => JSON.stringify(a) === JSON.stringify(b);
const byReading = (a, b) => (sameLine(a, b) ? a[0] - b[0] : a[1] - b[1]);

// 標記被從中間切斷時，拆成「切點之前」與「切點之後」兩段獨立標記（選取在閱讀順序上是連續的）
function cutMark(m, cutters) {
  const rest = subtractAll(m.rects, cutters);
  if (!rest.length) return [];
  if (sameRects(rest, m.rects)) return [m];
  const start = [...cutters].sort(byReading)[0];
  const before = [];
  const after = [];
  for (const r of rest.sort(byReading)) (byReading(r, start) < 0 ? before : after).push(r);
  const out = [];
  if (before.length) out.push({ ...m, rects: before, dirty: true });
  if (after.length) out.push({ ...m, id: before.length ? m.id + '-' + Math.random().toString(36).slice(2, 6) : m.id, rects: after, dirty: true });
  return out;
}

// 新增一段標記；回傳新的標記陣列（有變動的標記加上 dirty: true，供重新擷取文字）
export function addMark(marks, mark) {
  const onPage = (m) => m.page === mark.page;
  const joined = marks.filter((m) => onPage(m) && m.color === mark.color && overlapsAny(m.rects, mark.rects, EPS * 2));
  const rects = mergeLine([...mark.rects, ...joined.flatMap((m) => m.rects)]);
  const out = [];
  for (const m of marks) {
    if (joined.includes(m)) continue;
    if (!onPage(m)) { out.push(m); continue; }
    out.push(...cutMark(m, rects));
  }
  out.push({ ...mark, rects, dirty: true });
  return out;
}

// 橡皮擦：從該頁所有標記中扣掉指定範圍
export function eraseArea(marks, page, cutRects) {
  const out = [];
  for (const m of marks) {
    if (m.page !== page) { out.push(m); continue; }
    out.push(...cutMark(m, cutRects));
  }
  return out;
}

export const removeMark = (marks, id) => marks.filter((m) => m.id !== id);
export const recolor = (marks, id, color) => marks.map((m) => (m.id === id ? { ...m, color } : m));

export function hitMark(marks, page, x, y) {
  for (let i = marks.length - 1; i >= 0; i--) {
    const m = marks[i];
    if (m.page === page && m.rects.some(([rx, ry, rw, rh]) => x >= rx && x <= rx + rw && y >= ry && y <= ry + rh)) return m;
  }
  return null;
}

// 檢查：同一頁任兩段標記是否有重疊（測試用）
export function overlapArea(marks) {
  let area = 0;
  for (let i = 0; i < marks.length; i++) {
    for (let j = i + 1; j < marks.length; j++) {
      if (marks[i].page !== marks[j].page) continue;
      for (const a of marks[i].rects) for (const b of marks[j].rects) {
        if (!sameLine(a, b)) continue;
        const w = Math.min(a[0] + a[2], b[0] + b[2]) - Math.max(a[0], b[0]);
        if (w > EPS) area += w;
      }
    }
  }
  return area;
}
