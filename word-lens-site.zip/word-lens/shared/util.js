// 共用小工具：網頁端（content scripts）、生詞本頁、PDF 閱讀器共用，避免重複維護
(() => {
  if (globalThis.WLUtil) return;

  const EXT_GONE = '擴充功能已更新或重新載入，請重新整理這個網頁後再試。';

  function el(tag, cls, text) {
    const e = document.createElement(tag);
    if (cls) e.className = cls;
    if (text != null) e.textContent = text;
    return e;
  }

  const escapeRe = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

  // 與背景程式溝通，一律回傳 { ok, data } 或 { ok:false, error:{ code, message } }
  function send(msg) {
    return new Promise((resolve) => {
      try {
        chrome.runtime.sendMessage(msg, (res) => {
          if (chrome.runtime.lastError) resolve({ ok: false, error: { code: 'EXT', message: EXT_GONE } });
          else resolve(res || { ok: false, error: { code: 'EMPTY', message: '沒有收到回應，請再試一次。' } });
        });
      } catch (e) {
        resolve({ ok: false, error: { code: 'EXT', message: EXT_GONE } });
      }
    });
  }

  // 發音：優先真人音檔，失敗改用電腦語音
  function speak(text, audioUrl) {
    let fellBack = false;
    const fallback = () => {
      if (fellBack) return;
      fellBack = true;
      // 網頁版直接呼叫瀏覽器語音（iPad 需要在點擊當下發聲，繞道背景程式可能被擋）
      if (globalThis.WL_WEB) chrome.tts.speak(text, { lang: 'en-US', rate: 0.9 });
      else send({ type: 'speak', text });
    };
    if (!audioUrl) return fallback();
    try {
      const a = new Audio(audioUrl);
      a.addEventListener('error', fallback);
      const p = a.play();
      if (p && p.catch) p.catch(fallback);
    } catch (e) {
      fallback();
    }
  }

  // 擴充功能頁面用：確認背景程式與頁面是同一版；不一致時在頁面最上方顯示提醒
  async function checkBuild() {
    const want = chrome.runtime.getManifest().version;
    const r = await send({ type: 'ping' });
    const got = r.ok && r.data && r.data.build;
    if (got === want) return true;
    const bar = el('div', null, '⚠️ 擴充功能沒有完整更新（背景程式仍是舊版）。請到 chrome://extensions，按「點字學英文」的「↻ 重新載入」，再重新開啟這個頁面。');
    bar.style.cssText = 'background:#FBEDEA;color:#A33A2B;padding:10px 14px;font-weight:600;border-bottom:2px solid #A33A2B;font-size:13px;';
    document.body.prepend(bar);
    return false;
  }

  // 在擴充功能自己的頁面（PDF 閱讀器、生詞本、複習、網頁版首頁）載入查字功能：
  // 程式清單直接讀 manifest（與網頁端相同，只維護一份）
  async function loadContent() {
    const cs = chrome.runtime.getManifest().content_scripts[0];
    for (const css of cs.css || []) {
      if (document.querySelector('link[data-wl-css="' + css + '"]')) continue;
      const l = document.createElement('link');
      l.rel = 'stylesheet';
      l.href = chrome.runtime.getURL(css);
      l.setAttribute('data-wl-css', css);
      document.head.appendChild(l);
    }
    for (const f of cs.js) {
      if (f === 'shared/util.js') continue; // 本檔已載入
      await new Promise((resolve) => {
        const sc = document.createElement('script');
        sc.src = chrome.runtime.getURL(f);
        sc.onload = sc.onerror = resolve;
        document.head.appendChild(sc);
      });
    }
    return globalThis.__WL;
  }

  // 例句太長（例如整段翻譯時加入的字）：只留含有這個字的那一句，再太長就只取單字前後一段
  function clipSentence(text, re) {
    const s = String(text || '').replace(/\s+/g, ' ').trim();
    const m = re && re.exec(s);
    if (!m) return { text: s.length > 240 ? s.slice(0, 240) + '…' : s, clipped: s.length > 240 };
    let start = 0;
    let end = s.length;
    for (const b of s.slice(0, m.index).matchAll(/[.!?。！？]["”’)]?\s+/g)) start = b.index + b[0].length;
    const after = /[.!?。！？](?=["”’)]?(\s|$))/.exec(s.slice(m.index + m[0].length));
    if (after) end = m.index + m[0].length + after.index + 1;
    const clipped = start > 0 || end < s.length;
    if (end - start > 240) {
      const a = Math.max(start, m.index - 110);
      const b = Math.min(end, m.index + m[0].length + 110);
      return { text: (a > 0 ? '…' : '') + s.slice(a, b).trim() + (b < s.length ? '…' : ''), clipped: true };
    }
    return { text: s.slice(start, end).trim(), clipped };
  }

  // CEFR 等級對應台灣常用的英檢程度（字的等級＝達到這個程度的人通常認得）
  // 全民英檢：語言訓練測驗中心公告的 CEFR 對應；多益：ETS 對照表聽力＋閱讀最低分相加（僅供參考）
  const CEFR_TW = {
    A1: { name: '入門級', tw: '全民英檢初級以下', toeic: '多益 120 以上' },
    A2: { name: '基礎級', tw: '全民英檢初級', toeic: '多益 225 以上' },
    B1: { name: '進階級', tw: '全民英檢中級', toeic: '多益 550 以上' },
    B2: { name: '高階級', tw: '全民英檢中高級', toeic: '多益 785 以上' },
    C1: { name: '流利級', tw: '全民英檢高級', toeic: '多益 945 以上' },
    C2: { name: '精通級', tw: '全民英檢優級', toeic: '超出多益範圍' }
  };
  const cefrNote = (lv) => {
    const c = CEFR_TW[lv];
    return c ? 'CEFR ' + lv + ' ' + c.name + '：約' + c.tw + '、' + c.toeic + '程度的字' : '不在 CEFR 字表內：多半是 C2 以上的難字、專有名詞或專業用語';
  };

  globalThis.WLUtil = Object.freeze({
    checkBuild,
    loadContent,
    el, escapeRe, send, speak, clipSentence, CEFR_TW, cefrNote,
    WORD_RE: /^[A-Za-z]+(?:['’-][A-Za-z]+)*$/
  });
})();
