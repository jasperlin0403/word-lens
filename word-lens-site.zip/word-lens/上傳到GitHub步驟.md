# 更新網頁版（GitHub Pages）

儲存庫裡有一個自動發布流程（`.github/workflows/pages.yml`），它會在每次推送時
抓取根目錄的 `word-lens-site.zip`、解壓縮、發布到 GitHub Pages。

所以更新網頁版**只要換掉一個檔案**，不必上傳整個專案的三百多個檔案。

## 更新步驟（約 1 分鐘）

1. 打開上傳頁：<https://github.com/jasperlin0403/word-lens/upload/main>
2. 把新的 `word-lens-site.zip` 拖進去（同名會直接覆蓋舊檔）。
3. 下方「Commit changes」填一行說明，例如「更新到 2.5.3」。
4. 確認選的是 **Commit directly to the `main` branch**，按 **Commit changes**。
5. 到 <https://github.com/jasperlin0403/word-lens/actions> 看「發布網頁版」跑完（約 1–2 分鐘）。
6. 打開 <https://jasperlin0403.github.io/word-lens/> 重新整理**兩次**
   （第一次下載新版、第二次才開始使用）。

## 確認真的更新成功

網頁版右上角若出現紅色的「沒有完整更新」警告，表示版本字串不一致，不要忽略它。
正常情況下打開瀏覽器主控台應該看到快取名稱是 `wl-web-<版本>`，與 `manifest.json` 相同。

## 常見問題

- **Actions 顯示「找不到 word-lens-site.zip，略過發布」**：檔名打錯，或上傳到了子資料夾。
  檔案必須在儲存庫**根目錄**，檔名必須完全是 `word-lens-site.zip`。
- **網頁還是舊版**：關掉分頁重新開啟，或重新整理兩次。iPad 上尤其要重整兩次。
- **404**：確認 Settings → Pages 的來源是 **GitHub Actions**（不是 Deploy from a branch）。
- **隱藏檔 `.nojekyll`**：已包含在壓縮檔裡，用途是讓 GitHub Pages 原樣提供檔案。

## 注意：不要整個資料夾覆蓋

儲存庫根目錄還有 `.github/workflows/pages.yml`，那是自動發布流程本身。
若用「刪光再放新的」方式更新，會把它一起刪掉，之後就不會自動發布了。
照上面的步驟只換 zip 就不會有這個問題。

## 電腦版擴充功能的更新（與網頁版無關）

把「完整版」解壓縮後的檔案**覆蓋到原本那個資料夾**，再到 `chrome://extensions`
按「重新載入」。**不要**移除後重新加入——Chrome 用資料夾路徑決定擴充功能身分，
路徑一變就會被當成新的擴充功能，**生詞本與 API 金鑰都會不見**。
