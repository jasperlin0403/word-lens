# 把網頁版放上 GitHub Pages（Mac＋GitHub Desktop）

整個專案有 300 多個檔案，超過 GitHub 網頁一次上傳 100 個的限制，所以用免費的 **GitHub Desktop** App 上傳，之後更新也只要按兩下。

## 第一次設定（約 10 分鐘）

1. 下載「完整版」壓縮檔並解壓縮，把得到的 `word-lens` 資料夾放在固定位置，例如「文件」。
   （這個資料夾專門用來放網頁版，**不要**和 Chrome 擴充功能正在使用的資料夾共用。）
2. 到 desktop.github.com 下載並安裝 **GitHub Desktop**，用你的 GitHub 帳號登入。
3. 在 GitHub Desktop 選單列按 **File → Add Local Repository…**，選擇剛才的 `word-lens` 資料夾。
4. 畫面會說這個資料夾還不是儲存庫，點提示文字中的 **「create a repository」**，名稱確認為 `word-lens`，按 **Create Repository**。
5. 按右上角 **Publish repository**，**取消勾選「Keep this code private」**（免費帳號的網頁版需要公開儲存庫），再按 **Publish Repository**。
6. 到 GitHub 網站打開 `word-lens` 儲存庫 → **Settings → Pages**：
   Source 選 **Deploy from a branch**，Branch 選 **main**、資料夾選 **/(root)**，按 **Save**。
7. 等 1–2 分鐘重新整理，頁面上方會顯示網址（類似 `https://你的帳號.github.io/word-lens/`）。用 iPad 的 Safari 開啟並加入書籤即可。

## 之後更新

1. 打開 `word-lens` 資料夾，刪除裡面**看得到的**所有檔案（隱藏的 `.git` 資料夾會自動保留，不要動它）。
2. 把新版「完整版」解壓縮後的內容放進來。
3. 回到 GitHub Desktop，左下角填寫說明（例如「更新到 2.3.0」），按 **Commit to main**，再按上方 **Push origin**。
4. 約 1–2 分鐘後網頁版就會更新；iPad 重新整理兩次即可看到新版。

## 常見問題

- **網址打開是 404**：GitHub Pages 第一次發布需要幾分鐘；確認第 6 步的設定已儲存。
- **iPad 上還是舊版**：關掉分頁重新開啟，或重新整理兩次（第一次下載新版、第二次開始使用）。
- **隱藏檔 `.nojekyll`**：已包含在壓縮檔裡，用途是讓 GitHub Pages 原樣提供檔案。
