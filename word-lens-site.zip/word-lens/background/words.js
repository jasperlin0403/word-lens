// 生詞本：單字與熟悉度存在 chrome.storage.local（網頁端要用來標色）；
// 查詢次數與複習排程存在 IndexedDB（頻繁寫入，不廣播到每個分頁）
import * as db from './db.js';
import * as srs from './srs.js';

let queue = Promise.resolve();
function withLock(fn) {
  const p = queue.then(fn, fn);
  queue = p.catch(() => {});
  return p;
}

const getWords = async () => (await chrome.storage.local.get('words')).words || {};
const DAY = 86400000;

function findKey(words, w) {
  const lw = String(w || '').toLowerCase().trim();
  if (!lw) return null;
  if (words[lw]) return lw;
  for (const [k, v] of Object.entries(words)) if ((v.forms || []).includes(lw)) return k;
  return null;
}

// 查詢已存的字：累計次數；同一天第一次再查會「降一級」並排入複習（代表還沒記住）
export function touch(word) {
  return withLock(async () => {
    const words = await getWords();
    const key = findKey(words, word) || findKey(words, String(word).replace(/['’]s$/i, ''));
    if (!key) return { saved: false };
    const now = Date.now();
    const st = (await db.get('stats', key)) || { lookups: words[key].lookups || 1 };
    const sameDay = st.lastTouch && new Date(st.lastTouch).toDateString() === new Date(now).toDateString();
    st.lookups = (st.lookups || 0) + 1;
    st.t = now;
    st.lastTouch = now;
    await db.put('stats', key, st);
    let level = words[key].level || 1;
    if (!sameDay && level > 1) {
      level = level - 1;
      words[key].level = level;
      await chrome.storage.local.set({ words });
      const s = (await db.get('srs', key)) || srs.newState();
      s.due = Math.min(s.due, now);
      await db.put('srs', key, s);
      await refreshBadge();
    }
    return { saved: true, key, lookups: st.lookups, level };
  });
}

export function save(entry) {
  return withLock(async () => {
    const words = await getWords();
    const now = new Date().toISOString();
    const key = findKey(words, entry.lemma) || findKey(words, entry.word) || String(entry.lemma || entry.word).toLowerCase().trim();
    const forms = new Set([entry.word, entry.lemma].filter(Boolean).map((s) => String(s).toLowerCase().trim()));
    const fields = {};
    for (const f of ['lemma', 'phonetic', 'audio', 'pos', 'zh', 'en_def', 'en_example', 'phrase']) if (entry[f]) fields[f] = entry[f];
    const old = words[key];
    if (old) {
      (old.forms || []).forEach((f) => forms.add(f));
      const contexts = [...(old.contexts || [])];
      if (entry.context && entry.context.sentence && !contexts.some((c) => c.sentence === entry.context.sentence)) contexts.unshift(entry.context);
      words[key] = { ...old, ...fields, forms: [...forms], contexts: contexts.slice(0, 5), updatedAt: now };
    } else {
      words[key] = {
        key, ...fields, forms: [...forms], level: 1,
        contexts: entry.context && entry.context.sentence ? [entry.context] : [],
        addedAt: now, updatedAt: now
      };
      if (!(await db.get('stats', key))) await db.put('stats', key, { lookups: 1, t: Date.now(), lastTouch: Date.now() });
      await db.put('srs', key, srs.newState());
    }
    await chrome.storage.local.set({ words });
    await refreshBadge();
    return { key, isNew: !old, level: words[key].level || 1 };
  });
}

export function setLevel(word, level) {
  return withLock(async () => {
    const words = await getWords();
    const key = findKey(words, word);
    if (!key) return { saved: false };
    const lv = Math.min(5, Math.max(1, Math.round(level)));
    words[key].level = lv;
    await chrome.storage.local.set({ words });
    await db.put('srs', key, srs.forLevel(await db.get('srs', key), lv));
    await refreshBadge();
    return { saved: true, key, level: lv };
  });
}

export const allStats = () => db.getAll('stats');

// ---------- 複習 ----------
export async function dueList(now = Date.now()) {
  const words = await getWords();
  const all = await db.getAll('srs');
  const out = [];
  for (const [k, v] of Object.entries(words)) {
    const st = all[k] || srs.newState(0);
    if (st.due <= now) out.push({ key: k, due: st.due });
  }
  return out.sort((a, b) => a.due - b.due);
}

export async function reviewQueue(limit = 30, fixedMode) {
  const words = await getWords();
  const due = await dueList();
  return due.slice(0, limit).map(({ key }) => ({
    key, word: words[key], mode: srs.pickMode(words[key].level, fixedMode)
  }));
}

// 自由練習：不影響熟悉度與排程；scope：all 全部（隨機）｜today 今天複習過（隨機）｜recent 最近加入
export async function practicePool(scope = 'all', n = 10, fixedMode) {
  const words = await getWords();
  let keys = Object.keys(words);
  if (scope === 'today') {
    const all = await db.getAll('srs');
    const today = new Date().toDateString();
    keys = keys.filter((k) => all[k] && all[k].last && new Date(all[k].last).toDateString() === today);
  }
  if (scope === 'recent') {
    keys.sort((a, b) => String(words[b].addedAt || '').localeCompare(String(words[a].addedAt || '')));
  } else {
    for (let i = keys.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [keys[i], keys[j]] = [keys[j], keys[i]];
    }
  }
  if (n > 0) keys = keys.slice(0, n);
  return keys.map((key) => ({ key, word: words[key], mode: srs.pickMode(words[key].level, fixedMode) }));
}

export function answer(key, rating) {
  return withLock(async () => {
    const words = await getWords();
    if (!words[key]) return { saved: false };
    const st = await db.get('srs', key);
    const before = words[key].level || 1;
    const r = srs.schedule(st, before, rating);
    await db.put('srs', key, r.state);
    if (r.level !== before) {
      words[key].level = r.level;
      await chrome.storage.local.set({ words }); // 熟悉度有變才寫入（才會通知各分頁重新標色）
    }
    await bumpReviewStats();
    await refreshBadge();
    return { level: r.level, due: r.state.due, interval: r.state.interval };
  });
}

async function bumpReviewStats() {
  const s = (await db.get('kv', 'reviewStats')) || { day: '', count: 0, streak: 0, lastDay: '' };
  const today = new Date().toDateString();
  if (s.day !== today) {
    const yesterday = new Date(Date.now() - DAY).toDateString();
    s.streak = s.lastDay === yesterday ? s.streak + 1 : 1;
    s.day = today;
    s.count = 0;
  }
  s.count++;
  s.lastDay = today;
  await db.put('kv', 'reviewStats', s);
}

export async function reviewStats() {
  const s = (await db.get('kv', 'reviewStats')) || { day: '', count: 0, streak: 0, lastDay: '' };
  const today = new Date().toDateString();
  const yesterday = new Date(Date.now() - DAY).toDateString();
  return {
    today: s.day === today ? s.count : 0,
    streak: s.lastDay === today || s.lastDay === yesterday ? s.streak : 0,
    due: (await dueList()).length
  };
}

// 備份／還原複習排程（讓電腦與 iPad 之間轉移時保留熟悉度與進度）
export const exportSrs = () => db.getAll('srs');

export async function importSrs(incoming) {
  let n = 0;
  for (const [k, v] of Object.entries(incoming || {})) {
    if (!v || typeof v !== 'object') continue;
    const cur = await db.get('srs', k);
    if (!cur || (v.last || 0) > (cur.last || 0)) {
      await db.put('srs', k, v);
      n++;
    }
  }
  await refreshBadge();
  return n;
}

// 工具列圖示顯示今日待複習數
export async function refreshBadge() {
  try {
    const n = (await dueList()).length;
    await chrome.action.setBadgeBackgroundColor({ color: '#1F7AA0' });
    await chrome.action.setBadgeText({ text: n ? (n > 99 ? '99+' : String(n)) : '' });
  } catch (e) { /* 忽略 */ }
}
