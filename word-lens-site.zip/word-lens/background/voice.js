// 朗讀語音挑選：避開 macOS／iOS 內建的特效與怪聲語音（Zarvox、Whisper、Bad News、Albert 等）。
// 為什麼需要：只指定語言 en-US、不指定語音時，瀏覽器可能挑到清單裡的怪聲語音，聽起來像機器人或鬼；
// 而且更新作業系統後清單會變，「以前正常、現在變怪」就是這樣發生的。
// 這支檔案只含純函式，背景程式與網頁版共用（網頁版用動態 import 載入）。

// 不適合學習用的語音（特效、舊式合成、角色扮演）。名稱比對時會先去掉括號說明。
export const BAD_VOICES = /^(Albert|Bad News|Bahh|Bells|Boing|Bubbles|Cellos|Good News|Jester|Organ|Superstar|Trinoids|Whisper|Wobble|Zarvox|Fred|Junior|Ralph|Kathy|Grandma|Grandpa|Pipe Organ|Deranged|Hysterical)$/i;

// 偏好順序：越前面越優先。有「(Enhanced)／(Premium)／Natural」的高品質版本再加分。
const PREFER = [
  /^Microsoft (Aria|Jenny|Guy|Ava|Andrew|Emma|Brian)\b.*Natural/i,
  /^Samantha$/i,
  /^Ava$/i,
  /^Allison$/i,
  /^Nicky$/i,
  /^Google US English$/i,
  /^Alex$/i,
  /^(Evan|Zoe|Tom|Susan)$/i,
  /^Microsoft (Zira|David|Mark)\b/i,
  /^(Eddy|Flo|Reed|Rocko|Sandy|Shelley)$/i
];

const baseName = (n) => String(n || '').replace(/\s*[（(].*$/, '').trim();

// voices：[{ name, lang, local }]，name 為語音名稱。回傳挑中的那一個，或 null（讓系統自己決定）。
export function pickVoice(voices, lang = 'en-US') {
  const l = lang.toLowerCase();
  const all = (voices || []).filter((v) => v && v.name && !BAD_VOICES.test(baseName(v.name)));
  const norm = (v) => String(v.lang || '').toLowerCase().replace('_', '-');
  const pool = all.filter((v) => norm(v) === l);
  const score = (v) => {
    const b = baseName(v.name);
    let i = PREFER.findIndex((re) => re.test(b) || re.test(v.name));
    if (i < 0) i = PREFER.length; // 沒列名但也不在黑名單：排在偏好之後
    const quality = /enhanced|premium|natural/i.test(v.name) ? -0.5 : 0;
    const online = v.local === false ? 0.25 : 0; // 同等條件下，本機語音優先（離線也能用）
    return i + quality + online;
  };
  const best = (arr) => arr.slice().sort((a, b) => score(a) - score(b))[0] || null;
  return best(pool) || best(all.filter((v) => norm(v).startsWith(l.slice(0, 2) + '-'))) || null;
}
