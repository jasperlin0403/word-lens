// AI 提供者：Google Gemini
// 介面約定（新增其他 AI 時照此實作）：
//   id、label、keyName、models、generateJSON(prompt, { apiKey, model }) → 解析後的 JSON 物件
//   錯誤請拋出 makeError，code 使用：NO_KEY BAD_KEY BAD_MODEL MODEL_NOT_FREE QUOTA_MINUTE QUOTA_DAY NETWORK API EMPTY PARSE
import { makeError } from '../errors.js';

export const id = 'gemini';
export const label = 'Google Gemini';
export const keyName = 'geminiKey';
// 每日免費額度（rpd）來源：使用者帳號的 Google AI Studio Rate Limit 頁面（2026 年 9 月）；Google 可能調整
export const models = [
  { id: 'gemini-3.5-flash-lite', label: 'Gemini 3.5 Flash Lite', rpd: 500, note: '建議' },
  { id: 'gemini-3.1-flash-lite', label: 'Gemini 3.1 Flash Lite', rpd: 500, note: '建議作為備援' },
  { id: 'gemma-4-26b-a4b-it', label: 'Gemma 4 26B', rpd: 14400, note: '額度多，需先測試', experimental: true },
  { id: 'gemma-4-31b-it', label: 'Gemma 4 31B', rpd: 14400, note: '額度多、較慢，需先測試', experimental: true },
  { id: 'gemini-3.5-flash', label: 'Gemini 3.5 Flash', rpd: 20, note: '額度很少' },
  { id: 'gemini-2.5-flash-lite', label: 'Gemini 2.5 Flash Lite', rpd: 20, note: '額度很少' }
];
export const defaultFallbacks = ['gemini-3.1-flash-lite'];
export const gemmaFallback = 'gemma-4-26b-a4b-it';

// 依模型設定最低思考量以加快回應（Flash-Lite 系列預設已是最低）
function thinkingFor(model) {
  if (/^gemini-3\.[56]-flash$/.test(model)) return { thinkingLevel: 'minimal' };
  if (/^gemini-3\.[78]-flash$/.test(model)) return { thinkingLevel: 'low' };
  if (/^gemini-2\.5-flash(-lite)?$/.test(model)) return { thinkingBudget: 0 };
  if (/^gemma-4/.test(model)) return { thinkingLevel: 'minimal' };
  return null;
}

function parseJsonText(text) {
  const t = String(text || '').trim().replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/, '');
  try {
    return JSON.parse(t);
  } catch (e) {
    const s = t.indexOf('{');
    const end = t.lastIndexOf('}');
    if (s >= 0 && end > s) return JSON.parse(t.slice(s, end + 1));
    throw e;
  }
}

// opts.plain：不要求 JSON 模式（部分模型如 Gemma 可能不支援，失敗時自動改用純文字＋解析）
// 偶發的格式錯誤：自動重試一次（AI 有時會回傳無法解析的內容）
export async function generateJSON(prompt, opts, useThinking = true, plain = false) {
  try {
    return await generateJSONOnce(prompt, opts, useThinking, plain);
  } catch (e) {
    if (e.code !== 'PARSE' && e.code !== 'EMPTY') throw e;
    await new Promise((r) => setTimeout(r, 800));
    return generateJSONOnce(prompt, opts, useThinking, plain);
  }
}

async function generateJSONOnce(prompt, { apiKey, model }, useThinking = true, plain = false) {
  if (!apiKey) throw makeError('NO_KEY', '尚未設定 Gemini API 金鑰。');
  const thinking = useThinking ? thinkingFor(model) : null;
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), 30000);
  let res;
  try {
    res = await fetch('https://generativelanguage.googleapis.com/v1beta/models/' + encodeURIComponent(model) + ':generateContent', {
      method: 'POST',
      signal: ctrl.signal,
      headers: { 'Content-Type': 'application/json', 'x-goog-api-key': apiKey },
      body: JSON.stringify({
        contents: [{ role: 'user', parts: [{ text: prompt }] }],
        generationConfig: Object.assign(
          plain ? { temperature: 0.2 } : { temperature: 0.2, responseMimeType: 'application/json' },
          thinking ? { thinkingConfig: thinking } : {}
        )
      })
    });
  } catch (e) {
    throw makeError('NETWORK', 'Gemini 連線失敗或逾時，請稍後再試。');
  } finally {
    clearTimeout(timer);
  }

  if (!res.ok) {
    let body = {};
    try { body = await res.json(); } catch (e) { /* 忽略 */ }
    const msg = (body.error && body.error.message) || '';
    const raw = JSON.stringify(body);
    if (res.status === 400 && thinking && /think/i.test(msg)) return generateJSONOnce(prompt, { apiKey, model }, false, plain);
    if (res.status === 400 && !plain && /json|mime/i.test(msg)) return generateJSONOnce(prompt, { apiKey, model }, useThinking, true);
    if (res.status === 400 && /api key/i.test(msg)) throw makeError('BAD_KEY', 'API 金鑰無效，請到設定頁重新貼上。');
    if (res.status === 403) throw makeError('BAD_KEY', 'API 金鑰沒有權限使用 Gemini，請確認金鑰是在 Google AI Studio 建立的。');
    if (res.status === 404) throw makeError('BAD_MODEL', '找不到模型「' + model + '」，請到設定頁改選其他模型。');
    if (res.status === 429) {
      if (/limit:\s*0\b/.test(msg)) throw makeError('MODEL_NOT_FREE', '這個模型在你的免費方案中不可用，請到設定頁改選其他模型。');
      const retry = /"retryDelay"\s*:\s*"(\d+(?:\.\d+)?)s"/.exec(raw);
      const daily = /PerDay/i.test(raw);
      throw makeError(daily ? 'QUOTA_DAY' : 'QUOTA_MINUTE', daily ? '今天的 AI 額度已用完。' : 'AI 每分鐘的額度已用完。', {
        retryMs: retry ? parseFloat(retry[1]) * 1000 : null
      });
    }
    throw makeError('API', 'Gemini 回傳錯誤（' + res.status + '）' + (msg ? '：' + msg : ''));
  }

  const data = await res.json();
  const cand = data.candidates && data.candidates[0];
  const text = cand && cand.content && Array.isArray(cand.content.parts)
    ? cand.content.parts.filter((p) => !p.thought).map((p) => p.text || '').join('')
    : '';
  if (!text) throw makeError('EMPTY', 'Gemini 沒有產生內容' + (cand && cand.finishReason ? '（' + cand.finishReason + '）' : '') + '，請再試一次。');
  try {
    return parseJsonText(text);
  } catch (e) {
    throw makeError('PARSE', 'Gemini 回傳的格式無法解讀，請再試一次。');
  }
}
