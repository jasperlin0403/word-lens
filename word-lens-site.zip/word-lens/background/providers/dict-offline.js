// 字典提供者：離線英漢詞典（ECDICT，MIT 授權；依字首分檔，載入後留在記憶體）
const files = {};
function loadLetter(ch) {
  if (!/^[a-z]$/.test(ch)) return Promise.resolve(null);
  if (!files[ch]) {
    files[ch] = fetch(chrome.runtime.getURL('dict/' + ch + '.json'))
      .then((r) => r.json())
      .catch(() => { delete files[ch]; return null; });
  }
  return files[ch];
}

export async function lookup(word) {
  const w = String(word || '').toLowerCase().replace(/’/g, "'").replace(/'s$/, '').trim();
  if (!w) return { found: false };
  const file = await loadLetter(w[0]);
  if (!file) return { found: false };
  let lemma = w;
  let entry = file.w[w];
  if (!entry && file.f[w]) {
    lemma = file.f[w];
    const lf = await loadLetter(lemma[0]);
    entry = lf && lf.w[lemma];
  }
  if (!entry) return { found: false };
  return { found: true, lemma, phonetic: entry[0], lines: entry[1].split('\n') };
}
