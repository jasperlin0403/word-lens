// 提供者登記處：新增 AI 時，在這裡加一行 import 即可
import * as gemini from './ai-gemini.js';

export const aiProviders = { [gemini.id]: gemini };
export const getAiProvider = (id) => aiProviders[id] || gemini;
