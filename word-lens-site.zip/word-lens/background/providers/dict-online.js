// 字典提供者：Free Dictionary API（英英解釋、例句、真人發音；免金鑰）
import { makeError } from '../errors.js';

export async function lookup(word) {
  const w = String(word || '').toLowerCase().replace(/['’]s$/, '');
  const url = 'https://api.dictionaryapi.dev/api/v2/entries/en/' + encodeURIComponent(w);
  let res = null;
  for (let attempt = 0; attempt < 2 && !res; attempt++) {
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), 10000);
    try {
      res = await fetch(url, { signal: ctrl.signal });
    } catch (e) {
      res = null;
    } finally {
      clearTimeout(timer);
    }
  }
  if (!res) throw makeError('NETWORK', '英英字典暫時連不上。');
  if (res.status === 404) return { notFound: true };
  if (!res.ok) throw makeError('DICT', '英英字典暫時無法使用（' + res.status + '）。');

  const data = await res.json();
  let phonetic = '';
  let audio = '';
  const meanings = [];
  for (const entry of Array.isArray(data) ? data : []) {
    if (!phonetic && entry.phonetic) phonetic = entry.phonetic;
    for (const p of entry.phonetics || []) {
      if (!phonetic && p.text) phonetic = p.text;
      if (p.audio && (!audio || /-us\.mp3$/i.test(p.audio))) audio = p.audio; // 優先美式發音
    }
    for (const m of entry.meanings || []) {
      let g = meanings.find((x) => x.pos === m.partOfSpeech);
      if (!g) {
        if (meanings.length >= 3) continue;
        g = { pos: m.partOfSpeech, defs: [] };
        meanings.push(g);
      }
      for (const d of m.definitions || []) {
        if (g.defs.length >= 2) break;
        g.defs.push({ def: d.definition || '', example: d.example || '' });
      }
    }
  }
  if (audio.startsWith('//')) audio = 'https:' + audio;
  return { notFound: false, phonetic, audio, meanings };
}
