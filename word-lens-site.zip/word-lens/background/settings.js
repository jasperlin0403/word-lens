// 設定（chrome.storage.local，網頁端需要讀取）與機密（IndexedDB，網頁端讀不到）
import * as db from './db.js';

export const SCHEMA = 3;
export const DEFAULTS = {
  schema: SCHEMA,
  enabled: true,        // 啟用查詢
  highlight: true,      // 標色生詞本裡的字
  hover: true,          // 按住 Ctrl 指著單字查詢
  aiMode: 'auto',       // auto：停留 0.5 秒才呼叫｜manual：按按鈕才呼叫｜off：純離線
  aiProvider: 'gemini',
  model: 'gemini-3.5-flash-lite',
  autoFallback: true,   // 額度用完時自動改用備援模型
  gemmaBackup: false,   // 把 Gemma 4 加為第二備援（需先在設定頁測試）
  reviewMode: 'auto'    // 複習卡片形式：auto（依熟悉度搭配）｜recognize｜spell｜listen
};

export async function getSettings() {
  const { settings } = await chrome.storage.local.get('settings');
  return { ...DEFAULTS, ...(settings || {}) };
}

export const getSecret = (name) => db.get('kv', 'secret:' + name);
export const setSecret = (name, value) =>
  value ? db.put('kv', 'secret:' + name, value) : db.del('kv', 'secret:' + name);

// 資料版本低於目前版本（或仍有舊格式的金鑰）時才轉移；同一次啟動只執行一次
let migrating = null;
export function ensureMigrated() {
  if (!migrating) {
    migrating = chrome.storage.local.get('settings').then(({ settings }) => {
      if (!settings || (settings.schema || 0) < SCHEMA || settings.apiKey) return migrate();
    }).catch((e) => {
      migrating = null;
      throw e;
    });
  }
  return migrating;
}

// 舊版資料轉移（v1.x → schema 2）
async function migrate() {
  const got = await chrome.storage.local.get(['settings', 'aiCache', 'pdfProgress', 'words']);
  const s = { ...(got.settings || {}) };
  if (s.apiKey) {
    await setSecret('geminiKey', s.apiKey); // 金鑰移出網頁端可讀取的位置
    delete s.apiKey;
  }
  if (got.pdfProgress && typeof got.pdfProgress === 'object') {
    for (const [fp, v] of Object.entries(got.pdfProgress)) await db.put('pdfProgress', fp, { ...v, t: v.time || Date.now() });
  }
  for (const [k, v] of Object.entries(got.words || {})) {
    if (v.lookups && !(await db.get('stats', k))) await db.put('stats', k, { lookups: v.lookups, t: Date.now() });
  }
  // schema 3：生詞加上熟悉度（1–5），並建立複習排程
  const words = got.words || {};
  let changed = false;
  for (const [k, v] of Object.entries(words)) {
    if (!v.level) { v.level = 1; changed = true; }
    if (!(await db.get('srs', k))) await db.put('srs', k, { due: Date.now(), interval: 0, ease: 2.5, reps: 0, lapses: 0 });
  }
  if (changed) await chrome.storage.local.set({ words });
  if (got.aiCache || got.pdfProgress) await chrome.storage.local.remove(['aiCache', 'pdfProgress']);
  await chrome.storage.local.set({ settings: { ...DEFAULTS, ...s, schema: SCHEMA } });
}
