// 點字學英文 Word Lens — 背景程式入口：安裝／更新、右鍵選單、訊息路由
import * as db from './db.js';
import * as quota from './quota.js';
import * as ai from './ai.js';
import * as words from './words.js';
import * as dictOffline from './providers/dict-offline.js';
import * as dictOnline from './providers/dict-online.js';
import { getAiProvider } from './providers/index.js';
import { getSettings, getSecret, setSecret, ensureMigrated } from './settings.js';
import { makeError } from './errors.js';

// 背景程式實際執行的版本（由入口檔設定）；頁面用來確認沒有沿用到舊版背景程式
let BUILD = '';
export const setBuild = (v) => { BUILD = v; };

const pageUrl = (path, params) => chrome.runtime.getURL(path) + (params ? '?' + new URLSearchParams(params) : '');
const viewerUrl = (file) => pageUrl('pdf/viewer.html', file ? { file } : null);

// ---------- 資料版本、待複習數字 ----------
// 每次背景程式啟動都檢查一次（不只依賴「安裝／更新」事件：某些更新方式不會觸發它）
ensureMigrated().then(() => words.refreshBadge());
chrome.alarms.create('wl-badge', { periodInMinutes: 30 });
chrome.alarms.onAlarm.addListener((a) => { if (a.name === 'wl-badge') words.refreshBadge(); });
chrome.runtime.onStartup.addListener(() => words.refreshBadge());

// ---------- 安裝／更新 ----------
chrome.runtime.onInstalled.addListener(async (details) => {
  await ensureMigrated();
  if (details.reason === 'install' || details.reason === 'update') await injectIntoOpenTabs();
  if (details.reason === 'install') chrome.runtime.openOptionsPage();
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({ id: 'wl-open-pdf-link', title: '用點字學英文的 PDF 閱讀器開啟', contexts: ['link'] });
  });
});

// 讓已開著的分頁不用重新整理就能使用（檔案清單直接讀 manifest，不重複維護）
async function injectIntoOpenTabs() {
  const cs = chrome.runtime.getManifest().content_scripts[0];
  let tabs = [];
  try { tabs = await chrome.tabs.query({}); } catch (e) { return; }
  for (const t of tabs) {
    if (!t.id || !t.url || !/^(https?|file):/.test(t.url)) continue;
    try {
      await chrome.scripting.insertCSS({ target: { tabId: t.id, allFrames: true }, files: cs.css });
      await chrome.scripting.executeScript({ target: { tabId: t.id, allFrames: true }, files: cs.js });
    } catch (e) { /* 無權限的頁面略過 */ }
  }
}

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === 'wl-open-pdf-link' && info.linkUrl) {
    chrome.tabs.create({ url: viewerUrl(info.linkUrl), index: tab ? tab.index + 1 : undefined });
  }
});

// ---------- 訊息路由 ----------
// 一般訊息：網頁端與擴充功能頁面都可使用
const handlers = {
  ping: () => ({ build: BUILD }),
  offline: (m) => dictOffline.lookup(m.word),
  dict: (m) => dictOnline.lookup(m.word),
  'ai-word': (m) => ai.explainWord(m.word, m.sentence, { cacheOnly: !!m.cacheOnly }),
  'ai-sentence': (m) => ai.explainSentence(m.text, { cacheOnly: !!m.cacheOnly }),
  touch: (m) => words.touch(m.word),
  'save-word': (m) => words.save(m.entry),
  'set-level': (m) => words.setLevel(m.word, m.level),
  speak: (m) => {
    chrome.tts.speak(String(m.text || '').slice(0, 1000), { lang: 'en-US', rate: m.rate || 0.9 });
    return true;
  },
  'quota-status': () => quota.status(),
  'open-options': () => chrome.runtime.openOptionsPage(),
  'open-wordbook': () => chrome.tabs.create({ url: pageUrl('pages/wordbook.html') }),
  'open-review': () => chrome.tabs.create({ url: pageUrl('pages/review.html') }),
  'open-pdf': async (m) => {
    if (m.tabId && m.url) await chrome.tabs.update(m.tabId, { url: viewerUrl(m.url) });
    else await chrome.tabs.create({ url: viewerUrl('') });
    return true;
  }
};

// 敏感訊息：只接受擴充功能自己的頁面（設定頁、生詞本、閱讀器），網頁端不能呼叫
const privileged = {
  'key-status': async () => {
    const p = getAiProvider((await getSettings()).aiProvider);
    const k = await getSecret(p.keyName);
    return { provider: p.label, set: !!k, masked: k ? k.slice(0, 4) + '…' + k.slice(-4) : '' };
  },
  'set-key': async (m) => {
    const p = getAiProvider((await getSettings()).aiProvider);
    await setSecret(p.keyName, String(m.key || '').trim());
    return true;
  },
  'provider-info': async () => {
    const p = getAiProvider((await getSettings()).aiProvider);
    return { id: p.id, label: p.label, models: p.models, fallbacks: p.defaultFallbacks, gemma: p.gemmaFallback };
  },
  'model-chain': async () => {
    const s = await getSettings();
    return ai.modelChain(s, getAiProvider(s.aiProvider));
  },
  test: () => ai.testConnection(),
  'test-model': (m) => ai.testModel(m.model),
  'review-queue': (m) => words.reviewQueue(m.limit || 30, m.mode),
  'review-answer': (m) => words.answer(m.key, m.rating),
  'practice-pool': (m) => words.practicePool(m.scope, m.n, m.mode),
  'export-srs': () => words.exportSrs(),
  'import-srs': (m) => words.importSrs(m.srs),
  'review-stats': () => words.reviewStats(),
  'quota-resume': () => quota.resume(),
  'stats-all': () => words.allStats(),
  'pdf-progress-get': (m) => db.get('pdfProgress', m.fp),
  'pdf-progress-set': async (m) => {
    await db.put('pdfProgress', m.fp, { ...m.data, t: Date.now() });
    return db.prune('pdfProgress', 100);
  },
  'pdf-progress-list': async () => Object.values(await db.getAll('pdfProgress')).sort((a, b) => b.t - a.t).slice(0, 10)
};

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  const type = msg && msg.type;
  const fromExtPage = !!(sender.url && sender.url.startsWith(chrome.runtime.getURL('')));
  const fn = handlers[type] || (fromExtPage && privileged[type]);
  const run = fn ? ensureMigrated().then(() => fn(msg, sender)) : Promise.reject(makeError('UNKNOWN', '未知或不允許的指令'));
  run
    .then((data) => sendResponse({ ok: true, data: data === undefined ? true : data }))
    .catch((e) => sendResponse({ ok: false, error: { code: e.code || 'ERROR', message: e.message || String(e), until: e.until } }));
  return true;
});
