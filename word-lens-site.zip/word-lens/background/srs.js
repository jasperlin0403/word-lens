// 複習排程（間隔重複，簡化版 SM-2）與熟悉度規則
// 熟悉度：1 新字｜2 認得｜3 學習中｜4 快熟了｜5 已掌握（網頁上不標色）
// 評分：again 忘記｜hard 模糊｜good 記得｜easy 很簡單
const DAY = 86400000;
const MIN = 60000;

export const newState = (now = Date.now()) => ({ due: now, interval: 0, ease: 2.5, reps: 0, lapses: 0, last: 0 });

// 純函式：輸入目前排程、熟悉度與評分，回傳新的排程與熟悉度
export function schedule(st, level, rating, now = Date.now()) {
  const s = { ...newState(now), ...(st || {}) };
  let lv = level || 1;
  if (rating === 'again') {
    s.lapses++;
    s.reps = 0;
    s.interval = 0;
    s.ease = Math.max(1.3, s.ease - 0.2);
    s.due = now + 10 * MIN; // 10 分鐘後再出現（同一輪複習的最後）
    lv = Math.max(1, lv - 1);
  } else if (rating === 'hard') {
    s.interval = Math.max(1, Math.round((s.interval || 1) * 1.2));
    s.ease = Math.max(1.3, s.ease - 0.15);
    s.due = now + s.interval * DAY;
  } else {
    if (s.reps === 0) s.interval = rating === 'easy' ? 3 : 1;
    else if (s.reps === 1) s.interval = rating === 'easy' ? 7 : 3;
    else s.interval = Math.round(s.interval * s.ease * (rating === 'easy' ? 1.3 : 1));
    if (rating === 'easy') s.ease += 0.15;
    s.reps++;
    s.due = now + s.interval * DAY;
    lv = Math.min(5, lv + (rating === 'easy' ? 2 : 1));
  }
  s.last = now;
  return { state: s, level: lv };
}

// 手動調整熟悉度時，同步調整下次複習時間
export function forLevel(st, level, now = Date.now()) {
  const s = { ...newState(now), ...(st || {}) };
  if (level >= 5) { s.interval = Math.max(s.interval, 60); s.due = now + s.interval * DAY; }
  else if (level <= 1) { s.interval = 0; s.reps = 0; s.due = now; }
  return s;
}

// 依熟悉度決定題型（auto）：有標準答案的題目為主（選擇題、本句意思、拼字、聽音選字），自評的「看英文想中文」只占少數
// 1 新字：選擇題（看英文選中文）與本句意思｜2 認得：加入拼字｜3 以上：拼字、聽音為主，穿插選擇題
// canSense：這個字存過「本句意思」，可以出「這句話裡是哪個意思」
export function pickMode(level, fixed, canSense = false) {
  if (fixed === 'sense') return canSense ? 'sense' : 'choice';
  if (fixed && fixed !== 'auto') return fixed;
  const table = (level || 1) <= 1
    ? [['choice', 50], ['sense', 30], ['recognize', 20]]
    : level === 2
      ? [['choice', 35], ['sense', 25], ['spell', 25], ['recognize', 15]]
      : [['spell', 35], ['listen', 25], ['sense', 20], ['choice', 20]];
  const rows = table.filter(([m]) => canSense || m !== 'sense');
  let r = Math.random() * rows.reduce((t, [, w]) => t + w, 0);
  for (const [m, w] of rows) if ((r -= w) < 0) return m;
  return rows[0][0];
}
