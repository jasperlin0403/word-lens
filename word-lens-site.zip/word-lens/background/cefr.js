// 生詞自動分級：CEFR（歐洲語言共同參考架構）A1–C2
// 等級表 dict/cefr.json 由 CEFR-J Wordlist（A1–B2）與 Octanove C1/C2 合併（tools/build_cefr.py，出處見 dict/LICENSE-CEFR.txt）
// 表裡沒有的字回傳 ''（表外：多半是 C2 以上、專有名詞或專業用語）
import * as dictOffline from './providers/dict-offline.js';

export const LEVELS = ['A1', 'A2', 'B1', 'B2', 'C1', 'C2'];
let table = null;

export function load() {
  if (!table) {
    table = fetch(chrome.runtime.getURL('dict/cefr.json'))
      .then((r) => r.json())
      .catch(() => { table = null; return {}; });
  }
  return table;
}

// 依序試：原字、存下的變化形、詞典原形（went → go）
export async function levelOf(...words) {
  const t = await load();
  const tried = [...new Set(words.filter(Boolean).map((w) => String(w).toLowerCase().trim()))];
  for (const w of tried) if (t[w]) return t[w];
  for (const w of tried) {
    if (/\s/.test(w)) continue;
    const r = await dictOffline.lookup(w);
    if (r.found && t[r.lemma]) return t[r.lemma];
  }
  return '';
}

// 某個等級的字（出選擇題的干擾選項用）
export async function wordsAt(levels) {
  const t = await load();
  const want = new Set(levels);
  return Object.keys(t).filter((w) => want.has(t[w]) && /^[a-z]+$/.test(w));
}
