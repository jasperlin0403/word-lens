// AI 服務：組 prompt、查快取、檢查模式與額度、呼叫提供者
import * as db from './db.js';
import * as quota from './quota.js';
import { makeError } from './errors.js';
import { getAiProvider } from './providers/index.js';
import { getSettings, getSecret } from './settings.js';

const CACHE_MAX = 3000;
let writesSincePrune = 0;

const PREFIX = '你是一位英文老師，學生的母語是繁體中文（台灣）。請使用台灣慣用的詞彙與繁體中文回答。';

function wordPrompt(word, sentence) {
  return [
    PREFIX,
    '學生在閱讀時查詢了一個英文單字，請根據它所在的句子說明。',
    '',
    '單字：' + word,
    '所在句子：' + (sentence || '（沒有提供句子，請提供最常見的意思）'),
    '',
    '請只回傳一個 JSON 物件，不要有其他文字，欄位如下：',
    '{',
    '  "lemma": "此字的字典原形，一般字用小寫（例如 running → run）",',
    '  "pos": "此字在本句中的詞性，用中文，例如：名詞、動詞（過去式）、形容詞",',
    '  "zh": "這個字常見的中文意思，最多 3 個，用「；」分隔",',
    '  "context_zh": "這個字在本句中的具體意思與用法，1 到 2 句",',
    '  "sentence_zh": "整句的通順中文翻譯（沒有句子時填空字串）",',
    '  "phrase": "若此字在本句中屬於片語或慣用語（例如 give up），填片語原形，否則填空字串",',
    '  "phonetic": "此字原形的 IPA 音標（美式），例如 /ˈɪn.dɪ.keɪt/",',
    '  "en_def": "符合本句用法的簡短英英解釋（英文，一句）",',
    '  "en_example": "另一個自然的英文例句（不要重複原句）"',
    '}'
  ].join('\n');
}

function sentencePrompt(text) {
  return [
    PREFIX,
    '請翻譯並解析下面這段英文：',
    '',
    text,
    '',
    '請只回傳一個 JSON 物件，不要有其他文字，欄位如下：',
    '{',
    '  "translation": "通順自然的中文翻譯",',
    '  "structure": "句子的主要結構說明（主詞、動詞、子句等），1 到 3 句；若為多句的段落，說明最關鍵的一句",',
    '  "grammar": [ { "point": "文法重點名稱", "explain": "簡短說明，並指出原文中對應的部分" } ],',
    '  "vocab": [ { "word": "值得學習的單字或片語（原文寫法）", "zh": "在此處的中文意思" } ]',
    '}',
    'grammar 最多 4 項，vocab 最多 6 項。'
  ].join('\n');
}

const str = (v) => String(v || '').trim();

function cleanWord(d, word) {
  return {
    lemma: str(d.lemma) || word, pos: str(d.pos), zh: str(d.zh), context_zh: str(d.context_zh),
    sentence_zh: str(d.sentence_zh), phrase: str(d.phrase), phonetic: str(d.phonetic),
    en_def: str(d.en_def), en_example: str(d.en_example)
  };
}

function cleanSentence(d) {
  return {
    translation: str(d.translation),
    structure: str(d.structure),
    grammar: (Array.isArray(d.grammar) ? d.grammar : []).slice(0, 4).map((g) => ({ point: str(g.point), explain: str(g.explain) })),
    vocab: (Array.isArray(d.vocab) ? d.vocab : []).slice(0, 6).map((v) => ({ word: str(v.word), zh: str(v.zh) })).filter((v) => v.word)
  };
}

async function cached(key) {
  const hit = await db.get('aiCache', key);
  return hit ? hit.data : null;
}

async function remember(key, data) {
  await db.put('aiCache', key, { t: Date.now(), data });
  if (++writesSincePrune >= 50) {
    writesSincePrune = 0;
    db.prune('aiCache', CACHE_MAX).catch(() => {});
  }
}

// 依設定排出要嘗試的模型：主要模型 → 備援（3.1 Flash Lite）→ Gemma（若啟用）
export function modelChain(s, provider) {
  const chain = [s.model];
  if (s.autoFallback) {
    for (const m of provider.defaultFallbacks || []) if (!chain.includes(m)) chain.push(m);
    if (s.gemmaBackup && provider.gemmaFallback && !chain.includes(provider.gemmaFallback)) chain.push(provider.gemmaFallback);
  }
  return chain;
}

// 共用流程：快取 → 模式 → 依序嘗試各模型（額度用完就換下一個）；cacheOnly 時只查快取（不消耗額度）
async function run(key, prompt, clean, { cacheOnly } = {}) {
  const hit = await cached(key);
  if (hit) return { ...hit, cached: true };
  if (cacheOnly) return null;

  const s = await getSettings();
  if (s.aiMode === 'off') throw makeError('AI_OFF', 'AI 已關閉，目前只顯示離線結果。');
  const provider = getAiProvider(s.aiProvider);
  const apiKey = await getSecret(provider.keyName);
  if (!apiKey) throw makeError('NO_KEY', '尚未設定 ' + provider.label + ' 的 API 金鑰。');

  const chain = modelChain(s, provider);
  let earliest = null;
  let lastErr = null;
  for (let i = 0; i < chain.length; i++) {
    const model = chain[i];
    const paused = await quota.pausedInfo(model);
    if (paused) {
      if (!earliest || paused.until < earliest.until) earliest = paused;
      continue;
    }
    await quota.recordRequest(model);
    try {
      const data = { ...clean(await provider.generateJSON(prompt, { apiKey, model })), model };
      await remember(key, data);
      return data;
    } catch (e) {
      if (e.code === 'QUOTA_DAY' || e.code === 'QUOTA_MINUTE') {
        const p = await quota.pause(model, e.code === 'QUOTA_DAY' ? 'day' : 'minute', e.retryMs);
        if (!earliest || p.until < earliest.until) earliest = p;
        continue;
      }
      // 備援模型無法使用（不在免費方案、名稱錯誤、格式問題）→ 換下一個；主要模型的錯誤直接回報
      if (i > 0 && ['MODEL_NOT_FREE', 'BAD_MODEL', 'PARSE', 'EMPTY', 'API'].includes(e.code)) {
        lastErr = e;
        continue;
      }
      throw e;
    }
  }
  if (earliest) throw makeError('PAUSED', pausedMessage(earliest), { until: earliest.until });
  throw lastErr || makeError('API', 'AI 暫時無法使用。');
}

function pausedMessage({ until, reason }) {
  const t = new Date(until).toLocaleTimeString('zh-TW', { hour: '2-digit', minute: '2-digit' });
  return (reason === 'day' ? '今天的 AI 額度已用完' : 'AI 每分鐘額度已用完') + '，約 ' + t + ' 自動恢復；目前改用離線結果。';
}

export const explainWord = (word, sentence, opts) =>
  run('w2|' + word.toLowerCase() + '|' + (sentence || '').slice(0, 400), wordPrompt(word, sentence), (d) => cleanWord(d, word), opts);

export const explainSentence = (text, opts) =>
  run('s|' + text.slice(0, 600), sentencePrompt(text), cleanSentence, opts);

export async function testConnection() {
  const s = await getSettings();
  const provider = getAiProvider(s.aiProvider);
  const apiKey = await getSecret(provider.keyName);
  const out = await provider.generateJSON('請只回傳這個 JSON：{"ok": true}', { apiKey, model: s.model });
  await quota.resume();
  return out;
}

// 設定頁的「測試模型」：用真實的查字 prompt 測格式、中文品質、速度（不寫入快取）
export async function testModel(model) {
  const s = await getSettings();
  const provider = getAiProvider(s.aiProvider);
  const apiKey = await getSecret(provider.keyName);
  const sentence = 'Where a week is indicated, this does not mean that it should take you a whole week.';
  const t0 = Date.now();
  const raw = await provider.generateJSON(wordPrompt('indicated', sentence), { apiKey, model });
  const ms = Date.now() - t0;
  const d = cleanWord(raw, 'indicated');
  const fields = ['lemma', 'pos', 'zh', 'context_zh', 'sentence_zh', 'phonetic', 'en_def'];
  const missing = fields.filter((f) => !d[f]);
  // 粗略檢查是否為繁體：出現常見簡體字即提醒
  const simplified = /[这个为时说们来对过还没发会样后动见么应]/.test(d.zh + d.context_zh + d.sentence_zh);
  return { model, ms, ok: missing.length === 0 && !simplified, missing, simplified, sample: d };
}
