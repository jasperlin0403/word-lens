// 背景程式入口（檔名含版本號，由 tools/release.py 產生）
// Chrome 會快取背景程式，同一個檔名在某些更新方式下會一直沿用舊版程式碼；換檔名能確保載入新版。
import { setBuild } from './main.js';
setBuild('2.3.0');
