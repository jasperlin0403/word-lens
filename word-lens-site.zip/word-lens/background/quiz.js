// 四選一選擇題的選項：干擾選項先從生詞本找，不夠再從同一 CEFR 等級的常用字補
// dir：en2zh 看英文選中文｜zh2en 看中文選英文｜listen 聽發音選英文（偏好字首相同、長度相近，聽起來容易混淆）
import * as dictOffline from './providers/dict-offline.js';
import * as cefr from './cefr.js';

const shuffle = (a) => {
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
};

// 詞典的一行「n. 住址, 演說, 舉止」→ { pos: 'n.', text: 'n. 住址, 演說' }（只留前兩個意思，選項才不會太長）
function shortLine(line) {
  const m = /^\s*((?:[a-z]+\.\s*)+|\[[^\]]+\]\s*)?(.*)$/i.exec(String(line || ''));
  const pos = (m[1] || '').trim();
  const glosses = (m[2] || '').split(/[,，;；]/).map((s) => s.trim()).filter(Boolean).slice(0, 2);
  return { pos, text: (pos ? pos + ' ' : '') + glosses.join(', ') };
}

// 一個字的中文短釋義；有詞性時盡量挑同詞性的那一行，選項看起來才一致
function meaningOf(zh, pos) {
  const lines = String(zh || '').split(/\n|；(?=[a-z]+\.)/).map(shortLine).filter((l) => l.text.length > (l.pos ? l.pos.length + 1 : 0));
  if (!lines.length) return '';
  return ((pos && lines.find((l) => l.pos === pos)) || lines[0]).text;
}

const display = (w) => (w.lemma || w.key || '').toLowerCase();

export async function options({ word, answer, dir = 'en2zh', pool = [], level = '' }) {
  const target = display(word);
  const wantEnglish = dir !== 'en2zh';
  const right = wantEnglish ? target : answer || meaningOf(word.zh);
  if (!right) return null;
  const pos = wantEnglish ? '' : (shortLine(right).pos || '');
  // 正確答案沒有詞性（例如舊資料的「持續、留下來」）時，干擾選項也拿掉詞性，避免從格式猜出答案
  const bare = !wantEnglish && !pos;
  const fmt = (t) => (bare ? t.replace(/^\s*(?:[a-z]+\.\s*)+|^\s*\[[^\]]+\]\s*/i, '').replace(/,\s*/g, '、') : t);
  const seen = new Set([right]);
  const picks = [];
  const add = (label) => {
    if (!label || seen.has(label) || picks.length >= 3) return;
    if (!wantEnglish && (label.includes(right) || right.includes(label))) return;
    seen.add(label);
    picks.push(label);
  };

  // 1) 生詞本裡的其他字
  const others = shuffle(pool.filter((w) => display(w) && display(w) !== target && !/\s/.test(display(w))));
  if (dir === 'listen') others.sort((a, b) => sim(b) - sim(a));
  for (const w of others) add(wantEnglish ? display(w) : fmt(meaningOf(w.zh, pos)));

  // 2) 不夠：同一等級（附近等級）的常用字
  if (picks.length < 3) {
    const i = level ? Math.max(0, cefr.LEVELS.indexOf(level)) : cefr.LEVELS.length - 1;   // 表外的字用 C1–C2 當干擾
    let cands = shuffle(await cefr.wordsAt(cefr.LEVELS.slice(Math.max(0, i - 1), i + 2)));
    if (dir === 'listen') cands = cands.filter((w) => w[0] === target[0] && Math.abs(w.length - target.length) <= 2).concat(cands);
    for (const w of cands.slice(0, 60)) {
      if (picks.length >= 3) break;
      if (w === target) continue;
      if (wantEnglish) { add(w); continue; }
      const r = await dictOffline.lookup(w);
      if (r.found) add(fmt(meaningOf(r.lines.join('\n'), pos)));
    }
  }
  if (picks.length < 3) return null;
  const opts = shuffle([right, ...picks]);
  return { options: opts, answer: opts.indexOf(right) };

  function sim(w) {
    const s = display(w);
    return (s[0] === target[0] ? 2 : 0) + (Math.abs(s.length - target.length) <= 2 ? 1 : 0);
  }
}

export { meaningOf };
