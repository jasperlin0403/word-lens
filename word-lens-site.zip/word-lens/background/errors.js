// 統一的錯誤格式：code 供程式判斷，message 給使用者看
export function makeError(code, message, extra) {
  const e = new Error(message);
  e.code = code;
  if (extra) Object.assign(e, extra);
  return e;
}
