// AI 額度保護：記錄每日用量；每個模型各自記錄「暫停到何時」（Google 的額度是依模型分開計算）
import * as db from './db.js';

let state = null;
async function load() {
  if (!state) {
    state = (await db.get('kv', 'quota')) || {};
    state.paused = state.paused || {}; // { 模型: { until, reason } }
    state.day = state.day || '';
    state.count = state.count || 0;
    state.byModel = state.byModel || {};
  }
  return state;
}
const save = () => db.put('kv', 'quota', state);

// Gemini 的每日額度以美國太平洋時間午夜重置
const pacificDay = (d = new Date()) => new Intl.DateTimeFormat('en-CA', { timeZone: 'America/Los_Angeles' }).format(d);
export function msToPacificMidnight(now = new Date()) {
  const p = {};
  new Intl.DateTimeFormat('en-US', { timeZone: 'America/Los_Angeles', hourCycle: 'h23', hour: '2-digit', minute: '2-digit', second: '2-digit' })
    .formatToParts(now)
    .forEach((x) => { p[x.type] = +x.value; });
  return ((23 - (p.hour % 24)) * 3600 + (59 - p.minute) * 60 + (60 - p.second)) * 1000;
}

function rollDay(s) {
  const d = pacificDay();
  if (s.day !== d) {
    s.day = d;
    s.count = 0;
    s.byModel = {};
  }
}

export async function pausedInfo(model) {
  const s = await load();
  const p = s.paused[model];
  return p && p.until > Date.now() ? p : null;
}

export async function recordRequest(model) {
  const s = await load();
  rollDay(s);
  s.count++;
  s.byModel[model] = (s.byModel[model] || 0) + 1;
  await save();
}

export async function pause(model, kind, retryMs) {
  const s = await load();
  const wait = kind === 'day' ? msToPacificMidnight() + 60000 : Math.max(retryMs || 60000, 10000);
  s.paused[model] = { until: Date.now() + wait, reason: kind };
  await save();
  return s.paused[model];
}

export async function resume() {
  const s = await load();
  s.paused = {};
  await save();
}

export async function status() {
  const s = await load();
  rollDay(s);
  const now = Date.now();
  const paused = {};
  for (const [m, p] of Object.entries(s.paused)) if (p.until > now) paused[m] = p;
  return { today: s.count, byModel: { ...s.byModel }, paused };
}
