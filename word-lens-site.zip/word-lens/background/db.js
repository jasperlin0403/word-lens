// IndexedDB 小型封裝（只有背景程式與擴充功能頁面能存取，網頁讀不到）
// 用途：API 金鑰、AI 快取、查詢次數統計、PDF 閱讀進度、額度狀態、複習排程（srs）
const DB_NAME = 'word-lens';
const VERSION = 2;
export const STORES = ['kv', 'aiCache', 'stats', 'pdfProgress', 'srs'];

let dbPromise = null;
function open() {
  if (!dbPromise) {
    dbPromise = new Promise((resolve, reject) => {
      const r = indexedDB.open(DB_NAME, VERSION);
      r.onupgradeneeded = () => {
        for (const s of STORES) if (!r.result.objectStoreNames.contains(s)) r.result.createObjectStore(s);
      };
      r.onsuccess = () => resolve(r.result);
      r.onerror = () => {
        dbPromise = null;
        reject(r.error);
      };
    });
  }
  return dbPromise;
}

const done = (r) => new Promise((resolve, reject) => {
  r.onsuccess = () => resolve(r.result);
  r.onerror = () => reject(r.error);
});

export async function get(store, key) {
  const db = await open();
  return done(db.transaction(store).objectStore(store).get(key));
}

export async function put(store, key, value) {
  const db = await open();
  return done(db.transaction(store, 'readwrite').objectStore(store).put(value, key));
}

export async function del(store, key) {
  const db = await open();
  return done(db.transaction(store, 'readwrite').objectStore(store).delete(key));
}

export async function getAll(store) {
  const db = await open();
  const s = db.transaction(store).objectStore(store);
  const [keys, values] = await Promise.all([done(s.getAllKeys()), done(s.getAll())]);
  const out = {};
  keys.forEach((k, i) => { out[k] = values[i]; });
  return out;
}

// 超過上限時刪除最舊的資料（依 value.t 時間戳）
export async function prune(store, max) {
  const all = await getAll(store);
  const keys = Object.keys(all);
  if (keys.length <= max) return 0;
  const old = keys.sort((a, b) => (all[a].t || 0) - (all[b].t || 0)).slice(0, keys.length - max);
  const db = await open();
  const s = db.transaction(store, 'readwrite').objectStore(store);
  await Promise.all(old.map((k) => done(s.delete(k))));
  return old.length;
}
