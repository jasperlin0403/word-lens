// 網頁版平台轉接層：讓擴充功能的同一套程式碼在一般網頁（例如 iPad 的 Safari）執行
// 在 Chrome 擴充功能環境中完全不作用。
// 以標準網頁技術模擬程式用到的 chrome.* 功能：
//   runtime（訊息、網址、manifest）、storage.local（IndexedDB）、tts（瀏覽器語音）、
//   tabs（改為頁面跳轉）；action、alarms、contextMenus、scripting 在網頁版沒有對應功能，安全地略過。
(() => {
  if (globalThis.chrome && chrome.runtime && chrome.runtime.id) return; // 擴充功能環境
  if (globalThis.WL_WEB) return;
  globalThis.WL_WEB = true;

  const script = document.currentScript;
  const ROOT = new URL('../', script ? script.src : location.href).href; // web/shim.js 的上一層 = 網站根目錄

  // manifest：同步讀取（多處程式需要立即取得，例如版本號與程式清單）
  // 同步讀取不經過離線快取，所以每次成功讀到就另存一份；沒有網路時改用這份
  let manifest = {};
  const MKEY = 'wl-web-manifest';
  try {
    const x = new XMLHttpRequest();
    x.open('GET', ROOT + 'manifest.json?t=' + Date.now(), false); // 加時間戳：避免讀到瀏覽器快取的舊版
    x.send();
    if (x.status !== 200) throw new Error('offline');
    manifest = JSON.parse(x.responseText);
    localStorage.setItem(MKEY, x.responseText);
  } catch (e) {
    try { manifest = JSON.parse(localStorage.getItem(MKEY) || '{}'); } catch (e2) { manifest = {}; }
  }

  const clone = (v) => (v === undefined ? undefined : JSON.parse(JSON.stringify(v)));
  const listeners = { message: [], changed: [], alarm: [] };

  // 背景程式載入完成後才處理訊息（由 web/boot.mjs 呼叫 resolve）
  let resolveReady;
  const ready = new Promise((r) => { resolveReady = r; });
  globalThis.__wlWebReady = () => resolveReady();

  // ---------- storage.local：IndexedDB＋記憶體快取；跨頁面以 BroadcastChannel 同步變更 ----------
  const cache = {};
  function openStore() {
    return new Promise((resolve, reject) => {
      const r = indexedDB.open('wl-web-storage', 1);
      r.onupgradeneeded = () => r.result.createObjectStore('kv');
      r.onsuccess = () => resolve(r.result);
      r.onerror = () => reject(r.error);
    });
  }
  const dbp = openStore();
  const storeReady = dbp.then((db) => new Promise((resolve) => {
    const s = db.transaction('kv').objectStore('kv');
    const kr = s.getAllKeys();
    const vr = s.getAll();
    vr.onsuccess = () => {
      kr.result.forEach((k, i) => { cache[k] = vr.result[i]; });
      resolve();
    };
    vr.onerror = () => resolve();
  })).catch(() => {});

  async function write(puts, dels) {
    const db = await dbp;
    await new Promise((resolve) => {
      const t = db.transaction('kv', 'readwrite');
      const s = t.objectStore('kv');
      for (const [k, v] of Object.entries(puts)) s.put(v, k);
      for (const k of dels) s.delete(k);
      t.oncomplete = resolve;
      t.onerror = resolve;
    });
  }

  const bc = 'BroadcastChannel' in globalThis ? new BroadcastChannel('wl-web-storage') : null;
  function fire(changes) {
    for (const fn of listeners.changed) {
      try { fn(clone(changes), 'local'); } catch (e) { /* 忽略 */ }
    }
  }
  if (bc) {
    bc.onmessage = (e) => {
      const changes = e.data || {};
      for (const [k, c] of Object.entries(changes)) {
        if (c.newValue === undefined) delete cache[k];
        else cache[k] = c.newValue;
      }
      fire(changes);
    };
  }

  function withCb(p, cb) {
    if (typeof cb === 'function') {
      p.then((v) => cb(v));
      return undefined;
    }
    return p;
  }

  const local = {
    get(keys, cb) {
      const p = storeReady.then(() => {
        const out = {};
        if (keys == null) for (const k of Object.keys(cache)) out[k] = clone(cache[k]);
        else if (typeof keys === 'string') { if (keys in cache) out[keys] = clone(cache[keys]); }
        else if (Array.isArray(keys)) { for (const k of keys) if (k in cache) out[k] = clone(cache[k]); }
        else for (const [k, d] of Object.entries(keys)) out[k] = k in cache ? clone(cache[k]) : d;
        return out;
      });
      return withCb(p, cb);
    },
    set(obj, cb) {
      const p = storeReady.then(async () => {
        const changes = {};
        const puts = {};
        for (const [k, v] of Object.entries(obj || {})) {
          changes[k] = { oldValue: clone(cache[k]), newValue: clone(v) };
          cache[k] = clone(v);
          puts[k] = cache[k];
        }
        await write(puts, []);
        fire(changes);
        if (bc) bc.postMessage(changes);
      });
      return withCb(p, cb);
    },
    remove(keys, cb) {
      const list = Array.isArray(keys) ? keys : [keys];
      const p = storeReady.then(async () => {
        const changes = {};
        for (const k of list) if (k in cache) { changes[k] = { oldValue: clone(cache[k]) }; delete cache[k]; }
        await write({}, list);
        fire(changes);
        if (bc) bc.postMessage(changes);
      });
      return withCb(p, cb);
    }
  };

  // ---------- runtime ----------
  const runtime = {
    id: 'wl-web',
    lastError: undefined,
    getURL: (p) => new URL(String(p || '').replace(/^\//, ''), ROOT).href,
    getManifest: () => manifest,
    sendMessage(msg, cb) {
      // 背景程式若載入失敗，ready 永遠不會完成；加上逾時，讓畫面能顯示錯誤而不是一直空轉
      const guard = new Promise((resolve) => setTimeout(() => resolve({ ok: false, error: { code: 'NO_BACKGROUND', message: '背景程式沒有回應，請重新整理頁面。' } }), 20000));
      const p = Promise.race([guard, ready.then(() => new Promise((resolve) => {
        const sender = { id: 'wl-web', url: location.href };
        let done = false;
        const respond = (r) => { if (!done) { done = true; resolve(clone(r)); } };
        let async = false;
        for (const fn of listeners.message) if (fn(clone(msg), sender, respond) === true) async = true;
        if (!async && !done) resolve(undefined);
      }))]);
      return withCb(p, cb);
    },
    onMessage: { addListener: (fn) => listeners.message.push(fn) },
    onInstalled: { addListener() {} }, // 網頁版沒有「安裝」事件；資料轉移由背景程式啟動時自動檢查
    onStartup: { addListener() {} },
    openOptionsPage: () => { location.href = runtime.getURL('pages/options.html'); }
  };

  // ---------- 發音：瀏覽器內建語音 ----------
  // 不能只指定語言：macOS／iPad 的 en-US 清單裡有 Zarvox、Whisper 等怪聲語音，可能被系統挑到。
  // 所以用 background/voice.js 的規則明確挑一個自然的語音（載入失敗時退回只指定語言）。
  const voiceUrl = new URL('../background/voice.js', document.currentScript ? document.currentScript.src : location.href).href;
  let voicePicker = null;
  import(voiceUrl).then((m) => { voicePicker = m.pickVoice; }).catch(() => {});
  const chosen = {};
  function chooseVoice(lang) {
    if (!voicePicker) return null;
    const vs = speechSynthesis.getVoices();
    if (!vs.length) return null;
    if (chosen[lang] && vs.includes(chosen[lang])) return chosen[lang];
    const v = voicePicker(vs.map((x) => ({ name: x.name, lang: x.lang, local: x.localService, ref: x })), lang);
    chosen[lang] = v ? vs.find((x) => x.name === v.name && x.lang === v.lang) || null : null;
    return chosen[lang];
  }
  try { speechSynthesis.addEventListener('voiceschanged', () => { for (const k in chosen) delete chosen[k]; }); } catch (e) { /* 忽略 */ }
  const tts = {
    speak(text, opts = {}) {
      try {
        speechSynthesis.cancel();
        const u = new SpeechSynthesisUtterance(String(text || ''));
        u.lang = opts.lang || 'en-US';
        u.rate = opts.rate || 0.9;
        const v = chooseVoice(u.lang);
        if (v) u.voice = v;
        speechSynthesis.speak(u);
      } catch (e) { /* 裝置不支援語音 */ }
    }
  };

  // ---------- 分頁：網頁版改為在同一頁跳轉 ----------
  const tabs = {
    create: ({ url }) => { location.href = url; return Promise.resolve({}); },
    update: (id, { url }) => { location.href = url; return Promise.resolve({}); },
    query: () => Promise.resolve([])
  };

  const noop = () => Promise.resolve();
  globalThis.chrome = {
    runtime,
    storage: {
      local,
      onChanged: {
        addListener: (fn) => listeners.changed.push(fn),
        removeListener: (fn) => { const i = listeners.changed.indexOf(fn); if (i >= 0) listeners.changed.splice(i, 1); }
      }
    },
    tts,
    tabs,
    action: { setBadgeText: noop, setBadgeBackgroundColor: noop, getBadgeText: () => Promise.resolve('') },
    alarms: {
      create: (name, { periodInMinutes } = {}) => {
        if (periodInMinutes) setInterval(() => listeners.alarm.forEach((fn) => fn({ name })), periodInMinutes * 60000);
      },
      onAlarm: { addListener: (fn) => listeners.alarm.push(fn) }
    },
    contextMenus: { removeAll: (cb) => cb && cb(), create() {}, onClicked: { addListener() {} } },
    scripting: { insertCSS: noop, executeScript: noop }
  };
})();
