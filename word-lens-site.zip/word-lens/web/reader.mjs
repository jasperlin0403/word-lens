// 網頁版首頁：貼上文章閱讀、快速查字、接收 iPad「分享」傳來的文字
import { loadContentScripts } from './boot.mjs';

const $ = (id) => document.getElementById(id);
const KEY = 'wl-reader-text';

function render(text) {
  const art = $('reader');
  art.textContent = '';
  for (const para of String(text).split(/\n\s*\n|\r?\n/).map((p) => p.trim()).filter(Boolean)) {
    const p = document.createElement('p');
    p.textContent = para;
    art.appendChild(p);
  }
  art.hidden = false;
  $('readBar').hidden = false;
  $('editor').hidden = true;
}

function edit() {
  $('reader').hidden = true;
  $('readBar').hidden = true;
  $('editor').hidden = false;
}

// 在閱讀區中找出某個字的位置，讓查詢卡顯示在它旁邊
function rangeOf(word) {
  const w = document.createTreeWalker($('reader'), NodeFilter.SHOW_TEXT);
  const re = new RegExp('\\b' + word.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '\\b', 'i');
  let n;
  while ((n = w.nextNode())) {
    const m = re.exec(n.data);
    if (m) {
      const r = document.createRange();
      r.setStart(n, m.index);
      r.setEnd(n, m.index + m[0].length);
      return r;
    }
  }
  return null;
}

await loadContentScripts();
const WL = globalThis.__WL;

$('shareUrl').textContent = new URL('index.html?share=', location.href).href;
$('text').value = localStorage.getItem(KEY) || '';
$('read').addEventListener('click', () => {
  const t = $('text').value.trim();
  if (!t) return;
  localStorage.setItem(KEY, t);
  render(t);
});
$('clear').addEventListener('click', () => { $('text').value = ''; localStorage.removeItem(KEY); });
$('edit').addEventListener('click', edit);

$('quick').addEventListener('submit', (e) => {
  e.preventDefault();
  const w = $('quickInput').value.trim().replace(/^[^A-Za-z]+|[^A-Za-z]+$/g, '');
  if (!w || !WL.U.WORD_RE.test(w)) return;
  $('quickInput').blur();
  WL.cards.showWordCard(w, '', $('quickInput').getBoundingClientRect(), $('quickInput'));
});

// 從 iPad「分享」傳來的文字：單字 → 直接查；句子 → 顯示在閱讀區並翻譯
const shared = (new URLSearchParams(location.search).get('share') || '').trim();
if (shared) {
  history.replaceState(null, '', location.pathname);
  $('text').value = shared;
  render(shared);
  const word = shared.replace(/^[^A-Za-z]+|[^A-Za-z]+$/g, '');
  setTimeout(() => {
    if (!/\s/.test(shared) && WL.U.WORD_RE.test(word)) {
      const r = rangeOf(word);
      WL.cards.showWordCard(word, '', r ? r.getBoundingClientRect() : $('reader').getBoundingClientRect(), r ? r.startContainer : $('reader'));
    } else if (shared.length <= 500) {
      WL.cards.showSentenceCard(shared, $('reader').getBoundingClientRect(), $('reader'));
    }
  }, 300);
} else if ($('text').value) {
  render($('text').value);
}

// 提醒：尚未設定金鑰、太久沒備份（網頁版資料只存在這台裝置的瀏覽器）
chrome.runtime.sendMessage({ type: 'key-status' }, (r) => { $('noKey').hidden = !(r && r.ok && !r.data.set); });
chrome.storage.local.get(['words', 'lastBackup'], ({ words = {}, lastBackup = 0 }) => {
  const n = Object.keys(words).length;
  const days = Math.floor((Date.now() - lastBackup) / 86400000);
  if (n && (!lastBackup || days >= 7)) {
    const b = $('backup');
    b.innerHTML = '';
    b.append('生詞本有 ' + n + ' 個字，' + (lastBackup ? '已經 ' + days + ' 天沒有備份' : '還沒有備份過') + '。網頁版資料只存在這台裝置，建議到 ');
    const a = document.createElement('a');
    a.href = 'pages/wordbook.html';
    a.textContent = '生詞本';
    b.append(a, ' 按「備份（JSON）」存到「檔案」。');
    b.hidden = false;
  }
});
