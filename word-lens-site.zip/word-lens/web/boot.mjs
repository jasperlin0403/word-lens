// 網頁版啟動：載入與擴充功能相同的背景程式、註冊離線快取、加上頁面導覽列
// 在擴充功能環境中不作用。
const WEB = !!globalThis.WL_WEB;

export async function loadContentScripts() {
  if (!globalThis.WLUtil) {
    await new Promise((resolve) => {
      const s = document.createElement('script');
      s.src = chrome.runtime.getURL('shared/util.js');
      s.onload = s.onerror = resolve;
      document.head.appendChild(s);
    });
  }
  return globalThis.WLUtil.loadContent();
}

const NAV = [
  ['index.html', '📖 閱讀'],
  ['pdf/viewer.html', '📄 PDF'],
  ['pages/wordbook.html', '📚 生詞本'],
  ['pages/review.html', '🔁 複習'],
  ['pages/popup.html', '⚙️ 快速設定'],
  ['pages/options.html', '🔑 金鑰與模型']
];

function injectNav() {
  if (document.documentElement.hasAttribute('data-wl-nonav')) return;
  const nav = document.createElement('nav');
  nav.className = 'wl-webnav';
  nav.setAttribute('aria-label', '網頁版導覽');
  const here = location.pathname;
  for (const [path, label] of NAV) {
    const a = document.createElement('a');
    a.href = chrome.runtime.getURL(path);
    a.textContent = label;
    if (here.endsWith('/' + path) || (path === 'index.html' && /\/$/.test(here))) a.setAttribute('aria-current', 'page');
    if (path === 'pages/review.html') a.id = 'wlNavReview';
    nav.appendChild(a);
  }
  const style = document.createElement('style');
  style.textContent = `
    .wl-webnav { display: flex; gap: 4px; flex-wrap: wrap; padding: 8px 10px; background: #0E3A4F;
      font: 14px/1.4 -apple-system, "Segoe UI", "Noto Sans TC", "PingFang TC", sans-serif; }
    .wl-webnav a { color: #E6F3F8; text-decoration: none; padding: 6px 10px; border-radius: 8px; }
    .wl-webnav a[aria-current="page"] { background: #1F7AA0; color: #fff; font-weight: 600; }
    .wl-webnav .n { display: inline-block; min-width: 18px; margin-left: 4px; padding: 0 5px; border-radius: 9px; background: #FFD84D; color: #0E3A4F; font-size: 12px; text-align: center; font-weight: 700; }
    body.wl-popup-page { width: auto !important; max-width: 440px; margin: 0 auto !important; }
  `;
  document.head.appendChild(style);
  document.body.prepend(nav);
  if (/\/pages\/popup\.html$/.test(here)) document.body.classList.add('wl-popup-page');
  chrome.runtime.sendMessage({ type: 'review-stats' }, (r) => {
    if (r && r.ok && r.data.due) {
      const n = document.createElement('span');
      n.className = 'n';
      n.textContent = r.data.due > 99 ? '99+' : r.data.due;
      document.getElementById('wlNavReview').appendChild(n);
    }
  });
}

if (WEB) {
  const m = chrome.runtime.getManifest();
  await import(chrome.runtime.getURL(m.background.service_worker)); // 與擴充功能相同的背景程式
  globalThis.__wlWebReady();
  if ('serviceWorker' in navigator) navigator.serviceWorker.register(chrome.runtime.getURL('sw.js')).catch(() => {});
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', injectNav, { once: true });
  else injectNav();
}
